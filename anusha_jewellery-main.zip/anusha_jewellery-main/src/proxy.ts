import { NextResponse, type NextRequest } from "next/server";
import { SESSION_COOKIE, verifySessionToken } from "@/lib/session";

// Fast redirect to the login page; pages and actions still verify the session themselves.
export async function proxy(request: NextRequest) {
  const session = await verifySessionToken(request.cookies.get(SESSION_COOKIE)?.value);
  if (!session) {
    const url = new URL("/login", request.url);
    url.searchParams.set("next", request.nextUrl.pathname + request.nextUrl.search);
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/orders/:path*",
    "/billing/:path*",
    "/pawning/:path*",
    "/find/:path*",
    "/lockers/:path*",
    "/stock/:path*",
    "/settings/:path*",
    "/reports/:path*",
    "/print/:path*",
  ],
};
