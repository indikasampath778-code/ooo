import { redirect } from "next/navigation";

// No public website: the root opens the shop system (the proxy sends signed-out users to /login).
export default function Home() {
  redirect("/dashboard");
}
