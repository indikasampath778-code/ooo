// Shown instantly on navigation while the next page loads its data.
export default function Loading() {
  return (
    <div className="animate-pulse space-y-6" aria-busy="true" aria-label="Loading">
      <div className="h-20 rounded-2xl border border-slate-200 bg-white shadow-sm" />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 4 }, (_, i) => (
          <div key={i} className="h-28 rounded-xl border border-slate-200 bg-white shadow-sm" />
        ))}
      </div>
      <div className="h-64 rounded-2xl border border-slate-200 bg-white shadow-sm" />
    </div>
  );
}
