import type { Metadata } from "next";
import Link from "next/link";
import { createOrder } from "@/app/actions/orders";
import ActionForm from "@/components/ActionForm";
import FormDialog from "@/components/FormDialog";
import OrderAdvanceFields from "@/components/OrderAdvanceFields";
import { OrderFields, OrdersTable } from "@/components/orders";
import SearchBox from "@/components/SearchBox";
import { PageHeader, UrgencyLegend } from "@/components/ui";
import { formatMoney } from "@/lib/format";
import { getOrder, listOrders, type OrderFilter } from "@/lib/orders";

export const metadata: Metadata = { title: "Orders | Anusha Jewellers" };

const tabs: { value: OrderFilter; label: string }[] = [
  { value: "all", label: "All" },
  { value: "pending", label: "Pending" },
  { value: "active", label: "In progress" },
  { value: "ready", label: "Completed" },
  { value: "delivered", label: "Delivered" },
];

export default async function OrdersPage(props: PageProps<"/orders">) {
  const sp = await props.searchParams;
  const filter = tabs.find((t) => t.value === sp.filter)?.value ?? "all";
  const q = typeof sp.q === "string" ? sp.q.trim() : "";
  // Set after saving a new order, to confirm it here.
  const createdId = typeof sp.created === "string" ? sp.created : "";
  const [orders, created] = await Promise.all([listOrders(filter, q), createdId ? getOrder(createdId) : null]);
  const advance = created?.payments[0];

  return (
    <>
      <PageHeader
        title="Customer Orders"
        actions={
          <FormDialog label="+ New Order" title="New Order">
            <ActionForm action={createOrder} submitLabel="Save order" submitClassName="btn-primary px-8">
              <OrderFields wide />
              <OrderAdvanceFields />
            </ActionForm>
          </FormDialog>
        }
      />

      {created && (
        <div role="status" className="mb-5 flex flex-wrap items-center gap-3 rounded-xl border border-emerald-300 bg-emerald-50 px-4 py-3 text-sm text-emerald-900">
          <span className="font-semibold">
            Order {created.billNo} saved for {created.customer.name}
            {advance && ` · advance ${formatMoney(advance.amount)}`}.
          </span>
          <span className="ml-auto flex flex-wrap gap-2">
            {advance && (
              <a href={`/print/receipt/${advance.receiptNo}`} className="btn-primary px-3 py-1.5">Print advance receipt</a>
            )}
            <Link href={`/orders/${createdId}`} className="btn-outline px-3 py-1.5">Open order</Link>
          </span>
        </div>
      )}

      <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-4">
          <SearchBox placeholder="Search by bill no, customer name, phone or locker…" />
          <div className="flex flex-wrap gap-1 rounded-lg bg-canvas p-1">
            {tabs.map((tab) => (
              <Link
                key={tab.value}
                href={`/orders?filter=${tab.value}${q ? `&q=${encodeURIComponent(q)}` : ""}`}
                className={`rounded-md px-3 py-1.5 text-sm font-medium ${filter === tab.value ? "bg-ink text-canvas shadow-sm" : "text-ink hover:bg-white"}`}
              >
                {tab.label}
              </Link>
            ))}
          </div>
        </div>

        {orders.length ? (
          <OrdersTable orders={orders} bare />
        ) : (
          <p className="p-10 text-center text-sm text-foreground/60">No orders found.</p>
        )}

        <div className="border-t border-slate-200 px-4 py-2.5">
          <UrgencyLegend />
        </div>
      </section>
    </>
  );
}
