import type { Metadata } from "next";
import { createOrder } from "@/app/actions/orders";
import ActionForm from "@/components/ActionForm";
import OrderAdvanceFields from "@/components/OrderAdvanceFields";
import { OrderFields } from "@/components/orders";
import { PageHeader } from "@/components/ui";
import { requireUser } from "@/lib/auth";

export const metadata: Metadata = { title: "New Order | Anusha Jewellers" };

export default async function NewOrderPage() {
  await requireUser();
  return (
    <>
      <PageHeader title="New Order" />
      <div className="card">
        <ActionForm action={createOrder} submitLabel="Save order" submitClassName="btn-primary px-8">
          <OrderFields wide />
          <OrderAdvanceFields />
        </ActionForm>
      </div>
    </>
  );
}
