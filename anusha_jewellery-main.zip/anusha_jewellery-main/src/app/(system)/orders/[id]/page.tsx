import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { deliverOrder, updateOrder } from "@/app/actions/orders";
import ActionForm from "@/components/ActionForm";
import Barcode from "@/components/Barcode";
import LabelPrintButton from "@/components/LabelPrintButton";
import OrderTabs from "@/components/OrderTabs";
import StatusSelect from "@/components/StatusSelect";
import { InstallmentSchedule, OrderFields, OrderLockerForm, OrderPriceForm, PaymentHistory, PaymentSummary } from "@/components/orders";
import { Detail, StatusBadge, UrgencyBadge } from "@/components/ui";
import { formatDate, formatDateTime, formatMoney, formatWeight } from "@/lib/format";
import { getCategoryNames } from "@/lib/categories";
import { lockerLabel } from "@/lib/lockerLabel";
import { getOrder, orderTotals } from "@/lib/orders";
import { deliveryLabel, deliveryUrgency } from "@/lib/rules";

export const metadata: Metadata = { title: "Order | Anusha Jewellers" };

export default async function OrderPage(props: PageProps<"/orders/[id]">) {
  const categoryName = await getCategoryNames();
  const { id } = await props.params;
  // Arriving from "Completed…" in the orders table opens the completion popup.
  const completing = (await props.searchParams).complete === "1";
  const order = await getOrder(id);
  if (!order) notFound();

  const urgency = deliveryUrgency(order.status, order.deliveryDate);
  const { balance, paid } = orderTotals(order);
  const inProgress = order.status === "pending" || order.status === "in_progress";

  return (
    <OrderTabs
      status={
        <>
          {order.status === "pending" || order.status === "in_progress" ? (
            <StatusSelect
              id={id}
              status={order.status}
              completion={{ weightMg: order.weightMg, karat: order.karat }}
              startCompleting={completing}
            />
          ) : (
            <StatusBadge status={order.status} />
          )}
          <UrgencyBadge urgency={urgency} label={deliveryLabel(order.deliveryDate)} />
        </>
      }
      actions={order.barcode && <LabelPrintButton kind="order" id={id} />}
      paymentsSummary={
        <span className={balance ? "text-red-600" : undefined}>
          {balance == null ? `Paid ${formatMoney(paid)}` : `Balance ${formatMoney(balance)}`}
        </span>
      }
      order={
        <div className="space-y-6">
          {order.status !== "delivered" ? (
            <section className="card">
              <h2 className="card-title">Customer &amp; item</h2>
              <ActionForm action={updateOrder.bind(null, id)} submitLabel="Save changes">
                <OrderFields order={order} wide />
              </ActionForm>
            </section>
          ) : (
            <section className="card">
              <h2 className="card-title">Customer &amp; item</h2>
              <p className="mb-4 text-xs text-foreground/50">Delivered orders can no longer be edited.</p>
              <dl className="grid gap-4 sm:grid-cols-3 lg:grid-cols-5">
                <Detail label="Customer">{order.customer.name}</Detail>
                <Detail label="Phone"><a href={`tel:${order.customer.phone}`} className="underline">{order.customer.phone}</a></Detail>
                <Detail label="Address">{order.customer.address || "—"}</Detail>
                <Detail label="Category">{categoryName(order.category)} ({order.category})</Detail>
                <Detail label="Weight (ordered)">{formatWeight(order.weightMg)}</Detail>
                <Detail label="Carats">{order.karat}K</Detail>
                <Detail label="Item maker">{order.makerName}</Detail>
                <Detail label="Delivery date">{formatDate(order.deliveryDate)}</Detail>
                <Detail label="Bill number">{order.billNo}</Detail>
              </dl>
              {order.notes && <p className="mt-4 rounded-lg bg-canvas p-3 text-sm whitespace-pre-line">{order.notes}</p>}
            </section>
          )}

          {/* Completion details and the locker only matter once work on the item has finished. */}
          {!inProgress && (
            <div className="grid gap-6 lg:grid-cols-2">
              <section className="card">
                <h2 className="card-title">Completed item</h2>
                {order.completion ? (
                  <dl className="grid gap-4 sm:grid-cols-2">
                    <Detail label="Final weight">{formatWeight(order.completion.finalWeightMg)}</Detail>
                    <Detail label="Carats">{order.completion.karat}K</Detail>
                    <Detail label="Price">{order.completion.price == null ? "Not set yet" : formatMoney(order.completion.price)}</Detail>
                    <Detail label="Completed on">{formatDateTime(order.completion.completedAt)}</Detail>
                  </dl>
                ) : (
                  <p className="text-sm text-foreground/60">This order was cancelled.</p>
                )}
                {order.status === "completed" && (
                  <div className="mt-4 border-t border-slate-200 pt-4">
                    <OrderPriceForm order={order} />
                  </div>
                )}
              </section>

              <section className="card">
                <h2 className="card-title">Locker &amp; barcode</h2>
                {order.lockerCode || order.barcode ? (
                  <div className="flex flex-wrap items-center gap-4">
                    {order.lockerCode ? (
                      <div className="rounded-xl bg-ink px-6 py-4 text-center text-canvas">
                        <p className="text-xs tracking-widest text-gold-light uppercase">Locker</p>
                        <p className="text-3xl font-bold">{lockerLabel(order.lockerCode, order.lockerSlot)}</p>
                      </div>
                    ) : (
                      <p className="text-sm text-foreground/60">Handed over — taken out of its locker.</p>
                    )}
                    {order.barcode && (
                      <div className="text-center">
                        <Barcode value={order.barcode} className="h-14 w-56" />
                        <p className="mt-1 font-mono text-sm">{order.barcode}</p>
                      </div>
                    )}
                  </div>
                ) : order.status === "completed" ? (
                  <OrderLockerForm order={order} />
                ) : (
                  <p className="text-sm text-foreground/60">No locker — this order was cancelled.</p>
                )}
              </section>
            </div>
          )}

          {order.status === "completed" && balance === 0 && (
            <section className="card">
              <h2 className="card-title">Hand over</h2>
              <ActionForm action={deliverOrder.bind(null, id)} submitLabel="Hand over to customer" confirmMessage="Hand this item over and free its locker?">
                <p className="text-sm text-foreground/70">Fully paid. Hand over the item from {lockerLabel(order.lockerCode, order.lockerSlot) ?? ""}.</p>
              </ActionForm>
            </section>
          )}
        </div>
      }
      payments={
        <section className="card">
          <div className="grid gap-6 lg:grid-cols-2">
            <div className="space-y-4">
              <PaymentSummary order={order} />
              {order.status !== "delivered" && order.status !== "cancelled" && (
                <div>
                  <p className="mb-3 text-sm text-foreground/70">All payments are taken in Billing.</p>
                  <Link href={`/billing?id=${id}`} className="btn-primary w-full">
                    {balance ? `Take payment in Billing · ${formatMoney(balance)} due` : "Take payment in Billing"}
                  </Link>
                </div>
              )}
              <InstallmentSchedule order={order} />
            </div>
            <div>
              <h3 className="mb-2 text-sm font-semibold text-ink">Payment history</h3>
              <PaymentHistory order={order} />
            </div>
          </div>
        </section>
      }
    />
  );
}
