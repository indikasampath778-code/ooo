import type { Metadata } from "next";
import Link from "next/link";
import CheckoutForm, { type CartLine } from "@/components/CheckoutForm";
import { InstallmentSchedule, OrderPaymentForm, OrderPriceForm, OrdersTable, PaymentHistory, PaymentSummary } from "@/components/orders";
import ScanToCart from "@/components/ScanToCart";
import { StockTable } from "@/components/stock";
import { PawnInterestSummary, PawnPaymentPanel } from "@/components/pawnPayments";
import { PawnsTable } from "@/components/pawns";
import { Accordion, Detail, EmptyState, PageHeader, Pill, StatusBadge } from "@/components/ui";
import { getCategoryNames } from "@/lib/categories";
import { formatDate, formatDateTime, formatMoney, formatWeight, todayISO } from "@/lib/format";
import { lockerLabel } from "@/lib/lockerLabel";
import { getOrder, orderTotals, searchOrders } from "@/lib/orders";
import { getCartItems, readCartIds } from "@/lib/cart";
import { getPawn, searchPawns } from "@/lib/pawns";
import { getReservation, listReservations, reservationTotals } from "@/lib/reservations";
import { ratePerGram } from "@/lib/pricing";
import { getLatestGoldRates } from "@/lib/rates";
import { searchStock } from "@/lib/stock";
import type { PawnDoc, ReservationDoc } from "@/lib/types";
import { cancelReservation, payReservation } from "@/app/actions/reservations";
import ActionForm from "@/components/ActionForm";
import ClickableRow from "@/components/ClickableRow";
import OrderPaymentFields from "@/components/OrderPaymentFields";
import { payMethodLabel } from "@/lib/constants";

export const metadata: Metadata = { title: "Billing | Anusha Jewellers" };

const billingTabs = [
  { value: "orders", label: "Order bills" },
  { value: "stock", label: "Shop sales" },
  { value: "reservations", label: "Reservations" },
  { value: "pawn", label: "Pawn payments" },
] as const;

export default async function BillingPage(props: PageProps<"/billing">) {
  const sp = await props.searchParams;
  const type = billingTabs.find((t) => t.value === sp.type)?.value ?? "orders";
  const q = typeof sp.q === "string" ? sp.q.trim() : "";
  const id = typeof sp.id === "string" ? sp.id : "";

  return (
    <>
      <PageHeader title="Billing" />

      <div className="mb-5 flex w-fit gap-1 rounded-lg bg-white p-1 ring-1 ring-slate-200">
        {billingTabs.map((t) => (
          <Link
            key={t.value}
            href={`/billing?type=${t.value}`}
            className={`rounded-md px-4 py-2 text-sm font-medium ${type === t.value ? "bg-ink text-canvas shadow-sm" : "text-ink hover:bg-canvas"}`}
          >
            {t.label}
          </Link>
        ))}
      </div>

      {type !== "stock" && (
      <form className="card mb-6 flex max-w-2xl flex-col gap-3 p-4 sm:flex-row">
        <input type="hidden" name="type" value={type} />
        <input
          key={type}
          name="q"
          defaultValue={q}
          autoFocus
          className="input"
          placeholder={
            type === "pawn"
              ? "Scan the pawn ticket, or search ticket no, NIC, name, phone or locker"
              : type === "reservations"
                ? "Reservation no (RS000001), customer name, phone or item code"
                : "Bill number, customer name, locker or scan barcode"
          }
        />
        <button className="btn-primary px-6">Search</button>
      </form>
      )}

      {type === "stock" && <StockBilling q={q} />}
      {type === "pawn" && <PawnBilling q={q} id={id} />}
      {type === "reservations" && <ReservationBilling q={q} id={id} showAll={sp.status === "all"} />}
      {type === "orders" && <OrderBilling q={q} id={id} />}
    </>
  );
}

/* ---------------- Reservations (installments for shop stock) ---------------- */

async function ReservationBilling({ q, id, showAll }: { q: string; id: string; showAll: boolean }) {
  const selected = id ? await getReservation(id) : null;
  if (selected) return <ReservationBill reservation={selected} />;
  const list = await listReservations(q || showAll ? "all" : "active", q);
  if (q && list.length === 1) return <ReservationBill reservation={list[0]} />;

  return (
    <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-4">
        <h2 className="font-bold text-lg text-ink">
          {q ? `Reservations matching “${q}”` : showAll ? "All reservations" : "Active reservations"}
        </h2>
        {!q && (
          <Link href={showAll ? "/billing?type=reservations" : "/billing?type=reservations&status=all"} className="text-sm font-semibold text-ink underline">
            {showAll ? "Show active only" : "Show completed & cancelled too"}
          </Link>
        )}
      </div>
      {list.length === 0 ? (
        <p className="p-10 text-center text-sm text-foreground/60">
          {q ? "No reservation found." : "No reservations yet. Reserve items from Billing → Shop sales."}
        </p>
      ) : (
        <div className="overflow-x-auto">
          <table className="table">
            <thead>
              <tr><th>Reservation</th><th>Customer</th><th>Items</th><th>Reserved until</th><th className="text-right">Balance</th><th>Status</th></tr>
            </thead>
            <tbody>
              {list.map((r) => {
                const { balance } = reservationTotals(r);
                const overdue = r.status === "active" && r.reserveUntil != null && r.reserveUntil < todayISO();
                return (
                  <ClickableRow key={r._id.toString()} href={`/billing?type=reservations&id=${r._id}`} className={overdue ? "bg-red-50 hover:bg-red-100" : "hover:bg-canvas/70"}>
                    <td className="font-mono font-semibold text-ink">{r.code}</td>
                    <td><p className="font-medium">{r.customer.name}</p><p className="text-xs text-foreground/60">{r.customer.phone}</p></td>
                    <td className="text-sm">{r.items.map((i) => i.name).join(", ")}</td>
                    <td className="whitespace-nowrap">
                      {r.reserveUntil ? formatDate(r.reserveUntil) : "—"}
                      {overdue && <span className="ml-2 text-xs font-bold text-red-700">Overdue</span>}
                    </td>
                    <td className="text-right font-semibold whitespace-nowrap">{r.status === "cancelled" ? "—" : formatMoney(balance)}</td>
                    <td><ReservationPill status={r.status} /></td>
                  </ClickableRow>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

function ReservationPill({ status }: { status: ReservationDoc["status"] }) {
  if (status === "active") return <Pill tone="ink">Reserved</Pill>;
  if (status === "completed") return <Pill tone="green">Completed</Pill>;
  return <Pill tone="gray">Cancelled</Pill>;
}

async function ReservationBill({ reservation: r }: { reservation: ReservationDoc }) {
  const categoryName = await getCategoryNames();
  const { paid, balance } = reservationTotals(r);
  const id = r._id.toString();
  const last = r.payments.at(-1);
  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <section className="card space-y-5 lg:col-span-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-bold text-xl text-ink">Reservation {r.code}</h2>
          <div className="flex items-center gap-2">
            <ReservationPill status={r.status} />
            <Link href="/billing?type=reservations" className="text-sm font-semibold text-ink underline">All reservations</Link>
          </div>
        </div>
        <dl className="grid gap-4 sm:grid-cols-3">
          <Detail label="Customer">{r.customer.name}</Detail>
          <Detail label="Phone">{r.customer.phone}</Detail>
          <Detail label="Reserved until">{r.reserveUntil ? formatDate(r.reserveUntil) : "—"}</Detail>
          <Detail label="Reserved on">{formatDate(todayISO(r.createdAt))}</Detail>
          <Detail label="By">{r.createdBy}</Detail>
          {r.notes && <Detail label="Notes">{r.notes}</Detail>}
        </dl>
        <div className="overflow-x-auto rounded-xl border border-slate-200">
          <table className="table">
            <thead><tr><th>Item</th><th>Weight</th><th className="text-right">Price</th></tr></thead>
            <tbody>
              {r.items.map((i) => (
                <tr key={i.code}>
                  <td>
                    <Link href={`/stock/${i.stockId}`} className="font-medium text-ink underline">{i.name}</Link>
                    <p className="font-mono text-xs text-foreground/60">{i.code} · {categoryName(i.category)} {i.karat}K</p>
                  </td>
                  <td className="whitespace-nowrap">{formatWeight(i.weightMg)}</td>
                  <td className="text-right whitespace-nowrap">{formatMoney(i.price)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <dl className="space-y-1.5 rounded-xl bg-canvas p-3 text-sm">
          <div className="flex justify-between"><dt className="text-foreground/60">Total</dt><dd className="font-bold">{formatMoney(r.total)}</dd></div>
          <div className="flex justify-between"><dt className="text-foreground/60">Paid</dt><dd className="font-bold text-emerald-700">{formatMoney(paid)}</dd></div>
          <div className="flex justify-between border-t border-slate-200 pt-1.5 text-base">
            <dt className="font-semibold">Balance</dt>
            <dd className={`font-bold ${balance ? "text-red-700" : ""}`}>{formatMoney(balance)}</dd>
          </div>
        </dl>
        <div>
          <h3 className="mb-2 text-sm font-semibold text-ink">Payment history</h3>
          {r.payments.length === 0 ? (
            <p className="text-sm text-foreground/50">No payments yet.</p>
          ) : (
            <ul className="divide-y divide-slate-100 text-sm">
              {r.payments.map((p) => (
                <li key={p.receiptNo} className="flex items-center justify-between gap-2 py-2">
                  <div>
                    <p className="font-semibold">{formatMoney(p.amount)}</p>
                    <p className="text-xs text-foreground/60">
                      {formatDateTime(p.paidAt)} · {payMethodLabel(p.method)}
                      {p.oldGold && p.oldGold.length > 0 && ` · incl. old gold ${formatMoney(p.amount - (p.cash ?? 0))}`}
                      {p.note && ` · ${p.note}`}
                    </p>
                  </div>
                  <a href={`/print/receipt/${p.receiptNo}`} className="text-xs font-semibold text-ink underline">{p.receiptNo}</a>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      <div className="space-y-4 lg:col-span-2">
        {r.status === "active" ? (
          <>
            <section className="card">
              <h2 className="card-title">Payments</h2>
              <OrderPaymentFields action={payReservation.bind(null, id)} balance={balance} canHandOver={false} submitLabel="Save payment" />
            </section>
            <Accordion title="Cancel reservation">
              <ActionForm
                action={cancelReservation.bind(null, id)}
                submitLabel="Cancel reservation"
                submitClassName="btn-danger w-full"
                confirmMessage={`Cancel ${r.code}? The items go back into stock.`}
              >
                <p className="text-sm text-foreground/70">
                  The items go back into stock.
                  {paid > 0 && <> The customer has paid <strong>{formatMoney(paid)}</strong>, to be refunded or kept as agreed.</>}
                </p>
              </ActionForm>
            </Accordion>
          </>
        ) : r.status === "completed" ? (
          <section className="card space-y-3">
            <h2 className="card-title mb-0">Completed</h2>
            <p className="text-sm text-foreground/70">Fully paid on {formatDateTime(r.completedAt)}. The items are sold to {r.customer.name}.</p>
            {last && (
              <a href={`/print/receipt/${last.receiptNo}`} className="btn-primary w-full">
                Print final receipt ({last.receiptNo})
              </a>
            )}
          </section>
        ) : (
          <section className="card space-y-3">
            <h2 className="card-title mb-0">Cancelled</h2>
            <p className="text-sm text-foreground/70">
              Cancelled on {formatDateTime(r.cancelledAt)}. The items went back into stock.
              {paid > 0 && <> Amount paid by the customer: <strong>{formatMoney(paid)}</strong>.</>}
            </p>
          </section>
        )}
      </div>
    </div>
  );
}

/* ---------------- Pawn payments ---------------- */

async function PawnBilling({ q, id }: { q: string; id: string }) {
  const results = id ? [] : await searchPawns(q);
  // A single match (e.g. a scanned ticket) opens straight away; prefer an active pawn.
  const active = results.filter((p) => p.status === "active");
  const selected = id ? await getPawn(id) : results.length === 1 ? results[0] : active.length === 1 && q.toUpperCase() === active[0].ticketNo ? active[0] : null;

  if (selected) return <PawnBill pawn={selected} />;
  if (!q) return <EmptyState>Scan a pawn ticket or search to take interest or settle a pawn.</EmptyState>;
  if (!results.length) return <EmptyState>No pawn found for “{q}”.</EmptyState>;
  return (
    <>
      <p className="mb-3 text-sm text-foreground/60">{results.length} matching pawns — choose one:</p>
      <PawnsTable pawns={results} inBilling />
    </>
  );
}

async function PawnBill({ pawn }: { pawn: PawnDoc }) {
  const categoryName = await getCategoryNames();
  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <section className="card space-y-5 lg:col-span-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-bold text-xl text-ink">Pawn {pawn.ticketNo}</h2>
          <div className="flex items-center gap-2">
            {pawn.status === "active" ? <Pill tone="green">In stock · {lockerLabel(pawn.lockerCode, pawn.lockerSlot)}</Pill> : <Pill tone="gray">Released</Pill>}
            <Link href={`/pawning/${pawn._id}`} className="text-sm font-semibold text-ink underline">Full pawn</Link>
          </div>
        </div>
        <dl className="grid gap-4 sm:grid-cols-3">
          <Detail label="Customer">{pawn.customer.name}</Detail>
          <Detail label="NIC">{pawn.customer.nic}</Detail>
          <Detail label="Phone">{pawn.customer.phone}</Detail>
          <Detail label="Item">{categoryName(pawn.category)} · {pawn.standard}</Detail>
          <Detail label="Net weight">{formatWeight(pawn.netWeightMg)}</Detail>
          <Detail label="Pawned">{formatDate(pawn.pawnDate)}</Detail>
          <Detail label="Principal">{formatMoney(pawn.principal)}</Detail>
          <Detail label="Monthly interest">{pawn.monthlyRate}%</Detail>
          <Detail label="Renewals">{pawn.renewals}</Detail>
        </dl>
        <div className="rounded-xl bg-canvas p-4">
          <h3 className="mb-2 text-sm font-semibold text-ink">Interest today</h3>
          <PawnInterestSummary pawn={pawn} />
        </div>
      </section>
      <div className="lg:col-span-2">
        <PawnPaymentPanel pawn={pawn} />
      </div>
    </div>
  );
}

/* ---------------- Shop sales (cart) ---------------- */

async function StockBilling({ q }: { q: string }) {
  const [results, cart, cartIds, rates] = await Promise.all([searchStock(q), getCartItems(), readCartIds(), getLatestGoldRates()]);
  const lines: CartLine[] = cart.map((i) => ({
    id: i._id.toString(),
    code: i.code,
    name: i.name,
    karat: i.karat,
    weightMg: i.weightMg,
    price: i.price,
    rate: rates ? ratePerGram(rates, i.karat) : null,
    pricing: i.pricing ?? null,
  }));

  return (
    <div className="grid gap-6 xl:grid-cols-5">
      <div className="space-y-4 xl:col-span-2">
        <ScanToCart initial={q} />
        {q &&
          (results.length ? (
            <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
              <p className="border-b border-slate-200 px-4 py-3 text-sm text-foreground/60">
                {results.length} item{results.length === 1 ? "" : "s"} matching “{q}”
              </p>
              <StockTable items={results} bare cartIds={cartIds} />
            </section>
          ) : (
            <EmptyState>No stock item found for “{q}”.</EmptyState>
          ))}
      </div>
      <div className="xl:col-span-3">
        <CheckoutForm items={lines} />
      </div>
    </div>
  );
}

/* ---------------- Order bills ---------------- */

async function OrderBilling({ q, id }: { q: string; id: string }) {
  const results = id ? [] : await searchOrders(q);
  const selected = id ? await getOrder(id) : results.length === 1 ? results[0] : null;

  return (
    <>
      {selected ? (
        <BillDetails order={selected} />
      ) : q ? (
        results.length ? (
          <>
            <p className="mb-3 text-sm text-foreground/60">{results.length} matching bills — choose one:</p>
            <OrdersTable orders={results} linkBase="/billing" />
          </>
        ) : (
          <EmptyState>No bill found for “{q}”.</EmptyState>
        )
      ) : (
        <EmptyState>Search for a bill to see the item details and take payment.</EmptyState>
      )}
    </>
  );
}

async function BillDetails({ order }: { order: NonNullable<Awaited<ReturnType<typeof getOrder>>> }) {
  const categoryName = await getCategoryNames();
  const { balance } = orderTotals(order);
  const canPay = order.status !== "delivered" && order.status !== "cancelled";
  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <section className="card lg:col-span-3">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-bold text-xl text-ink">Bill {order.billNo}</h2>
          <div className="flex items-center gap-2">
            <StatusBadge status={order.status} />
            <Link href={`/orders/${order._id}`} className="text-sm font-semibold text-ink underline">Full order</Link>
          </div>
        </div>
        <dl className="grid gap-4 sm:grid-cols-3">
          <Detail label="Customer">{order.customer.name}</Detail>
          <Detail label="Phone">{order.customer.phone}</Detail>
          <Detail label="Address">{order.customer.address || "—"}</Detail>
          <Detail label="Item">{categoryName(order.category)}</Detail>
          <Detail label="Weight">{formatWeight(order.completion?.finalWeightMg ?? order.weightMg)}</Detail>
          <Detail label="Carats">{order.completion?.karat ?? order.karat}K</Detail>
          <Detail label="Item maker">{order.makerName}</Detail>
          <Detail label="Delivery date">{formatDate(order.deliveryDate)}</Detail>
          <Detail label="Locker">{lockerLabel(order.lockerCode, order.lockerSlot) ?? "—"}</Detail>
        </dl>
        <div className="mt-6">
          <PaymentSummary order={order} />
        </div>
        {order.installmentPlan && (
          <div className="mt-4">
            <InstallmentSchedule order={order} />
          </div>
        )}
        <div className="mt-4">
          <h3 className="mb-2 text-sm font-semibold text-ink">Payment history</h3>
          <PaymentHistory order={order} />
        </div>
      </section>

      <section className="card lg:col-span-2">
        <h2 className="card-title">Pay bill</h2>
        {!canPay ? (
          <div className="space-y-4">
            <p className="text-sm text-foreground/60">
              {order.status === "delivered" ? "This bill is fully paid and the item was handed over." : "This order was cancelled."}
            </p>
            {order.payments.length > 0 && (
              <a href={`/print/receipt/${order.payments.at(-1)!.receiptNo}`} className="btn-primary w-full">
                Print last receipt ({order.payments.at(-1)!.receiptNo})
              </a>
            )}
          </div>
        ) : (
          <>
            {!order.completion && (
              <p className="mb-4 rounded-lg bg-yellow-50 p-3 text-sm text-yellow-900 ring-1 ring-yellow-200">
                The item is not completed yet, so the final price is not set. You can still take an advance.
              </p>
            )}
            {order.status === "completed" && !order.barcode ? (
              // A completed item gets its locker and barcode (on the order page) before any payment is taken.
              <p className="rounded-lg bg-amber-50 p-3 text-sm text-amber-900 ring-1 ring-amber-200">
                Locker number is not displayed.
              </p>
            ) : (
              <>
                {order.status === "completed" && (
                  <div className="mb-4">
                    <OrderPriceForm order={order} />
                  </div>
                )}
                {balance != null && balance > 0 && (
                  <p className="mb-4 text-center">
                    <span className="block text-xs text-foreground/60 uppercase">Balance due</span>
                    <span className="text-3xl font-bold text-ink">{formatMoney(balance)}</span>
                  </p>
                )}
                <OrderPaymentForm order={order} submitLabel="Pay bill" />
              </>
            )}
          </>
        )}
      </section>
    </div>
  );
}
