import type { Metadata } from "next";
import { Stat } from "@/components/ui";
import { formatMoney, formatWeight } from "@/lib/format";
import { listLockers, lockerContents } from "@/lib/lockers";
import { orderStats } from "@/lib/orders";
import { pawnStock } from "@/lib/pawns";
import { stockStats } from "@/lib/stock";

export const metadata: Metadata = { title: "Dashboard | Anusha Jewellers" };

export default async function DashboardPage() {
  const [orders, pawns, lockers, contents, stock] = await Promise.all([orderStats(), pawnStock(), listLockers(), lockerContents(), stockStats()]);
  const stored = contents.length;

  return (
    <div className="space-y-6">
      <section>
        <h2 className="mb-3 text-sm font-bold text-slate-800">Orders</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Stat label="In progress" value={orders.inProgress} tone="ink" icon="💍" />
          <Stat label="Due within 1 week" value={orders.dueSoon} tone="yellow" icon="⏳" />
          <Stat label="Due today / overdue" value={orders.overdue} tone="red" icon="⚠️" />
          <Stat label="Ready for collection" value={orders.ready} icon="✅" hint="Completed, waiting for payment/pickup" />
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-sm font-bold text-slate-800">Pawning stock</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Stat label="Active pawned items" value={pawns.count} tone="ink" icon="🔒" hint={`Net ${formatWeight(pawns.netWeightMg)}`} />
          <Stat label="Principal lent" value={formatMoney(pawns.principal)} icon="💰" />
          <Stat label="Accrued interest" value={formatMoney(pawns.interest)} icon="📈" hint="Unpaid, as of today" />
          <Stat label="Lockers" value={lockers.length} icon="🗄️" hint={`${stored} item${stored === 1 ? "" : "s"} stored in lockers`} />
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-sm font-bold text-slate-800">Shop stock</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Stat
            label="Items in stock"
            value={stock.count}
            tone="ink"
            icon="📦"
            hint={`Total ${formatWeight(stock.weightMg)}${stock.reservedCount ? ` · ${stock.reservedCount} reserved` : ""}`}
          />
          <Stat label="Stock value" value={formatMoney(stock.value)} icon="⚖️" hint={stock.valueAtRate ? "At today's gold rate" : "At selling price"} />
          <Stat label="Sold today" value={stock.soldTodayCount} icon="🏷️" />
          <Stat
            label="Sales today"
            value={formatMoney(stock.soldTodayValue)}
            icon="💵"
            hint={
              stock.oldGoldTodayMg
                ? `Received ${formatMoney(stock.paidToday)} + old gold ${formatWeight(stock.oldGoldTodayMg)} (${formatMoney(stock.oldGoldTodayValue)})`
                : stock.paidToday
                  ? `Received ${formatMoney(stock.paidToday)} incl. reservation payments`
                  : undefined
            }
          />
        </div>
      </section>
    </div>
  );
}
