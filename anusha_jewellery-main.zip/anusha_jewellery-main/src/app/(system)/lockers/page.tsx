import type { Metadata } from "next";
import Link from "next/link";
import { createLocker, deleteLocker, updateLocker } from "@/app/actions/lockers";
import ActionForm from "@/components/ActionForm";
import FormDialog from "@/components/FormDialog";
import { EmptyState, Field, PageHeader } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { lockerItemHref } from "@/lib/lockerLabel";
import { listLockers, locateItem, lockerContents, type LocatedItem } from "@/lib/lockers";
import type { LockerDoc } from "@/lib/types";

export const metadata: Metadata = { title: "Lockers | Anusha Jewellers" };

const kindLabel = { stock: "Shop stock", order: "Customer order", pawn: "Pawned item" };

const filters = [
  { value: "all", label: "All" },
  { value: "order", label: "Orders" },
  { value: "pawn", label: "Pawning" },
  { value: "stock", label: "Shop stock" },
] as const;

export default async function LockersPage(props: PageProps<"/lockers">) {
  const sp = await props.searchParams;
  const find = typeof sp.find === "string" ? sp.find.trim() : "";
  const filter = filters.find((f) => f.value === sp.type)?.value ?? "all";
  const [allLockers, allContents, located, user] = await Promise.all([listLockers(), lockerContents(), find ? locateItem(find) : null, getCurrentUser()]);
  const isAdmin = user?.role === "admin";
  const contents = filter === "all" ? allContents : allContents.filter((c) => c.kind === filter);
  // A filtered view lists only the lockers holding that kind of item; "All" also shows empty ones.
  const lockers = filter === "all" ? allLockers : allLockers.filter((l) => contents.some((c) => c.locker === l._id));

  return (
    <>
      <PageHeader
        title="Lockers"
        subtitle="Name your safes, trays and display units, then assign each piece to one."
        actions={
          isAdmin && (
            <FormDialog label="+ Add locker" title="Add locker" width="sm">
              <LockerForm action={createLocker} submitLabel="Save locker" />
            </FormDialog>
          )
        }
      />

      <section className="card mb-5">
        <h2 className="card-title">Where is this item?</h2>
        <form className="flex flex-wrap gap-2">
          <input
            name="find"
            defaultValue={find}
            autoFocus
            autoComplete="off"
            className="input min-w-0 flex-1"
            placeholder="Enter or scan item number, e.g. ST000001, bill or pawn ticket number"
          />
          <button type="submit" className="btn-gold">Show location</button>
        </form>
        {find && <div className="mt-3"><Location query={find} item={located} /></div>}
      </section>

      <div className="mb-4 flex w-fit flex-wrap gap-1 rounded-lg bg-white p-1 ring-1 ring-slate-200">
        {filters.map((f) => {
          const count = f.value === "all" ? allContents.length : allContents.filter((c) => c.kind === f.value).length;
          return (
            <Link
              key={f.value}
              href={`/lockers?type=${f.value}${find ? `&find=${encodeURIComponent(find)}` : ""}`}
              className={`rounded-md px-4 py-2 text-sm font-medium ${filter === f.value ? "bg-ink text-canvas shadow-sm" : "text-ink hover:bg-canvas"}`}
            >
              {f.label} <span className="opacity-70">({count})</span>
            </Link>
          );
        })}
      </div>

      {allLockers.length === 0 ? (
        <EmptyState>No lockers yet. {isAdmin ? "Add one to start assigning storage locations." : "Ask an admin to add them."}</EmptyState>
      ) : lockers.length === 0 ? (
        <EmptyState>No {filters.find((f) => f.value === filter)?.label.toLowerCase()} items in any locker.</EmptyState>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {lockers.map((locker) => {
            const items = contents.filter((c) => c.locker === locker._id);
            return (
              <section key={locker._id} className="card">
                <div className="flex items-start justify-between gap-2">
                  <h2 className="text-base font-bold text-slate-900">{locker._id}</h2>
                  <span className="rounded-full bg-stone-100 px-2.5 py-0.5 text-xs font-semibold whitespace-nowrap text-stone-600 ring-1 ring-stone-300">
                    {items.length} item{items.length === 1 ? "" : "s"}
                  </span>
                </div>
                <p className="text-sm text-foreground/60">{locker.description || "No description"}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {items.length ? (
                    items.map((item) => (
                      <Link
                        key={`${item.kind}:${item.id}`}
                        href={lockerItemHref(item)}
                        title={`${kindLabel[item.kind]} · ${item.label}`}
                        className="rounded-md bg-canvas px-2 py-0.5 font-mono text-xs ring-1 ring-slate-200 hover:bg-amber-50 hover:ring-gold"
                      >
                        {item.ref}{item.slot && ` @ ${item.slot}`}
                      </Link>
                    ))
                  ) : (
                    <span className="text-sm text-foreground/50">Empty</span>
                  )}
                </div>
                {isAdmin && (
                  <div className="mt-3">
                    <FormDialog label="Edit" title={`Edit locker ${locker._id}`} width="sm" buttonClassName="btn-outline px-3 py-1 text-xs">
                      <LockerForm action={updateLocker.bind(null, locker._id)} locker={locker} submitLabel="Save locker" />
                      <div className="mt-4 border-t border-slate-200 pt-4">
                        {items.length ? (
                          <p className="text-xs text-foreground/50">Move the items out of this locker before deleting it.</p>
                        ) : (
                          <ActionForm
                            action={deleteLocker.bind(null, locker._id)}
                            submitLabel="Delete locker"
                            submitClassName="btn-danger px-3 py-1 text-xs"
                            confirmMessage={`Delete locker ${locker._id}?`}
                          >
                            {null}
                          </ActionForm>
                        )}
                      </div>
                    </FormDialog>
                  </div>
                )}
              </section>
            );
          })}
        </div>
      )}
    </>
  );
}

function LockerForm({ action, locker, submitLabel }: {
  action: Parameters<typeof ActionForm>[0]["action"];
  locker?: LockerDoc;
  submitLabel: string;
}) {
  return (
    <ActionForm action={action} submitLabel={submitLabel} submitClassName="btn-gold w-full">
      <Field label="Locker name *">
        <input name="name" className="input" required maxLength={40} defaultValue={locker?._id} placeholder="e.g. Safe A" />
      </Field>
      <Field label="Where is it? (description)">
        <input name="description" className="input" maxLength={120} defaultValue={locker?.description} placeholder="Back room, left wall, second shelf" />
      </Field>
    </ActionForm>
  );
}

/** Result of "Where is this item?": the locker in large type, like the label on the safe. */
function Location({ query, item }: { query: string; item: LocatedItem | null }) {
  if (!item) {
    return (
      <div className="rounded-xl border border-slate-200 bg-canvas px-4 py-3">
        <p className="font-bold">No item “{query}”</p>
        <p className="text-sm text-foreground/60">Check the number on the label and try again.</p>
      </div>
    );
  }
  return (
    <div className="space-y-2">
      <p className="text-sm">
        <Link href={lockerItemHref(item)} className="font-mono font-semibold text-ink underline">{item.ref}</Link>
        <span className="text-foreground/60"> · {kindLabel[item.kind]} · {item.label}</span>
      </p>
      {item.locker ? (
        <div className="flex flex-col gap-0.5 rounded-xl border-2 border-gold bg-amber-50 px-4 py-3">
          <span className="text-xs font-semibold text-foreground/60">Storage location</span>
          <span className="font-serif text-2xl leading-tight font-bold">{item.locker}</span>
          {item.description && <span>{item.description}</span>}
          {item.slot && <span className="font-bold">{item.slot}</span>}
        </div>
      ) : (
        <div className="rounded-xl border border-slate-200 bg-canvas px-4 py-3">
          <p className="font-bold">{item.gone ?? "No locker assigned"}</p>
          {!item.gone && <p className="text-sm text-foreground/60">Edit the item and choose a locker.</p>}
        </div>
      )}
    </div>
  );
}
