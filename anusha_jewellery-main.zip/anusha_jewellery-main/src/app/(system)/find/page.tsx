import type { Metadata } from "next";
import Link from "next/link";
import { StorageCard } from "@/components/pawns";
import { EmptyState, PageHeader, StatusBadge } from "@/components/ui";
import { getCategoryNames } from "@/lib/categories";
import { formatWeight } from "@/lib/format";
import { lockerLabel } from "@/lib/lockerLabel";
import { searchOrders } from "@/lib/orders";
import { searchPawns } from "@/lib/pawns";
import { searchStock } from "@/lib/stock";
import { StockTable } from "@/components/stock";

export const metadata: Metadata = { title: "Quick Finder | Anusha Jewellers" };

export default async function FindPage(props: PageProps<"/find">) {
  const categoryName = await getCategoryNames();
  const sp = await props.searchParams;
  const q = typeof sp.q === "string" ? sp.q.trim() : "";
  const [orders, pawns, stock] = await Promise.all([searchOrders(q), searchPawns(q), searchStock(q)]);

  return (
    <>
      <PageHeader title="Quick Finder" subtitle="Scan a barcode, or search by NIC, bill/ticket number, stock code, name, phone or locker" />
      <form className="card mb-6 flex flex-col gap-3 sm:flex-row">
        <input name="q" defaultValue={q} autoFocus className="input text-lg" placeholder="Scan or type here, then press Enter" />
        <button className="btn-primary px-6 text-base">Find</button>
      </form>

      {!q ? (
        <EmptyState>With a USB barcode scanner, just click the box and scan — it searches automatically.</EmptyState>
      ) : orders.length + pawns.length + stock.length === 0 ? (
        <EmptyState>Nothing found for “{q}”.</EmptyState>
      ) : (
        <div className="space-y-8">
          {stock.length > 0 && (
            <section>
              <h2 className="mb-3 font-bold text-lg text-ink">Shop stock</h2>
              <StockTable items={stock} />
            </section>
          )}
          {pawns.length > 0 && (
            <section>
              <h2 className="mb-3 font-bold text-lg text-ink">Pawned items</h2>
              <div className="grid gap-3 md:grid-cols-2">
                {pawns.map((pawn) => <StorageCard key={pawn._id.toString()} pawn={pawn} />)}
              </div>
            </section>
          )}
          {orders.length > 0 && (
            <section>
              <h2 className="mb-3 font-bold text-lg text-ink">Orders</h2>
              <div className="grid gap-3 md:grid-cols-2">
                {orders.map((order) => (
                  <Link
                    key={order._id.toString()}
                    href={`/orders/${order._id}`}
                    className="flex items-center gap-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition hover:shadow-md"
                  >
                    <div className={`rounded-xl px-4 py-3 text-center ${order.lockerCode ? "bg-ink text-canvas" : "bg-stone-200 text-stone-600"}`}>
                      <p className="text-[10px] tracking-widest uppercase opacity-80">Locker</p>
                      <p className="font-bold text-2xl">{lockerLabel(order.lockerCode, order.lockerSlot) ?? "—"}</p>
                    </div>
                    <div className="min-w-0">
                      <p className="flex items-center gap-2 font-semibold text-ink">
                        Bill {order.billNo} <StatusBadge status={order.status} />
                      </p>
                      <p className="truncate font-medium">{order.customer.name}</p>
                      <p className="text-sm text-foreground/60">
                        {categoryName(order.category)} · {formatWeight(order.completion?.finalWeightMg ?? order.weightMg)}
                        {order.barcode && ` · ${order.barcode}`}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </>
  );
}
