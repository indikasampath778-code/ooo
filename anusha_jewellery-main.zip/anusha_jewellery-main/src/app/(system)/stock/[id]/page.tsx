import type { Metadata } from "next";
import StockItemView from "@/components/StockItemView";

export const metadata: Metadata = { title: "Stock Item | Anusha Jewellers" };

export default async function StockItemPage(props: PageProps<"/stock/[id]">) {
  const { id } = await props.params;
  const { created } = await props.searchParams;
  return <StockItemView id={id} created={Boolean(created)} />;
}
