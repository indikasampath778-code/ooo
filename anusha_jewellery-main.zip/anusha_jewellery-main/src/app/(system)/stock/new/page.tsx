import type { Metadata } from "next";
import { createStockItem } from "@/app/actions/stock";
import ActionForm from "@/components/ActionForm";
import { StockFields } from "@/components/stock";
import { PageHeader } from "@/components/ui";
import { requireUser } from "@/lib/auth";

export const metadata: Metadata = { title: "Add Stock Item | Anusha Jewellers" };

export default async function NewStockItemPage() {
  await requireUser();
  return (
    <>
      <PageHeader title="Add Stock Item" />
      <div className="card">
        <ActionForm action={createStockItem} submitLabel="Save item & generate barcode" submitClassName="btn-primary px-8">
          <StockFields wide />
        </ActionForm>
      </div>
    </>
  );
}
