// Returning to /stock (close, save that redirects, delete) closes the popup.
export default function NoModal() {
  return null;
}
