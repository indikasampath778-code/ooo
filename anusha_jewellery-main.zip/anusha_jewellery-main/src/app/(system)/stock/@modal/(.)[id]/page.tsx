import RouteModal from "@/components/RouteModal";
import StockItemView from "@/components/StockItemView";

/** A stock item opened from the Shop Stock list shows in a popup; its own URL still opens the full page. */
export default async function StockItemModal(props: PageProps<"/stock/[id]">) {
  // The intercepted route's param can arrive with Next's "(.)" marker still on it.
  const id = (await props.params).id.replace(/^(\(\.\))+/, "");
  const { created } = await props.searchParams;
  return (
    <RouteModal>
      <StockItemView id={id} created={Boolean(created)} />
    </RouteModal>
  );
}
