// No popup unless a stock item was opened from the list.
export default function Default() {
  return null;
}
