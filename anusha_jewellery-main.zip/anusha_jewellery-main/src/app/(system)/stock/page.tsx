import type { Metadata } from "next";
import Link from "next/link";
import { createStockItem } from "@/app/actions/stock";
import ActionForm from "@/components/ActionForm";
import FilterSelect from "@/components/FilterSelect";
import FormDialog from "@/components/FormDialog";
import SearchBox from "@/components/SearchBox";
import { StockFields, StockTable } from "@/components/stock";
import { PageHeader, Stat } from "@/components/ui";
import { KARATS } from "@/lib/constants";
import { formatMoney, formatWeight } from "@/lib/format";
import { readCartIds } from "@/lib/cart";
import { getCategories } from "@/lib/categories";
import { listStock, readStockFilters, STOCK_STATUSES, stockStats } from "@/lib/stock";

export const metadata: Metadata = { title: "Shop Stock | Anusha Jewellers" };

export default async function StockPage(props: PageProps<"/stock">) {
  const sp = await props.searchParams;
  const { status, karat, category, q } = readStockFilters(sp);
  const [stats, items, cartIds, categories] = await Promise.all([
    stockStats(),
    listStock(status, q, karat, category),
    readCartIds(),
    getCategories(),
  ]);
  // "Print labels (filtered)" prints exactly the list on screen.
  const filterQuery = new URLSearchParams({
    ...(category && { category }),
    ...(status !== "in_stock" && { status }),
    ...(karat && { karat: String(karat) }),
    ...(q && { q }),
  }).toString();

  return (
    <>
      <PageHeader
        title="Shop Stock"
        actions={
          <>
            <Link href="/billing?type=stock" className="btn-primary">Cart ({cartIds.length}) · Checkout</Link>
            <Link href={`/print/labels/stock${filterQuery ? `?${filterQuery}` : ""}`} className="btn-outline">Print labels (filtered)</Link>
            <FormDialog label="Add item" title="Add Stock Item">
              <ActionForm action={createStockItem} submitLabel="Save item & generate barcode" submitClassName="btn-primary px-8">
                <StockFields wide />
              </ActionForm>
            </FormDialog>
          </>
        }
      />

      <div className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat
          label="Items in stock"
          value={stats.count}
          tone="ink"
          hint={`Total ${formatWeight(stats.weightMg)}${stats.reservedCount ? ` · ${stats.reservedCount} reserved` : ""}`}
        />
        <Stat label="Stock value" value={formatMoney(stats.value)} hint={stats.valueAtRate ? "At today's gold rate" : "At selling price"} />
        <Stat label="Sold today" value={stats.soldTodayCount} />
        <Stat
          label="Sales today"
          value={formatMoney(stats.soldTodayValue)}
          hint={
            stats.oldGoldTodayMg
              ? `Received ${formatMoney(stats.paidToday)} + old gold ${formatWeight(stats.oldGoldTodayMg)} (${formatMoney(stats.oldGoldTodayValue)})`
              : stats.paidToday
                ? `Received ${formatMoney(stats.paidToday)} incl. reservation payments`
                : undefined
          }
        />
      </div>

      <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="flex flex-wrap items-center gap-3 border-b border-slate-200 p-4">
          <SearchBox placeholder="Scan barcode, or search item no., name, locker or buyer…" className="min-w-60 flex-1" />
          <FilterSelect name="category" allLabel="All categories" options={categories.map((c) => ({ value: c.code, label: c.name }))} />
          <FilterSelect name="status" options={STOCK_STATUSES} defaultValue="in_stock" />
          <FilterSelect name="karat" allLabel="All karats" options={KARATS.map((k) => ({ value: String(k), label: `${k}K` }))} />
        </div>
        {items.length ? (
          <StockTable items={items} bare cartIds={cartIds} editable />
        ) : (
          <p className="p-10 text-center text-sm text-foreground/60">
            {q ? `Nothing found for “${q}”.` : "No items match these filters."}
          </p>
        )}
      </section>
    </>
  );
}
