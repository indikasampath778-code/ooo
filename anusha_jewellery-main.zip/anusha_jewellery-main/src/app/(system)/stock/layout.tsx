/** Shop Stock screens, plus the slot where a stock item opens as a popup over the list. */
export default function StockLayout({ children, modal }: LayoutProps<"/stock">) {
  return (
    <>
      {children}
      {modal}
    </>
  );
}
