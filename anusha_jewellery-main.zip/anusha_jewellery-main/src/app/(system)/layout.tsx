import type { ReactNode } from "react";
import Link from "next/link";
import { logout } from "@/app/actions/auth";
import GoldRatesBar from "@/components/GoldRatesBar";
import Logo from "@/components/Logo";
import NavLinks from "@/components/NavLinks";
import { requireUser } from "@/lib/auth";
import { SHOP } from "@/lib/constants";
import { formatDate, todayISO } from "@/lib/format";
import { getLatestGoldRates } from "@/lib/rates";

export default async function SystemLayout({ children }: { children: ReactNode }) {
  const user = await requireUser();
  const isAdmin = user.role === "admin";
  const rates = await getLatestGoldRates();
  return (
    <div className="flex min-h-screen flex-col">
      <header className="no-print sticky top-0 z-40 border-b border-gold/40 bg-slate-900 text-white shadow-lg">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-x-6 gap-y-3 px-4 py-3 sm:px-6 lg:px-8">
          <Link href="/dashboard" aria-label={SHOP.name}>
            <Logo className="h-14 w-auto text-gold" />
          </Link>

          <form
            action="/find"
            className="order-last flex w-full items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/90 px-3 py-2 lg:order-none lg:w-auto lg:flex-1 lg:max-w-xl"
          >
            <span className="flex items-center gap-1 border-r border-slate-700 pr-2 text-xs font-semibold whitespace-nowrap text-amber-400">
              <span className="inline-block size-2 animate-pulse rounded-full bg-emerald-400" />
              {formatDate(todayISO())}
            </span>
            <input
              name="q"
              className="w-full bg-transparent px-1 text-xs text-white outline-none placeholder:text-slate-500"
              placeholder="Scan barcode or search bill no, NIC, name, phone, locker…"
              aria-label="Quick finder"
            />
            <button className="rounded-lg bg-gold px-2.5 py-1 text-xs font-bold text-slate-950 shadow transition hover:bg-amber-500">
              Find
            </button>
          </form>

          <GoldRatesBar
            rates={rates && { rate24: rates.rate24, rate22: rates.rate22, rate18: rates.rate18 }}
            setOn={rates && formatDate(rates._id)}
            isToday={rates?._id === todayISO()}
            canEdit={isAdmin}
          />

          <div className="flex items-center gap-3">
            <div className="text-xs font-bold text-white capitalize">{user.name}</div>
            <form action={logout}>
              <button className="flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-700 hover:text-white">
                ⏻ <span className="hidden sm:inline">Log out</span>
              </button>
            </form>
          </div>
        </div>

        <nav className="overflow-x-auto border-t border-slate-800 bg-slate-950">
          <NavLinks isAdmin={isAdmin} />
        </nav>
      </header>

      <main className="mx-auto w-full max-w-7xl flex-1 p-4 sm:p-6 lg:p-8">{children}</main>
    </div>
  );
}
