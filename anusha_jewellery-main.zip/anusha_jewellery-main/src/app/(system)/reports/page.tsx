import type { Metadata } from "next";
import Link from "next/link";
import { EmptyState, Field, PageHeader } from "@/components/ui";
import { formatDate, todayISO } from "@/lib/format";
import { monthEnds, readReportRange, REPORT_KINDS, reportTable, stockOnDate, stockReport, type ReportKind } from "@/lib/reports";

export const metadata: Metadata = { title: "Reports | Anusha Jewellers" };

const views = [
  { value: "onhand", label: "Stock on a date" },
  { value: "movement", label: "Stock movement (date range)" },
] as const;

export default async function ReportsPage(props: PageProps<"/reports">) {
  const { view, date, from, to, kind } = readReportRange(await props.searchParams);
  const type: Record<string, string> = kind ? { type: kind } : {};
  const query = new URLSearchParams(view === "onhand" ? { date, ...type } : { view, from, to, ...type }).toString();

  return (
    <>
      <PageHeader
        title="Stock Report"
        subtitle={
          view === "onhand"
            ? "Everything that was in stock at the end of the chosen day, by category and item."
            : "Opening stock, items in and out, and closing stock in each category for the chosen dates."
        }
        actions={<a href={`/reports/pdf?${query}`} className="btn-gold">Download PDF</a>}
      />

      <div className="mb-4 flex w-fit flex-wrap gap-1 rounded-lg bg-white p-1 ring-1 ring-slate-200">
        {views.map((v) => (
          <Link
            key={v.value}
            href={`/reports?${new URLSearchParams(v.value === "movement" ? { view: v.value, ...type } : type)}`}
            className={`rounded-md px-4 py-2 text-sm font-medium ${view === v.value ? "bg-ink text-canvas shadow-sm" : "text-ink hover:bg-canvas"}`}
          >
            {v.label}
          </Link>
        ))}
      </div>

      {view === "onhand" ? <OnHandReport date={date} kind={kind} /> : <MovementReport from={from} to={to} kind={kind} />}
    </>
  );
}

function KindSelect({ kind }: { kind: ReportKind | null }) {
  return (
    <Field label="Report">
      <select name="type" defaultValue={kind ?? ""} className="input">
        <option value="">All (shop stock, pawning, orders)</option>
        {REPORT_KINDS.map((k) => (
          <option key={k.value} value={k.value}>{k.label}</option>
        ))}
      </select>
    </Field>
  );
}

function ReportTable({ headers, groups, rows, total }: {
  headers: string[];
  groups?: { label: string; span: number }[];
  rows: string[][];
  total?: string[];
}) {
  return (
    <div className="overflow-x-auto">
      <table className="table">
        <thead>
          {groups && (
            <tr>
              <th rowSpan={2}>{headers[0]}</th>
              {groups.map((g) => (
                <th key={g.label} colSpan={g.span} className="border-l border-slate-200 text-center">{g.label}</th>
              ))}
            </tr>
          )}
          <tr>
            {(groups ? headers.slice(1) : headers).map((h, i) => (
              <th key={i} className={!groups && i === 0 ? "" : "whitespace-nowrap"}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, r) => (
            <tr key={r}>
              {row.map((cell, i) => (
                <td key={i} className={i === 0 ? "font-medium" : "whitespace-nowrap"}>{cell}</td>
              ))}
            </tr>
          ))}
          {total && (
            <tr className="bg-canvas font-bold">
              {total.map((cell, i) => <td key={i} className="whitespace-nowrap">{cell}</td>)}
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

async function OnHandReport({ date, kind }: { date: string; kind: ReportKind | null }) {
  const sections = await stockOnDate(date, kind);
  const { lastMonth, thisMonth } = monthEnds(todayISO());
  const quick = (label: string, iso: string) => (
    <Link
      href={`/reports?${new URLSearchParams({ date: iso, ...(kind && { type: kind }) })}`}
      className={`btn-outline px-3 py-1.5 text-xs ${date === iso ? "ring-2 ring-gold" : ""}`}
    >
      {label}
    </Link>
  );

  return (
    <>
      <form className="card mb-5 flex flex-wrap items-end gap-3">
        <Field label="Stock at the end of">
          <input type="date" name="date" defaultValue={date} className="input" required />
        </Field>
        <KindSelect kind={kind} />
        <button type="submit" className="btn-primary">Show report</button>
        <div className="flex flex-wrap gap-2">
          {quick("Today", todayISO())}
          {quick("End of last month", lastMonth)}
          {quick("End of this month", thisMonth)}
        </div>
      </form>

      <p className="mb-3 text-sm text-foreground/60">Stock at the end of {formatDate(date)}</p>

      <div className="space-y-5">
        {sections.map((s) => (
          <section key={s.kind} className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <h2 className="border-b border-slate-200 px-4 py-3 text-sm font-bold text-slate-800">
              {s.title} <span className="font-normal text-foreground/60">· {s.items.rows.length} item{s.items.rows.length === 1 ? "" : "s"}</span>
            </h2>
            {s.items.rows.length === 0 ? (
              <div className="p-4"><EmptyState>No {s.title.toLowerCase()} on hand on this date.</EmptyState></div>
            ) : (
              <>
                <ReportTable headers={s.summary.headers} rows={s.summary.rows} total={s.summary.total} />
                <details className="border-t border-slate-200">
                  <summary className="cursor-pointer px-4 py-3 text-sm font-semibold text-ink">Show all {s.items.rows.length} items</summary>
                  <ReportTable headers={s.items.headers} rows={s.items.rows} />
                </details>
              </>
            )}
          </section>
        ))}
      </div>
    </>
  );
}

async function MovementReport({ from, to, kind }: { from: string; to: string; kind: ReportKind | null }) {
  const sections = await stockReport(from, to, kind);
  return (
    <>
      <form className="card mb-5 flex flex-wrap items-end gap-3">
        <input type="hidden" name="view" value="movement" />
        <Field label="From">
          <input type="date" name="from" defaultValue={from} className="input" required />
        </Field>
        <Field label="To">
          <input type="date" name="to" defaultValue={to} className="input" required />
        </Field>
        <KindSelect kind={kind} />
        <button type="submit" className="btn-primary">Show report</button>
      </form>

      <p className="mb-3 text-sm text-foreground/60">{formatDate(from)} to {formatDate(to)}</p>

      <div className="space-y-5">
        {sections.map((section) => {
          const table = reportTable(section);
          return (
            <section key={section.kind} className="rounded-2xl border border-slate-200 bg-white shadow-sm">
              <h2 className="border-b border-slate-200 px-4 py-3 text-sm font-bold text-slate-800">{table.title}</h2>
              {section.rows.length === 0 ? (
                <div className="p-4"><EmptyState>No {table.title.toLowerCase()} in these dates.</EmptyState></div>
              ) : (
                <ReportTable headers={table.headers} groups={table.groups} rows={table.rows} total={table.total} />
              )}
            </section>
          );
        })}
      </div>
    </>
  );
}
