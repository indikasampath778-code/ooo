import { jsPDF } from "jspdf";
import { autoTable, type RowInput } from "jspdf-autotable";
import type { NextRequest } from "next/server";
import { SHOP } from "@/lib/constants";
import { formatDate, formatDateTime } from "@/lib/format";
import { readReportRange, reportTable, stockOnDate, stockReport } from "@/lib/reports";

/** The Stock Report as a downloadable A4 landscape PDF, for the same view, dates and type as the page. */
export async function GET(request: NextRequest) {
  const { view, date, from, to, kind } = readReportRange(Object.fromEntries(request.nextUrl.searchParams));

  const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.text(SHOP.name, 14, 16);
  doc.setFontSize(12);
  doc.text(view === "onhand" ? `Stock at the end of ${formatDate(date)}` : "Stock movement - category wise", 14, 23);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  const period = view === "onhand" ? "" : `${formatDate(from)} to ${formatDate(to)}    |    `;
  doc.text(`${period}Generated ${formatDateTime(new Date())}`, 14, 29);

  let y = 36;
  /** Heading plus a table; starts a new page when there's no room left for the heading. */
  const section = (title: string, head: RowInput[], body: RowInput[], foot?: RowInput[]) => {
    if (y > 180) {
      doc.addPage();
      y = 16;
    }
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.text(title, 14, y);
    autoTable(doc, {
      startY: y + 2,
      head,
      body,
      foot,
      theme: "grid",
      styles: { fontSize: 8, cellPadding: 1.5 },
      headStyles: { fillColor: [30, 41, 59], textColor: 255 },
      footStyles: { fillColor: [241, 245, 249], textColor: 20, fontStyle: "bold" },
      margin: { left: 14, right: 14 },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;
  };
  const none = (text: string, span: number): RowInput[] => [[{ content: text, colSpan: span }]];

  if (view === "onhand") {
    for (const s of await stockOnDate(date, kind)) {
      const empty = s.items.rows.length === 0;
      section(`${s.title} - by category`, [s.summary.headers], empty ? none("Nothing on hand on this date", s.summary.headers.length) : s.summary.rows, empty ? undefined : [s.summary.total]);
      if (!empty) section(`${s.title} - ${s.items.rows.length} item${s.items.rows.length === 1 ? "" : "s"}`, [s.items.headers], s.items.rows);
    }
  } else {
    for (const s of await stockReport(from, to, kind)) {
      const table = reportTable(s);
      const head: RowInput[] = [
        [{ content: "Category", rowSpan: 2 }, ...table.groups.map((g) => ({ content: g.label, colSpan: g.span, styles: { halign: "center" as const } }))],
        table.headers.slice(1),
      ];
      const empty = table.rows.length === 0;
      section(table.title, head, empty ? none("No items in these dates", table.headers.length) : table.rows, empty ? undefined : [table.total]);
    }
  }

  const name = view === "onhand" ? `stock-on-${date}${kind ? `_${kind}` : ""}.pdf` : `stock-movement_${from}_to_${to}${kind ? `_${kind}` : ""}.pdf`;
  return new Response(doc.output("arraybuffer"), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${name}"`,
      "Cache-Control": "no-store",
    },
  });
}
