import type { Metadata } from "next";
import Link from "next/link";
import FormDialog from "@/components/FormDialog";
import NewPawnForm from "@/components/NewPawnForm";
import { PawnsTable, StorageCard } from "@/components/pawns";
import { PageHeader, Stat } from "@/components/ui";
import { formatMoney, formatWeight } from "@/lib/format";
import { listPawns, pawnStock } from "@/lib/pawns";

export const metadata: Metadata = { title: "Pawning | Anusha Jewellers" };

const tabs = [
  { value: "active", label: "In stock" },
  { value: "released", label: "Released" },
  { value: "all", label: "All" },
] as const;

export default async function PawningPage(props: PageProps<"/pawning">) {
  const sp = await props.searchParams;
  const status = tabs.find((t) => t.value === sp.status)?.value ?? "active";
  const q = typeof sp.q === "string" ? sp.q.trim() : "";
  const [stock, pawns] = await Promise.all([pawnStock(), listPawns(q ? "all" : status, q)]);

  return (
    <>
      <PageHeader
        title="Pawning"
        actions={
          <FormDialog label="+ New Pawn" title="New Pawn" buttonClassName="btn-primary">
            <NewPawnForm />
          </FormDialog>
        }
      />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Items in stock" value={stock.count} tone="ink" />
        <Stat label="Total principal" value={formatMoney(stock.principal)} hint={`Assessed ${formatMoney(stock.assessed)}`} />
        <Stat label="Accrued interest" value={formatMoney(stock.interest)} hint="Unpaid, as of today" />
        <Stat
          label="Net gold weight"
          value={formatWeight(stock.netWeightMg)}
          hint={Object.entries(stock.byStandard).map(([s, v]) => `${s}: ${formatWeight(v.netWeightMg)}`).join(" · ") || undefined}
        />
      </div>

      <section className="card mt-5">
        <h2 className="card-title">Quick Storage Finder</h2>
        <form className="flex flex-col gap-3 sm:flex-row">
          <input
            name="q"
            defaultValue={q}
            autoFocus
            className="input text-lg"
            placeholder="Scan barcode, or enter NIC, ticket/bill number, name or locker"
          />
          <button className="btn-primary px-6 text-base">Find</button>
          {q && <Link href="/pawning" className="btn-outline">Clear</Link>}
        </form>
        {q && (
          <div className="mt-4 grid gap-3 md:grid-cols-2">
            {pawns.length ? (
              pawns.slice(0, 6).map((pawn) => <StorageCard key={pawn._id.toString()} pawn={pawn} />)
            ) : (
              <p className="text-sm text-foreground/60">Nothing found for “{q}”.</p>
            )}
          </div>
        )}
      </section>

      {!q && (
        <section className="mt-5 rounded-2xl border border-slate-200 bg-white shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-4">
            <h2 className="font-bold text-lg text-ink">Pawned items</h2>
            <div className="flex gap-1 rounded-lg bg-canvas p-1">
              {tabs.map((tab) => (
                <Link
                  key={tab.value}
                  href={`/pawning?status=${tab.value}`}
                  className={`rounded-md px-3 py-1.5 text-sm font-medium ${status === tab.value ? "bg-ink text-canvas shadow-sm" : "text-ink hover:bg-white"}`}
                >
                  {tab.label}
                </Link>
              ))}
            </div>
          </div>
          {pawns.length ? (
            <PawnsTable pawns={pawns} bare />
          ) : (
            <p className="p-10 text-center text-sm text-foreground/60">No pawned items here yet.</p>
          )}
        </section>
      )}
    </>
  );
}
