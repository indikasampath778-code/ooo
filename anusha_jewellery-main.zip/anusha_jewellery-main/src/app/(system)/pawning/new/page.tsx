import type { Metadata } from "next";
import NewPawnForm from "@/components/NewPawnForm";
import { PageHeader } from "@/components/ui";

export const metadata: Metadata = { title: "New Pawn | Anusha Jewellers" };

export default function NewPawnPage() {
  return (
    <>
      <PageHeader title="New Pawn" />
      <div className="card max-w-3xl">
        <NewPawnForm />
      </div>
    </>
  );
}
