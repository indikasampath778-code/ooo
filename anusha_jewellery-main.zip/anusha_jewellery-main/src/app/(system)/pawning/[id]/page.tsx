import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import Barcode from "@/components/Barcode";
import LabelPrintButton from "@/components/LabelPrintButton";
import { Row } from "@/components/pawnPayments";
import { Accordion, Detail, PageHeader, Pill } from "@/components/ui";
import { payMethodLabel } from "@/lib/constants";
import { getCategoryNames } from "@/lib/categories";
import { formatDate, formatDateTime, formatDuration, formatMoney, formatWeight, todayISO } from "@/lib/format";
import { lockerLabel } from "@/lib/lockerLabel";
import { getPawn, pawnFigures } from "@/lib/pawns";

export const metadata: Metadata = { title: "Pawn | Anusha Jewellers" };

export default async function PawnPage(props: PageProps<"/pawning/[id]">) {
  const categoryName = await getCategoryNames();
  const { id } = await props.params;
  const { created } = await props.searchParams;
  const pawn = await getPawn(id);
  if (!pawn) notFound();

  const f = pawnFigures(pawn);
  const active = pawn.status === "active";

  return (
    <>
      <PageHeader
        title={`Pawn ${pawn.ticketNo}`}
        subtitle={`Pawned ${formatDate(pawn.pawnDate)}`}
        actions={
          <>
            <LabelPrintButton kind="pawn" id={id} />
            <a href={`/print/pawn-ticket/${id}`} className="btn-outline">Print pawn ticket</a>
          </>
        }
      />

      {created && (
        <p className="mb-6 rounded-xl border border-emerald-300 bg-emerald-50 p-4 text-sm font-medium text-emerald-800">
          Pawn saved. Store the item in locker <strong>{lockerLabel(pawn.lockerCode, pawn.lockerSlot)}</strong>, then print the barcode label for the bag and the ticket for the customer.
        </p>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <section className="card">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <h2 className="card-title">Customer &amp; item</h2>
              {active ? <Pill tone="green">In stock</Pill> : <Pill tone="gray">Released {formatDateTime(pawn.releasedAt)}</Pill>}
            </div>
            <dl className="grid gap-4 sm:grid-cols-3">
              <Detail label="Customer">{pawn.customer.name}</Detail>
              <Detail label="NIC">{pawn.customer.nic}</Detail>
              <Detail label="Phone"><a href={`tel:${pawn.customer.phone}`} className="underline">{pawn.customer.phone}</a></Detail>
              <Detail label="Address">{pawn.customer.address}</Detail>
              <Detail label="Item">{categoryName(pawn.category)} ({pawn.category})</Detail>
              <Detail label="Standard">{pawn.standard}</Detail>
              <Detail label="Gross weight">{formatWeight(pawn.grossWeightMg)}</Detail>
              <Detail label="Net weight">{formatWeight(pawn.netWeightMg)}</Detail>
              <Detail label="Assessed value">{formatMoney(pawn.assessedValue)}</Detail>
              <Detail label="Loan amount">{formatMoney(pawn.loanAmount ?? pawn.principal)}</Detail>
              <Detail label="Loan balance">{formatMoney(pawn.principal)}</Detail>
              <Detail label="Monthly interest">{pawn.monthlyRate}%</Detail>
              <Detail label="Duration">{formatDuration(pawn.durationMonths, pawn.durationDays)}</Detail>
              <Detail label="Due date">
                {pawn.dueDate ? (
                  <span className={active && pawn.dueDate < todayISO() ? "font-bold text-red-700" : ""}>
                    {formatDate(pawn.dueDate)}{active && pawn.dueDate < todayISO() && " (overdue)"}
                  </span>
                ) : "—"}
              </Detail>
              <Detail label="Renewals">{pawn.renewals}</Detail>
            </dl>
            {pawn.notes && <p className="mt-4 rounded-lg bg-canvas p-3 text-sm whitespace-pre-line">{pawn.notes}</p>}
          </section>

          <section className="card">
            <h2 className="card-title">Storage</h2>
            <div className="flex flex-wrap items-center gap-6">
              <div className={`rounded-xl px-6 py-4 text-center ${active ? "bg-ink text-canvas" : "bg-stone-200 text-stone-600"}`}>
                <p className="text-xs tracking-widest uppercase opacity-80">Locker</p>
                <p className="font-bold text-3xl">{lockerLabel(pawn.lockerCode, pawn.lockerSlot)}</p>
                {!active && <p className="text-xs">now available</p>}
              </div>
              <div className="text-center">
                <Barcode value={pawn.ticketNo} className="h-14 w-56" />
                <p className="mt-1 font-mono text-sm">{pawn.ticketNo}</p>
              </div>
            </div>
          </section>

          <section className="card">
            <h2 className="card-title">Payment history</h2>
            {pawn.payments.length === 0 ? (
              <p className="text-sm text-foreground/50">No payments yet.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="table">
                  <thead>
                    <tr><th>Receipt</th><th>Type</th><th>Period</th><th className="text-right">Interest</th><th className="text-right">Principal</th><th className="text-right">Total</th><th>Paid</th></tr>
                  </thead>
                  <tbody>
                    {pawn.payments.map((p) => (
                      <tr key={p.receiptNo}>
                        <td><a href={`/print/receipt/${p.receiptNo}`} className="font-semibold text-ink underline">{p.receiptNo}</a></td>
                        <td>{{ interest: "Interest / renewal", installment: "Installment", settlement: "Full settlement" }[p.type]}</td>
                        <td className="whitespace-nowrap">{formatDate(p.periodFrom)} → {formatDate(p.periodTo)} ({p.days}d)</td>
                        <td className="text-right whitespace-nowrap">{formatMoney(p.interest)}</td>
                        <td className="text-right whitespace-nowrap">{formatMoney(p.principal)}</td>
                        <td className="text-right font-semibold whitespace-nowrap">{formatMoney(p.amount)}</td>
                        <td className="whitespace-nowrap">{formatDateTime(p.paidAt)} · {payMethodLabel(p.method)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </div>

        <div className="space-y-4">
          <Accordion
            title="Interest today"
            summary={<span className="text-sm font-semibold text-ink">{formatMoney(f.accruedInterest)}</span>}
          >
            <dl className="space-y-2 text-sm">
              <Row label="Days elapsed (since pawned)" value={active ? `${f.daysElapsed} days` : "—"} />
              <Row label="Unpaid interest from" value={formatDate(f.interestFrom)} />
              <Row label="Unpaid days" value={active ? `${f.interestDays} days` : "—"} />
              <Row label="Accrued interest" value={formatMoney(f.accruedInterest)} strong />
              <Row label="Interest paid so far" value={formatMoney(f.interestPaid)} />
            </dl>
            <p className="mt-3 text-xs text-foreground/50">
              {pawn.monthlyRate}% per month on {formatMoney(pawn.principal)}, charged per day (30-day month).
            </p>
          </Accordion>

          {!active && pawn.payments.length > 0 && (
            <section className="card">
              <h2 className="card-title">Settled &amp; released</h2>
              <a href={`/print/receipt/${pawn.payments.at(-1)!.receiptNo}`} className="btn-primary w-full">
                Print settlement receipt ({pawn.payments.at(-1)!.receiptNo})
              </a>
            </section>
          )}

          {active && (
            <section className="card space-y-3">
              <h2 className="card-title mb-0">Payments</h2>
              <p className="text-sm text-foreground/70">Interest, installments and full settlement are taken in Billing.</p>
              <Link href={`/billing?type=pawn&id=${id}`} className="btn-gold w-full">
                Open in Billing · {formatMoney(f.settlementAmount)} to settle
              </Link>
            </section>
          )}
        </div>
      </div>
    </>
  );
}

