import type { Metadata } from "next";
import Link from "next/link";
import {
  createCategory,
  createMaker,
  createUser,
  deletePawn,
  deleteCategory,
  deleteMaker,
  deleteUser,
  updateCategory,
  updateMaker,
  updatePawn,
  updateUser,
} from "@/app/actions/settings";
import ActionForm from "@/components/ActionForm";
import { Field, PageHeader, Pill } from "@/components/ui";
import WeightInput from "@/components/WeightInput";
import { requireAdmin, type CurrentUser } from "@/lib/auth";
import { getCategories, getCategoryNames } from "@/lib/categories";
import { PAWN_STANDARDS, USER_ROLES } from "@/lib/constants";
import { getDb } from "@/lib/db";
import { formatDate, formatDateTime, formatMoney, formatWeight } from "@/lib/format";
import { lockerLabel } from "@/lib/lockerLabel";
import { getMakers, type Maker } from "@/lib/makers";
import { getPawn, listPawns } from "@/lib/pawns";

export const metadata: Metadata = { title: "Settings | Anusha Jewellers" };

const tabs = [
  { value: "categories", label: "Item categories" },
  { value: "makers", label: "Item makers" },
  { value: "pawns", label: "Pawned items" },
  { value: "users", label: "Users" },
] as const;

export default async function SettingsPage(props: PageProps<"/settings">) {
  const me = await requireAdmin();
  const sp = await props.searchParams;
  const tab = tabs.find((t) => t.value === sp.tab)?.value ?? "categories";

  return (
    <>
      <PageHeader title="Settings" />
      <div className="mb-5 flex w-fit flex-wrap gap-1 rounded-lg bg-white p-1 ring-1 ring-slate-200">
        {tabs.map((t) => (
          <Link
            key={t.value}
            href={`/settings?tab=${t.value}`}
            className={`rounded-md px-4 py-2 text-sm font-medium ${tab === t.value ? "bg-ink text-canvas shadow-sm" : "text-ink hover:bg-canvas"}`}
          >
            {t.label}
          </Link>
        ))}
      </div>
      {tab === "categories" && <CategoriesTab />}
      {tab === "makers" && <MakersTab />}
      {tab === "pawns" && <PawnsTab q={typeof sp.q === "string" ? sp.q.trim() : ""} editId={typeof sp.edit === "string" ? sp.edit : ""} />}
      {tab === "users" && <UsersTab me={me} />}
    </>
  );
}

/** Small inline "Edit" toggle used inside table rows. */
function EditToggle({ label = "Edit", children }: { label?: string; children: React.ReactNode }) {
  return (
    <details className="group">
      <summary className="btn-outline cursor-pointer list-none px-3 py-1 text-xs [&::-webkit-details-marker]:hidden">{label}</summary>
      <div className="mt-2 w-72 rounded-xl border border-slate-200 bg-canvas/60 p-3">{children}</div>
    </details>
  );
}

function DeleteButton({ action, confirm, disabled }: { action: () => Promise<{ error?: string; success?: string }>; confirm: string; disabled?: boolean }) {
  if (disabled) return <span className="text-xs text-foreground/40">In use</span>;
  return (
    <ActionForm action={action} submitLabel="Delete" submitClassName="btn-danger px-3 py-1 text-xs" className="space-y-2" confirmMessage={confirm}>
      {null}
    </ActionForm>
  );
}

/* ---------------- Item categories ---------------- */

async function CategoriesTab() {
  const { orders, pawns, stock } = await getDb();
  const [categories, orderUse, pawnUse, stockUse] = await Promise.all([
    getCategories(),
    orders.aggregate<{ _id: string; n: number }>([{ $group: { _id: "$category", n: { $sum: 1 } } }]).toArray(),
    pawns.aggregate<{ _id: string; n: number }>([{ $group: { _id: "$category", n: { $sum: 1 } } }]).toArray(),
    stock.aggregate<{ _id: string; n: number }>([{ $group: { _id: "$category", n: { $sum: 1 } } }]).toArray(),
  ]);
  const count = (list: { _id: string; n: number }[], code: string) => list.find((x) => x._id === code)?.n ?? 0;

  return (
    <div className="grid gap-5 lg:grid-cols-3">
      <section className="card h-fit">
        <h2 className="card-title">Add category</h2>
        <ActionForm action={createCategory} submitLabel="Add category" submitClassName="btn-primary w-full">
          <Field label="Name">
            <input name="name" className="input" required placeholder="e.g. Nose Pin" />
          </Field>
          <Field label="Code (2–4 letters)">
            <input name="code" className="input uppercase" required maxLength={4} placeholder="e.g. NOS" />
          </Field>
          <p className="text-xs text-foreground/50">The code can&apos;t be changed later.</p>
        </ActionForm>
      </section>

      <section className="rounded-2xl border border-slate-200 bg-white shadow-sm lg:col-span-2">
        <table className="table">
          <thead>
            <tr><th>Code</th><th>Name</th><th>Used by</th><th className="text-right">Actions</th></tr>
          </thead>
          <tbody>
            {categories.map((c) => {
              const used = { o: count(orderUse, c.code), p: count(pawnUse, c.code), s: count(stockUse, c.code) };
              return (
                <tr key={c.code}>
                  <td className="font-bold text-ink">{c.code}</td>
                  <td className="font-medium">{c.name}</td>
                  <td className="text-xs text-foreground/60">{used.o} orders · {used.p} pawns · {used.s} stock</td>
                  <td>
                    <div className="flex items-start justify-end gap-2">
                      <EditToggle>
                        <ActionForm action={updateCategory.bind(null, c.code)} submitLabel="Save" submitClassName="btn-primary w-full" className="space-y-3">
                          <Field label="Name"><input name="name" className="input" defaultValue={c.name} required /></Field>
                        </ActionForm>
                      </EditToggle>
                      <DeleteButton
                        action={deleteCategory.bind(null, c.code)}
                        confirm={`Delete category ${c.name} (${c.code})?`}
                        disabled={used.o + used.p + used.s > 0}
                      />
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {categories.length === 0 && <p className="p-8 text-center text-sm text-foreground/60">No categories yet.</p>}
      </section>
    </div>
  );
}

/* ---------------- Item makers ---------------- */

function MakerInputs({ maker }: { maker?: Maker }) {
  return (
    <>
      <Field label="Name"><input name="name" className="input" required defaultValue={maker?.name} placeholder="e.g. Sunil Silva" /></Field>
      <Field label="Phone (optional)"><input name="phone" type="tel" className="input" defaultValue={maker?.phone} placeholder="07X XXX XXXX" /></Field>
      <Field label="Note (optional)"><input name="note" className="input" defaultValue={maker?.note} placeholder="e.g. Rings and bangles" /></Field>
    </>
  );
}

async function MakersTab() {
  const { orders, stock } = await getDb();
  const [makers, orderUse, stockUse] = await Promise.all([
    getMakers(),
    orders.aggregate<{ _id: string; n: number }>([{ $group: { _id: "$makerName", n: { $sum: 1 } } }]).toArray(),
    stock.aggregate<{ _id: string; n: number }>([{ $group: { _id: "$makerName", n: { $sum: 1 } } }]).toArray(),
  ]);
  const count = (list: { _id: string; n: number }[], name: string) => list.find((x) => x._id === name)?.n ?? 0;

  return (
    <div className="grid gap-5 lg:grid-cols-3">
      <section className="card h-fit">
        <h2 className="card-title">Add item maker</h2>
        <ActionForm action={createMaker} submitLabel="Add maker" submitClassName="btn-primary w-full">
          <MakerInputs />
          <p className="text-xs text-foreground/50">Makers appear in the order and stock forms.</p>
        </ActionForm>
      </section>

      <section className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-sm lg:col-span-2">
        <table className="table">
          <thead>
            <tr><th>Name</th><th>Phone</th><th>Note</th><th>Used by</th><th className="text-right">Actions</th></tr>
          </thead>
          <tbody>
            {makers.map((m) => {
              const used = { o: count(orderUse, m.name), s: count(stockUse, m.name) };
              return (
                <tr key={m.id}>
                  <td className="font-medium">{m.name}</td>
                  <td className="whitespace-nowrap">{m.phone || "—"}</td>
                  <td className="text-foreground/70">{m.note || "—"}</td>
                  <td className="text-xs whitespace-nowrap text-foreground/60">{used.o} orders · {used.s} stock</td>
                  <td>
                    <div className="flex items-start justify-end gap-2">
                      <EditToggle>
                        <ActionForm action={updateMaker.bind(null, m.id)} submitLabel="Save" submitClassName="btn-primary w-full" className="space-y-3">
                          <MakerInputs maker={m} />
                        </ActionForm>
                      </EditToggle>
                      <DeleteButton action={deleteMaker.bind(null, m.id)} confirm={`Delete maker ${m.name}?`} disabled={used.o + used.s > 0} />
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {makers.length === 0 && <p className="p-8 text-center text-sm text-foreground/60">No item makers yet — add one on the left.</p>}
      </section>
    </div>
  );
}

/* ---------------- Pawned items ---------------- */

async function PawnsTab({ q, editId }: { q: string; editId: string }) {
  const [list, categoryName, editing] = await Promise.all([listPawns("all", q), getCategoryNames(), editId ? getPawn(editId) : null]);
  const base = `/settings?tab=pawns${q ? `&q=${encodeURIComponent(q)}` : ""}`;

  return (
    <div className="space-y-5">
      {editing && (
        <section className="card">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <h2 className="card-title mb-0">Edit pawn {editing.ticketNo}</h2>
            <Link href={base} className="btn-outline px-3 py-1.5">Close</Link>
          </div>
          <p className="mb-4 text-xs text-foreground/50">
            Ticket number, item category and locker ({editing.lockerCode}) can&apos;t be changed.
            {editing.payments.length > 0 && " The loan amount is fixed because payments have been taken."}
          </p>
          <ActionForm action={updatePawn.bind(null, editing._id.toString())} submitLabel="Save pawn" submitClassName="btn-primary px-8" className="space-y-5">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Field label="Customer name"><input name="name" className="input" required defaultValue={editing.customer.name} /></Field>
              <Field label="NIC number"><input name="nic" className="input uppercase" required defaultValue={editing.customer.nic} /></Field>
              <Field label="Phone number"><input name="phone" type="tel" className="input" required defaultValue={editing.customer.phone} /></Field>
              <Field label="Address"><input name="address" className="input" required defaultValue={editing.customer.address} /></Field>
              <Field label="Standard">
                <select name="standard" className="input" defaultValue={editing.standard}>
                  {PAWN_STANDARDS.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </Field>
              <WeightInput name="gross" label="Gross weight (optional)" defaultMg={editing.grossWeightMg} required={false} />
              <WeightInput name="net" label="Net weight" defaultMg={editing.netWeightMg} />
              <Field label="Assessed value (Rs.)">
                <input name="assessedValue" type="number" min="0.01" step="0.01" className="input" required defaultValue={editing.assessedValue} />
              </Field>
              <Field label="Loan amount (Rs.)">
                <input
                  name="principal"
                  type="number"
                  min="0.01"
                  step="0.01"
                  className="input"
                  required
                  defaultValue={editing.loanAmount ?? editing.principal}
                  disabled={editing.payments.length > 0}
                />
              </Field>
              <Field label="Monthly interest rate (%)">
                <input name="monthlyRate" type="number" min="0" max="20" step="0.01" className="input" required defaultValue={editing.monthlyRate} />
              </Field>
              <Field label="Duration — months">
                <input name="durationMonths" type="number" min="0" max="120" step="1" className="input" defaultValue={editing.durationMonths ?? 0} />
              </Field>
              <Field label="Duration — days">
                <input name="durationDays" type="number" min="0" max="365" step="1" className="input" defaultValue={editing.durationDays ?? 0} />
              </Field>
              <Field label="Notes" className="sm:col-span-2 lg:col-span-4">
                <textarea name="notes" rows={2} className="input" defaultValue={editing.notes} />
              </Field>
            </div>
          </ActionForm>
        </section>
      )}

      <form action="/settings" className="flex max-w-xl gap-2">
        <input type="hidden" name="tab" value="pawns" />
        <input name="q" className="input" defaultValue={q} placeholder="Search ticket no, NIC, name, phone, locker…" />
        <button className="btn-primary">Search</button>
      </form>

      <section className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-sm">
        <table className="table">
          <thead>
            <tr><th>Ticket</th><th>Customer</th><th>Item</th><th className="text-right">Loan balance</th><th>Pawned</th><th>Status</th><th className="text-right">Actions</th></tr>
          </thead>
          <tbody>
            {list.map((p) => {
              const id = p._id.toString();
              return (
                <tr key={id} className={id === editId ? "bg-amber-50" : ""}>
                  <td className="font-bold whitespace-nowrap"><Link href={`/pawning/${id}`} className="underline">{p.ticketNo}</Link></td>
                  <td>
                    <p className="font-medium">{p.customer.name}</p>
                    <p className="text-xs text-foreground/60">{p.customer.nic}</p>
                  </td>
                  <td className="whitespace-nowrap">{categoryName(p.category)} {p.standard} · {formatWeight(p.netWeightMg)}</td>
                  <td className="text-right whitespace-nowrap">{formatMoney(p.principal)}</td>
                  <td className="whitespace-nowrap">{formatDate(p.pawnDate)}</td>
                  <td>{p.status === "active" ? <Pill tone="green">Active · {lockerLabel(p.lockerCode, p.lockerSlot)}</Pill> : <Pill tone="gray">Released</Pill>}</td>
                  <td>
                    <div className="flex items-start justify-end gap-2">
                      <Link href={`${base}&edit=${id}`} className="btn-outline px-3 py-1 text-xs">Edit</Link>
                      <DeleteButton
                        action={deletePawn.bind(null, id)}
                        confirm={
                          `Permanently delete pawn ${p.ticketNo} for ${p.customer.name}?` +
                          (p.status === "active" ? ` It will no longer be listed in locker ${p.lockerCode}.` : "") +
                          (p.payments.length ? ` Its ${p.payments.length} payment receipt(s) will also be deleted.` : "") +
                          " This cannot be undone."
                        }
                      />
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {list.length === 0 && <p className="p-8 text-center text-sm text-foreground/60">{q ? "No pawns match your search." : "No pawns yet."}</p>}
      </section>
    </div>
  );
}

/* ---------------- Users ---------------- */

async function UsersTab({ me }: { me: CurrentUser }) {
  const { users } = await getDb();
  const list = await users.find({}, { projection: { passwordHash: 0 } }).sort({ createdAt: 1 }).toArray();
  const owner = process.env.ADMIN_USERNAME;

  return (
    <div className="grid gap-5 lg:grid-cols-3">
      <section className="card h-fit">
        <h2 className="card-title">Create user</h2>
        <ActionForm action={createUser} submitLabel="Create user" submitClassName="btn-primary w-full">
          <Field label="Full name"><input name="name" className="input" required /></Field>
          <Field label="Username (for logging in)">
            <input name="username" className="input lowercase" required autoComplete="off" placeholder="e.g. nimal" />
          </Field>
          <Field label="Role">
            <select name="role" className="input" defaultValue="staff">
              {USER_ROLES.map((r) => <option key={r.value} value={r.value}>{r.label} — {r.hint}</option>)}
            </select>
          </Field>
          <Field label="Password (at least 8 characters)">
            <input name="password" type="password" className="input" required minLength={8} autoComplete="new-password" />
          </Field>
          <Field label="Confirm password">
            <input name="confirm" type="password" className="input" required minLength={8} autoComplete="new-password" />
          </Field>
        </ActionForm>
      </section>

      <section className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-sm lg:col-span-2">
        <table className="table">
          <thead>
            <tr><th>User</th><th>Role</th><th>Created</th><th className="text-right">Actions</th></tr>
          </thead>
          <tbody>
            {owner && (
              <tr>
                <td>
                  <p className="font-medium">{owner}</p>
                  <p className="text-xs text-foreground/60">Owner account (from the server settings)</p>
                </td>
                <td><Pill tone="ink">Admin</Pill></td>
                <td className="text-sm text-foreground/50">—</td>
                <td className="text-right text-xs text-foreground/50">Change in .env / Vercel</td>
              </tr>
            )}
            {list.map((u) => (
              <tr key={u._id}>
                <td>
                  <p className="font-medium">{u.name}</p>
                  <p className="text-xs text-foreground/60">{u._id}{u._id === me.username && " (you)"}</p>
                </td>
                <td><Pill tone={u.role === "admin" ? "ink" : "gray"}>{u.role === "admin" ? "Admin" : "Staff"}</Pill></td>
                <td className="text-sm whitespace-nowrap text-foreground/60">{formatDateTime(u.createdAt)}</td>
                <td>
                  <div className="flex items-start justify-end gap-2">
                    <EditToggle>
                      <ActionForm action={updateUser.bind(null, u._id)} submitLabel="Save" submitClassName="btn-primary w-full" className="space-y-3">
                        <Field label="Full name"><input name="name" className="input" defaultValue={u.name} required /></Field>
                        <Field label="Role">
                          <select name="role" className="input" defaultValue={u.role}>
                            {USER_ROLES.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
                          </select>
                        </Field>
                        <Field label="New password (leave blank to keep)">
                          <input name="password" type="password" className="input" autoComplete="new-password" />
                        </Field>
                        <Field label="Confirm new password">
                          <input name="confirm" type="password" className="input" autoComplete="new-password" />
                        </Field>
                      </ActionForm>
                    </EditToggle>
                    {u._id !== me.username && (
                      <DeleteButton action={deleteUser.bind(null, u._id)} confirm={`Delete user ${u._id}? They will be signed out.`} />
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {list.length === 0 && <p className="p-6 text-center text-sm text-foreground/60">No staff accounts yet — create one on the left.</p>}
      </section>
    </div>
  );
}
