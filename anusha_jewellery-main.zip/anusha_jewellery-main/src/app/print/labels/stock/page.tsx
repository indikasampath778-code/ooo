import type { Metadata } from "next";
import LabelSheet, { LABEL_PAGE_CSS } from "@/components/LabelSheet";
import PrintButton from "@/components/PrintButton";
import { lockerLabel } from "@/lib/lockerLabel";
import { listStock, readStockFilters } from "@/lib/stock";

export const metadata: Metadata = { title: "Barcode Labels | Anusha Jewellers" };

/** Labels for every item in the Shop Stock list as currently filtered, one label per page. */
export default async function StockLabelsPage(props: PageProps<"/print/labels/stock">) {
  const { status, karat, category, q } = readStockFilters(await props.searchParams);
  const items = await listStock(status, q, karat, category);

  return (
    <>
      <style>{`${LABEL_PAGE_CSS} @media screen { .label-sheet { margin: 0 auto 12mm; } }`}</style>
      <div className="no-print mx-auto max-w-lg space-y-4 p-6 text-center">
        <h1 className="font-bold text-xl text-ink">Barcode labels</h1>
        <p className="text-sm text-foreground/70">
          {items.length} label{items.length === 1 ? "" : "s"} for the filtered shop stock list.
        </p>
        <p className="text-xs text-foreground/50">
          Preview is enlarged. In the print dialog choose your label printer, paper size 34 × 25 mm (width × height), margins “None”, scale 100%.
        </p>
        {items.length > 0 && <PrintButton label={`Print ${items.length} label${items.length === 1 ? "" : "s"}`} />}
      </div>
      <div className="print:block">
        {items.map((item) => (
          <LabelSheet
            key={item._id.toString()}
            barcode={item.code}
            locker={lockerLabel(item.lockerCode, item.lockerSlot) ?? `${item.karat}K`}
            weightMg={item.weightMg}
          />
        ))}
      </div>
    </>
  );
}
