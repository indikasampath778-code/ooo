import type { Metadata } from "next";
import { notFound } from "next/navigation";
import LabelSheet, { LABEL_PAGE_CSS } from "@/components/LabelSheet";
import PrintButton from "@/components/PrintButton";
import { lockerLabel } from "@/lib/lockerLabel";
import { getOrder } from "@/lib/orders";
import { getPawn } from "@/lib/pawns";
import { getStockItem } from "@/lib/stock";

export const metadata: Metadata = { title: "Barcode Label | Anusha Jewellers" };

async function loadLabel(kind: string, id: string) {
  if (kind === "order") {
    const order = await getOrder(id);
    if (!order?.barcode || !order.completion) return null;
    return {
      barcode: order.barcode,
      locker: lockerLabel(order.lockerCode, order.lockerSlot),
      weightMg: order.completion.finalWeightMg,
      title: `Order ${order.billNo} — ${order.customer.name}`,
    };
  }
  if (kind === "pawn") {
    const pawn = await getPawn(id);
    if (!pawn) return null;
    return {
      barcode: pawn.ticketNo,
      locker: lockerLabel(pawn.lockerCode, pawn.lockerSlot),
      weightMg: pawn.netWeightMg,
      title: `Pawn ${pawn.ticketNo} — ${pawn.customer.name}`,
    };
  }
  if (kind === "stock") {
    const item = await getStockItem(id);
    if (!item) return null;
    return {
      barcode: item.code,
      locker: lockerLabel(item.lockerCode, item.lockerSlot) ?? `${item.karat}K`, // items on open display show the carats instead
      weightMg: item.weightMg,
      title: `Stock ${item.code} — ${item.name}`,
    };
  }
  return null;
}

export default async function LabelPage(props: PageProps<"/print/label/[kind]/[id]">) {
  const { kind, id } = await props.params;
  // Inside the popup on the item's page only the label itself is shown.
  const embed = (await props.searchParams).embed === "1";
  const label = await loadLabel(kind, id);
  if (!label) notFound();

  return (
    <>
      <style>{`
        ${LABEL_PAGE_CSS}
        ${embed ? "@media screen { html, body { background: #fff !important; min-height: 0 !important; } }" : ""}
      `}</style>

      {!embed && <div className="no-print mx-auto max-w-lg space-y-4 p-6 text-center">
        <h1 className="font-bold text-xl text-ink">Barcode label</h1>
        <p className="text-sm text-foreground/70">{label.title}</p>
        <p className="text-xs text-foreground/50">
          Preview is enlarged. In the print dialog choose your label printer, paper size 34 × 25 mm (width × height), margins “None”, scale 100%.
        </p>
        <PrintButton label="Print label" />
      </div>}

      <div className={`flex justify-center print:block ${embed ? "pt-2" : ""}`}>
        <LabelSheet barcode={label.barcode} locker={label.locker} weightMg={label.weightMg} />
      </div>
    </>
  );
}
