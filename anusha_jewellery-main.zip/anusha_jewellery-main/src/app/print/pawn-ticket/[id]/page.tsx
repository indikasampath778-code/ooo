import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Barcode from "@/components/Barcode";
import { PrintSlip, SlipDivider, SlipRow } from "@/components/PrintSlip";
import { getCategoryNames } from "@/lib/categories";
import { formatDate, formatDuration, formatMoney, formatWeight } from "@/lib/format";
import { getPawn } from "@/lib/pawns";

export const metadata: Metadata = { title: "Pawn Ticket | Anusha Jewellers" };

export default async function PawnTicketPage(props: PageProps<"/print/pawn-ticket/[id]">) {
  const categoryName = await getCategoryNames();
  const { id } = await props.params;
  const pawn = await getPawn(id);
  if (!pawn) notFound();

  return (
    <PrintSlip title="Pawn ticket">
      <div className="my-2 text-center">
        <Barcode value={pawn.ticketNo} className="mx-auto h-12 w-56" />
        <p className="font-mono text-sm font-bold">{pawn.ticketNo}</p>
      </div>
      <SlipRow label="Date" value={formatDate(pawn.pawnDate)} />
      <SlipDivider />
      <SlipRow label="Customer" value={pawn.customer.name} />
      <SlipRow label="NIC" value={pawn.customer.nic} />
      <SlipRow label="Phone" value={pawn.customer.phone} />
      <SlipRow label="Address" value={pawn.customer.address} />
      <SlipDivider />
      <SlipRow label="Item" value={categoryName(pawn.category)} />
      <SlipRow label="Standard" value={pawn.standard} />
      {pawn.grossWeightMg != null && <SlipRow label="Gross weight" value={formatWeight(pawn.grossWeightMg)} />}
      <SlipRow label="Net weight" value={formatWeight(pawn.netWeightMg)} />
      <SlipRow label="Assessed value" value={formatMoney(pawn.assessedValue)} />
      <SlipDivider />
      <SlipRow label="Principal" value={formatMoney(pawn.loanAmount ?? pawn.principal)} bold />
      <SlipRow label="Interest" value={`${pawn.monthlyRate}% per month`} />
      {pawn.dueDate && (
        <>
          <SlipRow label="Duration" value={formatDuration(pawn.durationMonths, pawn.durationDays)} />
          <SlipRow label="Due date" value={formatDate(pawn.dueDate)} bold />
        </>
      )}
      <p className="mt-2 text-[10px]">
        Interest is charged per day at the monthly rate. Please bring this ticket and your NIC when paying interest or redeeming the item.
      </p>
      <div className="mt-6 flex justify-between gap-4 text-[10px]">
        <span className="flex-1 border-t border-black pt-1 text-center">Customer signature</span>
        <span className="flex-1 border-t border-black pt-1 text-center">For {`Anusha Jewellers`}</span>
      </div>
    </PrintSlip>
  );
}
