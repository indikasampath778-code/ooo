import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { InvoiceSheet, type InvoiceColumn, type InvoiceData } from "@/components/InvoiceSheet";
import { payMethodLabel } from "@/lib/constants";
import { getCategoryNames } from "@/lib/categories";
import { formatDate, formatDateTime, formatMoney, formatWeight, round2, todayISO } from "@/lib/format";
import { orderTotals } from "@/lib/orders";
import { principalBefore } from "@/lib/pawns";
import { findReceipt } from "@/lib/receipts";
import type { OldGoldLine } from "@/lib/types";

export const metadata: Metadata = { title: "Receipt | Anusha Jewellers" };

const itemColumns: InvoiceColumn[] = [
  { label: "Item / Code" },
  { label: "Karat", align: "center" },
  { label: "Net Wt", align: "right" },
  { label: "Price", align: "right" },
  { label: "Total", align: "right" },
];

/** Old gold handed in, listed in the item table as deductions. */
function oldGoldRows(lines: OldGoldLine[] | undefined) {
  return (lines ?? []).map((g) => [
    <span key="d">Old gold exchange — {g.description}</span>,
    `${g.karat}K`,
    g.weightMg > 0 ? formatWeight(g.weightMg) : "—",
    "",
    <b key="v">- {formatMoney(g.value)}</b>,
  ]);
}

/** Payments up to and including receipt `no`, oldest first, with their total. */
function paymentHistory(payments: { receiptNo: string; paidAt: Date; amount: number; label: string }[], no: string) {
  const upTo = payments.slice(0, payments.findIndex((p) => p.receiptNo === no) + 1);
  return {
    history: upTo.map((p) => ({
      receiptNo: p.receiptNo,
      date: formatDate(todayISO(p.paidAt)),
      label: p.label,
      amount: formatMoney(p.amount),
      current: p.receiptNo === no,
    })),
    historyTotal: formatMoney(round2(upTo.reduce((s, p) => s + p.amount, 0))),
  };
}

function oldGoldSum(lines: OldGoldLine[] | undefined) {
  return round2((lines ?? []).reduce((s, g) => s + g.value, 0));
}

export default async function ReceiptPage(props: PageProps<"/print/receipt/[no]">) {
  const categoryName = await getCategoryNames();
  const { no } = await props.params;
  const receipt = await findReceipt(no);
  if (!receipt) notFound();

  let data: InvoiceData;

  if (receipt.kind === "order") {
    const { order, payment } = receipt;
    const { price } = orderTotals(order);
    const index = order.payments.findIndex((p) => p.receiptNo === no);
    const paidToDate = round2(order.payments.slice(0, index + 1).reduce((s, p) => s + p.amount, 0));
    const gold = oldGoldSum(payment.oldGold);
    data = {
      kind: payment.note || "Order payment",
      receiptNo: payment.receiptNo,
      date: formatDateTime(payment.paidAt),
      customer: [
        { label: "Customer", value: order.customer.name },
        { label: "Phone", value: order.customer.phone },
      ],
      refs: [{ label: "Bill No", value: order.billNo }],
      columns: itemColumns,
      rows: [
        [
          <span key="i"><b>{categoryName(order.category)}</b> (custom order {order.billNo})</span>,
          `${order.completion?.karat ?? order.karat}K`,
          formatWeight(order.completion?.finalWeightMg ?? order.weightMg),
          price != null ? formatMoney(price) : "Not set",
          price != null ? <b key="p">{formatMoney(price)}</b> : "—",
        ],
        ...oldGoldRows(payment.oldGold),
      ],
      lines: [
        ...(price != null ? [{ label: "Total price", value: formatMoney(price) }] : []),
        ...(gold > 0
          ? [
              { label: "Old Gold Allowance", value: formatMoney(gold), tone: "minus" as const },
              { label: "Cash / card", value: formatMoney(payment.cash ?? 0) },
            ]
          : []),
      ],
      grand: { label: "Paid now", value: formatMoney(payment.amount) },
      after: [
        { label: "Method", value: payMethodLabel(payment.method) },
        { label: "Paid to date", value: formatMoney(paidToDate) },
        ...(price != null ? [{ label: "Balance", value: formatMoney(round2(price - paidToDate)) }] : []),
      ],
    };
  } else if (receipt.kind === "reservation") {
    const { reservation: r, payment, index } = receipt;
    const paidToDate = round2(r.payments.slice(0, index + 1).reduce((s, p) => s + p.amount, 0));
    const balance = round2(r.total - paidToDate);
    const gold = oldGoldSum(payment.oldGold);
    data = {
      kind: balance === 0 ? "Final payment · sale complete" : "Reservation payment",
      receiptNo: payment.receiptNo,
      date: formatDateTime(payment.paidAt),
      customer: [
        { label: "Customer", value: r.customer.name },
        { label: "Phone", value: r.customer.phone },
      ],
      refs: [{ label: "Reservation", value: r.code }],
      columns: itemColumns,
      rows: [
        ...r.items.map((i) => [
          <span key="i"><b>{i.name}</b> ({i.code}){i.goldRate ? <span className="block text-[11px] text-slate-500">Gold rate {formatMoney(i.goldRate)}/g</span> : null}</span>,
          `${i.karat}K`,
          formatWeight(i.weightMg),
          formatMoney(i.listPrice),
          <b key="p">{formatMoney(i.price)}</b>,
        ]),
        ...oldGoldRows(payment.oldGold),
      ],
      lines: [
        { label: "Total", value: formatMoney(r.total) },
        ...(gold > 0
          ? [
              { label: "Old Gold Allowance", value: formatMoney(gold), tone: "minus" as const },
              { label: "Cash / card", value: formatMoney(payment.cash ?? 0) },
            ]
          : []),
      ],
      grand: { label: "Paid now", value: formatMoney(payment.amount) },
      after: [
        { label: "Method", value: payMethodLabel(payment.method) },
        { label: "Paid to date", value: formatMoney(paidToDate) },
        { label: "Balance", value: formatMoney(balance) },
      ],
      note: balance > 0 && r.reserveUntil ? `Items reserved until ${formatDate(r.reserveUntil)}.` : undefined,
    };
  } else if (receipt.kind === "sale") {
    const { sale } = receipt;
    const discount = round2(sale.items.reduce((s, i) => s + i.listPrice - i.price, 0));
    data = {
      kind: "Sales invoice",
      receiptNo: sale.receiptNo,
      date: formatDateTime(sale.soldAt),
      customer: [
        { label: "Customer", value: sale.customer.name },
        ...(sale.customer.phone ? [{ label: "Phone", value: sale.customer.phone }] : []),
      ],
      columns: itemColumns,
      rows: [
        ...sale.items.map((i) => [
          <span key="i"><b>{i.name}</b> ({i.code}){i.goldRate ? <span className="block text-[11px] text-slate-500">Gold rate {formatMoney(i.goldRate)}/g</span> : null}</span>,
          `${i.karat}K`,
          formatWeight(i.weightMg),
          formatMoney(i.listPrice),
          <b key="p">{formatMoney(i.price)}</b>,
        ]),
        ...oldGoldRows(sale.oldGold),
      ],
      lines: [
        { label: "Subtotal", value: formatMoney(sale.subtotal) },
        ...(discount > 0 ? [{ label: "Includes discount", value: formatMoney(discount) }] : []),
        ...(sale.oldGoldTotal > 0 ? [{ label: "Old Gold Allowance", value: formatMoney(sale.oldGoldTotal), tone: "minus" as const }] : []),
      ],
      grand: { label: "Grand Total", value: formatMoney(sale.total) },
      after: [
        { label: "Method", value: payMethodLabel(sale.method) },
        { label: "Served by", value: sale.soldBy },
      ],
    };
  } else if (receipt.kind === "stock") {
    const { item, sale } = receipt;
    const discount = round2(item.price - sale.price);
    data = {
      kind: "Sales invoice",
      receiptNo: sale.receiptNo,
      date: formatDateTime(sale.soldAt),
      customer: [
        { label: "Customer", value: sale.customer.name },
        ...(sale.customer.phone ? [{ label: "Phone", value: sale.customer.phone }] : []),
      ],
      columns: itemColumns,
      rows: [[
        <span key="i"><b>{item.name}</b> ({item.code})</span>,
        `${item.karat}K`,
        formatWeight(item.weightMg),
        formatMoney(item.price),
        <b key="p">{formatMoney(sale.price)}</b>,
      ]],
      lines: [
        { label: "Subtotal", value: formatMoney(item.price) },
        ...(discount > 0 ? [{ label: "Discount", value: formatMoney(discount), tone: "minus" as const }] : []),
      ],
      grand: { label: "Grand Total", value: formatMoney(sale.price) },
      after: [{ label: "Method", value: payMethodLabel(sale.method) }],
    };
  } else {
    const { pawn, payment } = receipt;
    data = {
      kind: { interest: "Pawn interest receipt", installment: "Pawn installment receipt", settlement: "Pawn settlement receipt" }[payment.type],
      receiptNo: payment.receiptNo,
      date: formatDateTime(payment.paidAt),
      customer: [
        { label: "Customer", value: pawn.customer.name },
        { label: "NIC", value: pawn.customer.nic },
        { label: "Phone", value: pawn.customer.phone },
      ],
      refs: [{ label: "Ticket No", value: pawn.ticketNo }],
      columns: [
        { label: "Article" },
        { label: "Standard", align: "center" },
        { label: "Net Wt", align: "right" },
        { label: "Period", align: "right" },
        { label: "Principal", align: "right" },
      ],
      rows: [[
        <b key="i">{categoryName(pawn.category)}</b>,
        pawn.standard,
        formatWeight(pawn.netWeightMg),
        `${formatDate(payment.periodFrom)} – ${formatDate(payment.periodTo)} (${payment.days}d)`,
        <b key="p">{formatMoney(principalBefore(pawn, payment.receiptNo))}</b>,
      ]],
      lines: [
        { label: `Interest (${pawn.monthlyRate}% / month)`, value: formatMoney(payment.interest) },
        ...(payment.type !== "interest" ? [{ label: "Principal repaid", value: formatMoney(payment.principal) }] : []),
      ],
      grand: { label: "Total Paid", value: formatMoney(payment.amount) },
      after: [
        { label: "Method", value: payMethodLabel(payment.method) },
        ...(payment.principalAfter != null ? [{ label: "Loan balance", value: formatMoney(payment.principalAfter) }] : []),
      ],
      note: payment.type === "settlement" ? "Fully settled. Item released to the customer." : "Item remains in our safe keeping.",
    };
  }

  // Every payment on the bill up to this receipt, so the last receipt shows the full history.
  if (receipt.kind === "order" || receipt.kind === "reservation") {
    const payments = receipt.kind === "order" ? receipt.order.payments : receipt.reservation.payments;
    data = { ...data, ...paymentHistory(
      payments.map((p) => ({
        receiptNo: p.receiptNo,
        paidAt: p.paidAt,
        amount: p.amount,
        label: [p.note || "Payment", payMethodLabel(p.method), p.oldGold?.length ? "incl. old gold" : ""].filter(Boolean).join(" · "),
      })),
      no,
    ) };
  } else if (receipt.kind === "pawn") {
    const kinds = { interest: "Interest / renewal", installment: "Installment", settlement: "Full settlement" };
    data = { ...data, ...paymentHistory(
      receipt.pawn.payments.map((p) => ({
        receiptNo: p.receiptNo,
        paidAt: p.paidAt,
        amount: p.amount,
        label: `${kinds[p.type]} · ${payMethodLabel(p.method)}`,
      })),
      no,
    ) };
  }

  return <InvoiceSheet data={data} />;
}
