import type { Metadata } from "next";
import { Cinzel, Noto_Serif_Sinhala } from "next/font/google";
import "./globals.css";

// Cinzel is only used by the logo; the UI itself uses the system font stack.
const cinzel = Cinzel({
  variable: "--font-cinzel",
  subsets: ["latin"],
});

const notoSinhala = Noto_Serif_Sinhala({
  variable: "--font-sinhala",
  subsets: ["sinhala"],
});

export const metadata: Metadata = {
  title: "Anusha Jewellers | Shop System",
  description:
    "Order, billing and pawning system for Anusha Jewellers, Malawa, Kuruwita.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="en"
      className={`${cinzel.variable} ${notoSinhala.variable} h-full antialiased scroll-smooth`}
    >
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}
