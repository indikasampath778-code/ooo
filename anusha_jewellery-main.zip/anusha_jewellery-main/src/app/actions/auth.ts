"use server";

import { timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { getDb } from "@/lib/db";
import { verifyPassword } from "@/lib/passwords";
import { createSessionToken, SESSION_COOKIE, SESSION_MAX_AGE } from "@/lib/session";
import type { FormState } from "@/lib/types";

function safeEqual(a: string, b: string) {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}

/** Owner account from the environment, or a user created in Settings → Users. */
async function checkLogin(username: string, password: string) {
  const ownerUser = process.env.ADMIN_USERNAME;
  const ownerPassword = process.env.ADMIN_PASSWORD;
  if (ownerUser && ownerPassword && username === ownerUser) {
    return safeEqual(password, ownerPassword) ? username : null;
  }
  const { users } = await getDb();
  const user = await users.findOne({ _id: username.toLowerCase() });
  if (!user) return null;
  return (await verifyPassword(password, user.passwordHash)) ? user._id : null;
}

export async function login(_prev: FormState, formData: FormData): Promise<FormState> {
  const username = String(formData.get("username") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  if (!username || !password) return { error: "Enter your username and password" };

  let signedIn: string | null;
  try {
    signedIn = await checkLogin(username, password);
  } catch (error) {
    console.error(error);
    return { error: "Could not reach the database. Please try again." };
  }
  if (!signedIn) return { error: "Incorrect username or password" };

  (await cookies()).set(SESSION_COOKIE, await createSessionToken(signedIn), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_MAX_AGE,
  });

  const next = String(formData.get("next") ?? "");
  redirect(next.startsWith("/") && !next.startsWith("//") ? next : "/dashboard");
}

export async function logout() {
  (await cookies()).delete(SESSION_COOKIE);
  redirect("/login");
}
