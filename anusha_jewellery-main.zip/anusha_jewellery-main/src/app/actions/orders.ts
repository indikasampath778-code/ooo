"use server";

import { ObjectId } from "mongodb";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { KARATS, PAY_METHODS, type OrderStatus } from "@/lib/constants";
import { assertCategory } from "@/lib/categories";
import { getDb, nextReceiptNo, nextSequence, padNumber } from "@/lib/db";
import { errorMessage, FormError, isoDate, money, oneOf, optionalMoney, optionalWeight, phone, text, weight } from "@/lib/form";
import { round2 } from "@/lib/format";
import { readLockerFields } from "@/lib/lockers";
import { parseOldGold, sumOldGold } from "@/lib/oldGold";
import { orderTotals } from "@/lib/orders";
import type { FormState, OrderDoc } from "@/lib/types";

async function readOrderFields(fd: FormData) {
  return {
    customer: {
      name: text(fd, "name", "Customer name", { required: true, max: 120 }),
      phone: phone(fd),
      address: text(fd, "address", "Address", { max: 300 }),
    },
    category: await assertCategory(fd.get("category")),
    weightMg: optionalWeight(fd, "weight", "Weight"),
    karat: oneOf(Number(fd.get("karat")), KARATS, "Karat"),
    makerName: text(fd, "makerName", "Item maker name", { required: true, max: 120 }),
    deliveryDate: isoDate(fd, "deliveryDate", "Delivery date"),
    notes: text(fd, "notes", "Notes", { max: 1000 }),
  };
}

async function loadOrder(id: string) {
  if (!ObjectId.isValid(id)) throw new FormError("Order not found");
  const { orders } = await getDb();
  const order = await orders.findOne({ _id: new ObjectId(id) });
  if (!order) throw new FormError("Order not found");
  return { orders, order };
}

function refresh(id: string) {
  revalidatePath(`/orders/${id}`);
  revalidatePath("/orders");
  revalidatePath("/billing");
  revalidatePath("/dashboard");
}

export async function createOrder(_prev: FormState, fd: FormData): Promise<FormState> {
  await requireUser();
  let id: string;
  try {
    const fields = await readOrderFields(fd);
    const billNo =
      text(fd, "billNo", "Bill number", { max: 30 }).toUpperCase() ||
      `AJ${padNumber(await nextSequence("bill"))}`;
    // Advance = cash/card plus any old gold handed in with the order.
    const cash = optionalMoney(fd, "advance", "Advance payment");
    const oldGold = parseOldGold(String(fd.get("oldGold") ?? "[]"));
    const advance = round2(cash + sumOldGold(oldGold));
    const method = oneOf(fd.get("method") ?? "cash", PAY_METHODS.map((m) => m.value), "Payment method");
    const now = new Date();
    const doc: Omit<OrderDoc, "_id"> = {
      ...fields,
      billNo,
      status: "pending",
      completion: null,
      lockerCode: null,
      barcode: null,
      payments: advance > 0
        ? [{ receiptNo: await nextReceiptNo(), amount: advance, cash, oldGold, method, note: "Advance", paidAt: now }]
        : [],
      createdAt: now,
      updatedAt: now,
      deliveredAt: null,
    };
    const { orders } = await getDb();
    const result = await orders.insertOne(doc as OrderDoc);
    id = result.insertedId.toString();
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh(id);
  // Back to the orders table, which confirms the new order and links to it.
  redirect(`/orders?created=${id}`);
}

export async function updateOrder(id: string, _prev: FormState, fd: FormData): Promise<FormState> {
  await requireUser();
  try {
    const { orders, order } = await loadOrder(id);
    if (order.status === "delivered") throw new FormError("Delivered orders cannot be edited");
    const fields = await readOrderFields(fd);
    const billNo = text(fd, "billNo", "Bill number", { required: true, max: 30 }).toUpperCase();
    await orders.updateOne({ _id: order._id }, { $set: { ...fields, billNo, updatedAt: new Date() } });
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh(id);
  return { success: "Order details saved" };
}

/** Pending / In Progress / Completed / Cancelled. Completed also records final weight, carats and price. */
export async function updateOrderStatus(id: string, _prev: FormState, fd: FormData): Promise<FormState> {
  await requireUser();
  let message = "Status updated";
  try {
    const { orders, order } = await loadOrder(id);
    const status = oneOf(
      fd.get("status"),
      ["pending", "in_progress", "completed", "cancelled"] as OrderStatus[],
      "Status",
    );
    if (order.status === "delivered") throw new FormError("Delivered orders cannot be changed");
    if (order.status === "completed" && status !== "cancelled") {
      throw new FormError("This order is already completed");
    }

    if (status === "completed") {
      const finalWeightMg = weight(fd, "finalWeight", "Final weight");
      const karat = oneOf(Number(fd.get("finalKarat")), KARATS, "Karat");
      const price = readFinalPrice(fd, order);
      const now = new Date();
      await orders.updateOne(
        { _id: order._id },
        { $set: { status, completion: { finalWeightMg, karat, price, completedAt: now }, updatedAt: now } },
      );
      message = "Item marked as completed";
    } else {
      await orders.updateOne({ _id: order._id }, { $set: { status, updatedAt: new Date() } });
      if (status === "cancelled") await orders.updateOne({ _id: order._id }, { $set: { lockerCode: null, cancelledAt: new Date() } });
    }
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh(id);
  return { success: message };
}

/** Final price from the form: optional (null = set later), never below what is already paid. */
function readFinalPrice(fd: FormData, order: OrderDoc) {
  if (!String(fd.get("price") ?? "").trim()) return null;
  const price = money(fd, "price", "Price");
  const { paid } = orderTotals(order);
  if (price < paid) throw new FormError("Price cannot be less than the amount already paid");
  return price;
}

/** Sets or changes the final price of a completed order (e.g. at today's gold rate). */
export async function setOrderPrice(id: string, _prev: FormState, fd: FormData): Promise<FormState> {
  await requireUser();
  try {
    const { orders, order } = await loadOrder(id);
    if (order.status !== "completed" || !order.completion) throw new FormError("Only completed orders can be priced");
    if (!String(fd.get("price") ?? "").trim()) throw new FormError("Enter the final price");
    const price = readFinalPrice(fd, order);
    await orders.updateOne({ _id: order._id, status: "completed" }, { $set: { "completion.price": price, updatedAt: new Date() } });
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh(id);
  return { success: "Final price saved" };
}

export async function placeOrderInLocker(id: string, _prev: FormState, fd: FormData): Promise<FormState> {
  await requireUser();
  try {
    const { orders, order } = await loadOrder(id);
    if (order.status !== "completed") throw new FormError("Complete the item before putting it in a locker");
    if (order.lockerCode) throw new FormError(`Already in locker ${order.lockerCode}`);
    const { lockerCode, lockerSlot } = await readLockerFields(fd, { required: true });
    const barcode = order.barcode ?? `OR${padNumber(await nextSequence("barcode:order"))}`;
    const result = await orders.updateOne(
      { _id: order._id, lockerCode: null },
      { $set: { lockerCode, lockerSlot, barcode, updatedAt: new Date() } },
    );
    if (result.modifiedCount === 0) throw new FormError("This order was just updated by someone else. Please refresh.");
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh(id);
  revalidatePath("/lockers");
  return { success: "Item placed in locker. You can now print the barcode label." };
}

/** Records an advance, an installment or the final bill payment. */
export async function addOrderPayment(id: string, _prev: FormState, fd: FormData): Promise<FormState> {
  await requireUser();
  let receiptNo: string;
  let handedOver = false;
  try {
    const { orders, order } = await loadOrder(id);
    if (order.status === "cancelled") throw new FormError("This order is cancelled");
    if (order.status === "delivered") throw new FormError("This order is already delivered");
    if (order.status === "completed" && !order.barcode) {
      throw new FormError("Put the item in a locker and generate its barcode before taking payment");
    }
    // Cash/card/bank part plus any old gold handed in; together they are credited to the bill.
    const cash = optionalMoney(fd, "amount", "Amount");
    const oldGold = parseOldGold(String(fd.get("oldGold") ?? "[]"));
    const amount = round2(cash + sumOldGold(oldGold));
    if (amount <= 0) throw new FormError("Enter an amount or add old gold");
    const method = oneOf(fd.get("method"), PAY_METHODS.map((m) => m.value), "Payment method");
    const note = text(fd, "note", "Note", { max: 200 });
    const { balance } = orderTotals(order);
    if (balance != null && amount > balance) {
      throw new FormError(`Payment (${amount.toLocaleString("en-LK")}) is more than the balance due`);
    }
    receiptNo = await nextReceiptNo();
    const now = new Date();
    await orders.updateOne(
      { _id: order._id },
      {
        $push: { payments: { receiptNo, amount, cash, oldGold, method, note, paidAt: now } },
        $set: { updatedAt: now },
      },
    );

    const fullyPaid = balance != null && round2(balance - amount) === 0;
    if (fd.get("handover") === "on" && fullyPaid && order.status === "completed") {
      await orders.updateOne(
        { _id: order._id },
        { $set: { status: "delivered", deliveredAt: now, lockerCode: null, updatedAt: now } },
      );
      handedOver = true;
    }
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh(id);
  revalidatePath("/lockers");
  return {
    success: handedOver ? "Payment saved. Item handed over and taken out of its locker." : "Payment saved",
    receiptNo,
  };
}

export async function deliverOrder(id: string): Promise<FormState> {
  await requireUser();
  try {
    const { orders, order } = await loadOrder(id);
    if (order.status !== "completed") throw new FormError("Only completed items can be handed over");
    const { balance } = orderTotals(order);
    if (balance !== 0) throw new FormError("Please settle the full balance before handing over");
    const now = new Date();
    await orders.updateOne(
      { _id: order._id },
      { $set: { status: "delivered", deliveredAt: now, lockerCode: null, updatedAt: now } },
    );
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh(id);
  revalidatePath("/lockers");
  return { success: "Item handed over and taken out of its locker" };
}
