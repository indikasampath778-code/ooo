"use server";

import { ObjectId } from "mongodb";
import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { CART_LIMIT, cartLinesFromForm, getCartItems, readCartIds, saleItem, writeCartIds } from "@/lib/cart";
import { PAY_METHODS } from "@/lib/constants";
import { getDb, nextReceiptNo } from "@/lib/db";
import { errorMessage, FormError, oneOf, text } from "@/lib/form";
import { round2 } from "@/lib/format";
import { parseOldGold } from "@/lib/oldGold";
import type { FormState, SaleDoc } from "@/lib/types";

function refresh() {
  revalidatePath("/lockers");
  revalidatePath("/billing");
  revalidatePath("/stock");
  revalidatePath("/dashboard");
}

export async function addToCart(id: string): Promise<FormState> {
  await requireUser();
  try {
    if (!ObjectId.isValid(id)) throw new FormError("Item not found");
    const { stock } = await getDb();
    const item = await stock.findOne({ _id: new ObjectId(id) });
    if (!item) throw new FormError("Item not found");
    if (item.status !== "in_stock") throw new FormError(`${item.code} is already ${item.status === "reserved" ? "reserved for a customer" : "sold"}`);
    const ids = await readCartIds();
    if (ids.includes(id)) return { success: `${item.code} is already in the cart` };
    if (ids.length >= CART_LIMIT) throw new FormError(`The cart can hold up to ${CART_LIMIT} items`);
    await writeCartIds([...ids, id]);
    refresh();
    return { success: `Added ${item.code} · ${item.name}` };
  } catch (error) {
    return { error: errorMessage(error) };
  }
}

/**
 * For the scan box: an exact stock code (e.g. a scanned barcode) goes straight into
 * the cart. Anything else returns `notFound` so the page can show search results.
 */
export async function addToCartByCode(code: string): Promise<FormState & { notFound?: boolean }> {
  await requireUser();
  const value = code.trim().toUpperCase();
  if (!value) return { error: "Scan or type a stock code" };
  const { stock } = await getDb();
  const item = await stock.findOne({ code: value }, { projection: { _id: 1 } });
  if (!item) return { notFound: true };
  return addToCart(item._id.toString());
}

export async function removeFromCart(id: string): Promise<FormState> {
  await requireUser();
  await writeCartIds((await readCartIds()).filter((x) => x !== id));
  refresh();
  return { success: "Removed" };
}

export async function clearCart(): Promise<FormState> {
  await requireUser();
  await writeCartIds([]);
  refresh();
  return { success: "Cart cleared" };
}

/** Sells everything in the cart in one go, with any old gold exchange, and issues one receipt. */
export async function checkout(_prev: FormState, fd: FormData): Promise<FormState> {
  const user = await requireUser();
  const sold: ObjectId[] = [];
  try {
    const items = await getCartItems();
    if (!items.length) throw new FormError("The cart is empty");
    const lines = cartLinesFromForm(items, fd);
    const oldGold = parseOldGold(String(fd.get("oldGold") ?? "[]"));
    const subtotal = round2(lines.reduce((s, l) => s + l.price, 0));
    const oldGoldTotal = round2(oldGold.reduce((s, g) => s + g.value, 0));
    const total = round2(subtotal - oldGoldTotal);
    if (total < 0) throw new FormError("The old gold value is more than the items total");
    const method = oneOf(fd.get("method"), PAY_METHODS.map((m) => m.value), "Payment method");
    const customer = {
      name: text(fd, "customerName", "Customer name", { max: 120 }) || "Walk-in customer",
      phone: text(fd, "customerPhone", "Phone", { max: 20 }),
    };

    const receiptNo = await nextReceiptNo();
    const soldAt = new Date();
    const { stock, sales } = await getDb();
    for (const { item, price } of lines) {
      const result = await stock.updateOne(
        { _id: item._id, status: "in_stock" }, // stops the same piece being sold twice
        { $set: { status: "sold", sale: { receiptNo, customer, price, method, soldAt, soldBy: user.name }, updatedAt: soldAt } },
      );
      if (result.modifiedCount === 0) throw new FormError(`${item.code} was just sold elsewhere. Please check the cart.`);
      sold.push(item._id);
    }

    const sale: Omit<SaleDoc, "_id"> = {
      receiptNo,
      items: lines.map(saleItem),
      oldGold,
      subtotal,
      oldGoldTotal,
      total,
      method,
      customer,
      soldAt,
      soldBy: user.name,
    };
    await sales.insertOne(sale as SaleDoc);
    // Sold pieces leave their lockers (done only once the sale is safely saved).
    await stock.updateMany({ _id: { $in: sold } }, { $set: { lockerCode: null } });
    await writeCartIds([]);
    refresh();
    return {
      success: `Sale complete: ${lines.length} item${lines.length === 1 ? "" : "s"}, paid ${total.toLocaleString("en-LK", { minimumFractionDigits: 2 })}`,
      receiptNo,
    };
  } catch (error) {
    // Put back anything marked sold before the failure, so nothing is half-sold.
    if (sold.length) {
      const { stock } = await getDb();
      await stock.updateMany({ _id: { $in: sold } }, { $set: { status: "in_stock", sale: null, updatedAt: new Date() } });
    }
    return { error: errorMessage(error) };
  }
}
