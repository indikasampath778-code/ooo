"use server";

import { ObjectId } from "mongodb";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { PAWN_STANDARDS, PAY_METHODS } from "@/lib/constants";
import { assertCategory } from "@/lib/categories";
import { getDb, nextReceiptNo, nextSequence, padNumber } from "@/lib/db";
import { errorMessage, FormError, money, nic, oneOf, optionalWeight, percent, phone, text, weight, wholeNumber } from "@/lib/form";
import { addDaysISO, addMonthsISO, formatMoney, formatWeight, round2, todayISO } from "@/lib/format";
import { readLockerFields } from "@/lib/lockers";
import { pawnFigures } from "@/lib/pawns";
import type { FormState, PawnDoc } from "@/lib/types";

async function loadActivePawn(id: string) {
  if (!ObjectId.isValid(id)) throw new FormError("Pawn record not found");
  const { pawns } = await getDb();
  const pawn = await pawns.findOne({ _id: new ObjectId(id) });
  if (!pawn) throw new FormError("Pawn record not found");
  if (pawn.status !== "active") throw new FormError("This item has already been released");
  return { pawns, pawn };
}

function refresh(id: string) {
  revalidatePath(`/pawning/${id}`);
  revalidatePath("/pawning");
  revalidatePath("/dashboard");
  revalidatePath("/lockers");
  revalidatePath("/billing");
}

export async function createPawn(_prev: FormState, fd: FormData): Promise<FormState> {
  await requireUser();
  let id: string;
  try {
    const category = await assertCategory(fd.get("category"));
    const grossWeightMg = optionalWeight(fd, "gross", "Gross weight");
    const netWeightMg = weight(fd, "net", "Net weight");
    if (grossWeightMg != null && netWeightMg > grossWeightMg) {
      throw new FormError(
        `Net weight (${formatWeight(netWeightMg)}) cannot be more than gross weight (${formatWeight(grossWeightMg)}). ` +
          "Remember the mg box is milligrams: 500 mg = 0.5 g.",
      );
    }
    const assessedValue = money(fd, "assessedValue", "Assessed value");
    const principal = money(fd, "principal", "Principal amount");
    if (principal > assessedValue) throw new FormError("Principal cannot be more than the assessed value");
    const customer = {
      name: text(fd, "name", "Customer name", { required: true, max: 120 }),
      phone: phone(fd),
      address: text(fd, "address", "Address", { required: true, max: 300 }),
      nic: nic(fd),
    };
    const standard = oneOf(fd.get("standard"), PAWN_STANDARDS, "Standard");
    const monthlyRate = percent(fd, "monthlyRate", "Monthly interest rate");
    const durationMonths = wholeNumber(fd, "durationMonths", "Duration months", 120);
    const durationDays = wholeNumber(fd, "durationDays", "Duration days", 365);
    if (durationMonths + durationDays === 0) throw new FormError("Enter the loan duration in months and/or days");
    const notes = text(fd, "notes", "Notes", { max: 1000 });
    const { lockerCode, lockerSlot } = await readLockerFields(fd, { required: true });

    const ticketNo = `PW${padNumber(await nextSequence("pawn"))}`;
    const _id = new ObjectId();

    const today = todayISO();
    const now = new Date();
    const doc: PawnDoc = {
      _id,
      ticketNo,
      customer,
      category,
      standard,
      grossWeightMg,
      netWeightMg,
      assessedValue,
      principal,
      loanAmount: principal,
      monthlyRate,
      durationMonths,
      durationDays,
      dueDate: addDaysISO(addMonthsISO(today, durationMonths), durationDays),
      lockerCode: lockerCode!,
      lockerSlot,
      status: "active",
      pawnDate: today,
      interestPaidUntil: today,
      renewals: 0,
      notes,
      payments: [],
      createdAt: now,
      updatedAt: now,
      releasedAt: null,
    };
    const { pawns } = await getDb();
    await pawns.insertOne(doc);
    id = _id.toString();
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh(id);
  redirect(`/pawning/${id}?created=1`);
}

/** Pay Interest / Renewal: the customer pays the interest accrued up to today. */
export async function payPawnInterest(id: string, _prev: FormState, fd: FormData): Promise<FormState> {
  await requireUser();
  let receiptNo: string;
  try {
    const { pawns, pawn } = await loadActivePawn(id);
    const method = oneOf(fd.get("method"), PAY_METHODS.map((m) => m.value), "Payment method");
    const today = todayISO();
    const figures = pawnFigures(pawn, today);
    if (figures.accruedInterest <= 0) throw new FormError("No interest is due yet");
    receiptNo = await nextReceiptNo();
    const now = new Date();
    const result = await pawns.updateOne(
      // Matching interestPaidUntil stops the same interest being paid twice.
      { _id: pawn._id, status: "active", interestPaidUntil: pawn.interestPaidUntil },
      {
        $set: { interestPaidUntil: today, updatedAt: now },
        $inc: { renewals: 1 },
        $push: {
          payments: {
            receiptNo,
            type: "interest",
            amount: figures.accruedInterest,
            interest: figures.accruedInterest,
            principal: 0,
            days: figures.interestDays,
            periodFrom: figures.interestFrom,
            periodTo: today,
            method,
            paidAt: now,
          },
        },
      },
    );
    if (result.modifiedCount === 0) throw new FormError("This record was just updated. Please refresh.");
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh(id);
  return { success: "Interest paid and pawn renewed", receiptNo };
}

/**
 * Installment (part payment): clears the interest due up to today, and the rest
 * reduces the principal. The item stays in the locker; interest then runs on the
 * lower principal.
 */
export async function payPawnInstallment(id: string, _prev: FormState, fd: FormData): Promise<FormState> {
  await requireUser();
  let receiptNo: string;
  let principalAfter: number;
  try {
    const { pawns, pawn } = await loadActivePawn(id);
    const amount = money(fd, "amount", "Installment amount");
    const method = oneOf(fd.get("method"), PAY_METHODS.map((m) => m.value), "Payment method");
    const today = todayISO();
    const figures = pawnFigures(pawn, today);
    if (amount < figures.accruedInterest) {
      throw new FormError(`The installment must at least cover the interest due (${formatMoney(figures.accruedInterest)})`);
    }
    if (amount >= figures.settlementAmount) {
      throw new FormError(`That clears the whole loan (${formatMoney(figures.settlementAmount)}). Use Full Settlement & Release instead.`);
    }
    const principalPaid = round2(amount - figures.accruedInterest);
    principalAfter = round2(pawn.principal - principalPaid);
    receiptNo = await nextReceiptNo();
    const now = new Date();
    const result = await pawns.updateOne(
      // Matching both fields stops the same installment being applied twice.
      { _id: pawn._id, status: "active", interestPaidUntil: pawn.interestPaidUntil, principal: pawn.principal },
      {
        $set: { principal: principalAfter, interestPaidUntil: today, updatedAt: now },
        $push: {
          payments: {
            receiptNo,
            type: "installment",
            amount,
            interest: figures.accruedInterest,
            principal: principalPaid,
            principalAfter,
            days: figures.interestDays,
            periodFrom: figures.interestFrom,
            periodTo: today,
            method,
            paidAt: now,
          },
        },
      },
    );
    if (result.modifiedCount === 0) throw new FormError("This record was just updated. Please refresh.");
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh(id);
  return { success: `Installment saved. Loan balance is now ${formatMoney(principalAfter)}.`, receiptNo };
}

/** Full Settlement & Release: principal + accrued interest, then the locker is freed. */
export async function settlePawn(id: string, _prev: FormState, fd: FormData): Promise<FormState> {
  await requireUser();
  let receiptNo: string;
  try {
    const { pawns, pawn } = await loadActivePawn(id);
    if (fd.get("confirm") !== "on") throw new FormError("Tick the box to confirm the item is being released");
    const method = oneOf(fd.get("method"), PAY_METHODS.map((m) => m.value), "Payment method");
    const today = todayISO();
    const figures = pawnFigures(pawn, today);
    receiptNo = await nextReceiptNo();
    const now = new Date();
    const result = await pawns.updateOne(
      { _id: pawn._id, status: "active", interestPaidUntil: pawn.interestPaidUntil },
      {
        $set: { status: "released", interestPaidUntil: today, releasedAt: now, updatedAt: now },
        $push: {
          payments: {
            receiptNo,
            type: "settlement",
            amount: figures.settlementAmount,
            interest: figures.accruedInterest,
            principal: pawn.principal,
            days: figures.interestDays,
            periodFrom: figures.interestFrom,
            periodTo: today,
            method,
            paidAt: now,
          },
        },
      },
    );
    if (result.modifiedCount === 0) throw new FormError("This record was just updated. Please refresh.");
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh(id);
  return { success: "Settled in full. Item released from its locker.", receiptNo };
}
