"use server";

import { ObjectId } from "mongodb";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { readCartIds, writeCartIds } from "@/lib/cart";
import { assertCategory } from "@/lib/categories";
import { KARATS } from "@/lib/constants";
import { getDb, nextSequence, padNumber } from "@/lib/db";
import { errorMessage, FormError, money, oneOf, text, weight } from "@/lib/form";
import { readLockerFields } from "@/lib/lockers";
import { goldRatePrice } from "@/lib/pricing";
import { getLatestGoldRates } from "@/lib/rates";
import type { FormState, StockDoc } from "@/lib/types";

/**
 * "Daily gold rate" pricing stores making charge, wastage % and stone value, plus the
 * price at today's rates; "Fixed price" stores the price typed in.
 */
async function readPricing(fd: FormData): Promise<Pick<StockDoc, "price" | "pricing">> {
  if (fd.get("pricingMode") === "fixed") return { price: money(fd, "price", "Selling price"), pricing: null };
  const rates = await getLatestGoldRates();
  if (!rates) throw new FormError("Set today's gold rates (⚡ Set Rates in the top bar) before pricing by gold rate");
  const amount = (key: string, label: string) =>
    String(fd.get(key) ?? "").trim() ? money(fd, key, label, { allowZero: true }) : 0;
  const pricing = {
    makingCharge: amount("makingCharge", "Making charge"),
    wastagePercent: amount("wastagePercent", "Wastage"),
    stoneValue: amount("stoneValue", "Stone value"),
  };
  if (pricing.wastagePercent > 100) throw new FormError("Wastage must be 0–100%");
  const weightMg = weight(fd, "weight", "Weight");
  const karat = oneOf(Number(fd.get("karat")), KARATS, "Karat");
  return { price: goldRatePrice(weightMg, karat, pricing, rates).total, pricing };
}

async function readStockFields(fd: FormData) {
  const costRaw = String(fd.get("costPrice") ?? "").trim();
  return {
    name: text(fd, "name", "Item name", { required: true, max: 120 }),
    category: await assertCategory(fd.get("category")),
    karat: oneOf(Number(fd.get("karat")), KARATS, "Karat"),
    weightMg: weight(fd, "weight", "Weight"),
    ...(await readPricing(fd)),
    costPrice: costRaw ? money(fd, "costPrice", "Cost price", { allowZero: true }) : null,
    makerName: text(fd, "makerName", "Made by", { max: 120 }),
    location: text(fd, "location", "Location", { max: 80 }),
    notes: text(fd, "notes", "Notes", { max: 1000 }),
  };
}

async function loadItem(id: string) {
  if (!ObjectId.isValid(id)) throw new FormError("Item not found");
  const { stock } = await getDb();
  const item = await stock.findOne({ _id: new ObjectId(id) });
  if (!item) throw new FormError("Item not found");
  return { stock, item };
}

function refresh(id?: string) {
  if (id) revalidatePath(`/stock/${id}`);
  revalidatePath("/stock");
  revalidatePath("/dashboard");
  revalidatePath("/lockers");
}

export async function createStockItem(_prev: FormState, fd: FormData): Promise<FormState> {
  await requireUser();
  let id: string;
  try {
    const fields = await readStockFields(fd);
    // No locker = kept on open display.
    const locker = await readLockerFields(fd, { required: false });
    const _id = new ObjectId();
    const code = `ST${padNumber(await nextSequence("stock"))}`;
    const now = new Date();
    const doc: StockDoc = {
      ...fields,
      ...locker,
      _id,
      code,
      status: "in_stock",
      sale: null,
      createdAt: now,
      updatedAt: now,
    };
    const { stock } = await getDb();
    await stock.insertOne(doc);
    id = _id.toString();
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh(id);
  redirect(`/stock/${id}?created=1`);
}

export async function updateStockItem(id: string, _prev: FormState, fd: FormData): Promise<FormState> {
  await requireUser();
  try {
    const { stock, item } = await loadItem(id);
    if (item.status !== "in_stock") throw new FormError("Sold items can't be edited");
    const fields = await readStockFields(fd);
    const locker = await readLockerFields(fd, { required: false });
    await stock.updateOne({ _id: item._id, status: "in_stock" }, { $set: { ...fields, ...locker, updatedAt: new Date() } });
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh(id);
  return { success: "Item details saved" };
}

export async function deleteStockItem(id: string): Promise<FormState> {
  const user = await requireUser();
  try {
    if (user.role !== "admin") throw new FormError("Only admins can delete stock items");
    const { stock, item } = await loadItem(id);
    if (item.status !== "in_stock") throw new FormError("Sold items are kept for the sales record");
    await stock.deleteOne({ _id: item._id, status: "in_stock" });
    await writeCartIds((await readCartIds()).filter((x) => x !== id));
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh();
  redirect("/stock");
}
