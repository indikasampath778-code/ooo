"use server";

import { revalidatePath } from "next/cache";
import { getCurrentUser } from "@/lib/auth";
import { getDb } from "@/lib/db";
import { errorMessage, FormError, money } from "@/lib/form";
import { todayISO } from "@/lib/format";
import type { FormState } from "@/lib/types";

/** Saves today's gold rates per gram. Setting them again the same day replaces them. */
export async function setGoldRates(_prev: FormState, fd: FormData): Promise<FormState> {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== "admin") throw new FormError("Only admins can set the gold rates");
    const rate24 = money(fd, "rate24", "24K rate");
    const rate22 = money(fd, "rate22", "22K rate");
    const rate18 = money(fd, "rate18", "18K rate");
    if (!(rate24 >= rate22 && rate22 >= rate18)) throw new FormError("Rates should go 24K ≥ 22K ≥ 18K — please check the numbers");
    const { goldRates } = await getDb();
    await goldRates.updateOne(
      { _id: todayISO() },
      { $set: { rate24, rate22, rate18, updatedAt: new Date(), updatedBy: user.name } },
      { upsert: true },
    );
  } catch (error) {
    return { error: errorMessage(error) };
  }
  revalidatePath("/", "layout");
  return { success: "Today's gold rates saved" };
}
