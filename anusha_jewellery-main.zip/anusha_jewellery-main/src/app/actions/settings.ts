"use server";

import { ObjectId } from "mongodb";
import { revalidatePath } from "next/cache";
import { getCurrentUser, isOwnerUsername } from "@/lib/auth";
import { PAWN_STANDARDS, USER_ROLES, type UserRole } from "@/lib/constants";
import { getDb } from "@/lib/db";
import { errorMessage, FormError, money, nic, oneOf, optionalWeight, percent, phone, text, weight, wholeNumber } from "@/lib/form";
import { addDaysISO, addMonthsISO } from "@/lib/format";
import { hashPassword } from "@/lib/passwords";
import type { FormState, PawnDoc } from "@/lib/types";

async function adminOnly() {
  const user = await getCurrentUser();
  if (!user || user.role !== "admin") throw new FormError("Only admins can change settings");
  return user;
}

function done(success: string): FormState {
  revalidatePath("/", "layout");
  return { success };
}

/* ---------------- Item categories ---------------- */

function categoryCode(fd: FormData) {
  const code = text(fd, "code", "Code", { required: true, max: 4 }).toUpperCase();
  if (!/^[A-Z]{2,4}$/.test(code)) throw new FormError("Code must be 2–4 letters, e.g. RIN");
  return code;
}

export async function createCategory(_prev: FormState, fd: FormData): Promise<FormState> {
  try {
    await adminOnly();
    const code = categoryCode(fd);
    const name = text(fd, "name", "Name", { required: true, max: 40 });
    const { categories } = await getDb();
    if (await categories.findOne({ _id: code })) throw new FormError(`Code ${code} is already used`);
    await categories.insertOne({ _id: code, name, createdAt: new Date() });
    return done(`Added ${name} (${code})`);
  } catch (error) {
    return { error: errorMessage(error) };
  }
}

export async function updateCategory(code: string, _prev: FormState, fd: FormData): Promise<FormState> {
  try {
    await adminOnly();
    const name = text(fd, "name", "Name", { required: true, max: 40 });
    const { categories } = await getDb();
    const result = await categories.updateOne({ _id: code }, { $set: { name } });
    if (result.matchedCount === 0) throw new FormError("Category not found");
    return done(`Saved ${name}`);
  } catch (error) {
    return { error: errorMessage(error) };
  }
}

export async function deleteCategory(code: string): Promise<FormState> {
  try {
    await adminOnly();
    const { categories, orders, pawns, stock } = await getDb();
    const [orderCount, pawnCount, stockCount] = await Promise.all([
      orders.countDocuments({ category: code }),
      pawns.countDocuments({ category: code }),
      stock.countDocuments({ category: code }),
    ]);
    if (orderCount + pawnCount + stockCount > 0) {
      throw new FormError(`Can't delete ${code}: used by ${orderCount} order(s), ${pawnCount} pawn(s) and ${stockCount} stock item(s)`);
    }
    await categories.deleteOne({ _id: code });
    return done(`Deleted ${code}`);
  } catch (error) {
    return { error: errorMessage(error) };
  }
}

/* ---------------- Item makers ---------------- */

const caseInsensitive = { locale: "en", strength: 2 };

function makerFields(fd: FormData) {
  return {
    name: text(fd, "name", "Name", { required: true, max: 120 }),
    phone: text(fd, "phone", "Phone", { max: 30 }),
    note: text(fd, "note", "Note", { max: 200 }),
  };
}

function makerId(id: string) {
  if (!ObjectId.isValid(id)) throw new FormError("Maker not found");
  return new ObjectId(id);
}

export async function createMaker(_prev: FormState, fd: FormData): Promise<FormState> {
  try {
    await adminOnly();
    const fields = makerFields(fd);
    const { makers } = await getDb();
    if (await makers.findOne({ name: fields.name }, { collation: caseInsensitive })) {
      throw new FormError(`${fields.name} is already in the list`);
    }
    await makers.insertOne({ _id: new ObjectId(), ...fields, createdAt: new Date() });
    return done(`Added ${fields.name}`);
  } catch (error) {
    return { error: errorMessage(error) };
  }
}

/** Orders and stock store the maker's name, so a rename is copied onto them too. */
export async function updateMaker(id: string, _prev: FormState, fd: FormData): Promise<FormState> {
  try {
    await adminOnly();
    const fields = makerFields(fd);
    const { makers, orders, stock } = await getDb();
    const maker = await makers.findOne({ _id: makerId(id) });
    if (!maker) throw new FormError("Maker not found");
    const clash = await makers.findOne({ name: fields.name, _id: { $ne: maker._id } }, { collation: caseInsensitive });
    if (clash) throw new FormError(`${fields.name} is already in the list`);
    await makers.updateOne({ _id: maker._id }, { $set: fields });
    if (fields.name !== maker.name) {
      await Promise.all([
        orders.updateMany({ makerName: maker.name }, { $set: { makerName: fields.name } }),
        stock.updateMany({ makerName: maker.name }, { $set: { makerName: fields.name } }),
      ]);
    }
    return done(`Saved ${fields.name}`);
  } catch (error) {
    return { error: errorMessage(error) };
  }
}

export async function deleteMaker(id: string): Promise<FormState> {
  try {
    await adminOnly();
    const { makers, orders, stock } = await getDb();
    const maker = await makers.findOne({ _id: makerId(id) });
    if (!maker) throw new FormError("Maker not found");
    const [orderCount, stockCount] = await Promise.all([
      orders.countDocuments({ makerName: maker.name }),
      stock.countDocuments({ makerName: maker.name }),
    ]);
    if (orderCount + stockCount > 0) {
      throw new FormError(`Can't delete ${maker.name}: used by ${orderCount} order(s) and ${stockCount} stock item(s)`);
    }
    await makers.deleteOne({ _id: maker._id });
    return done(`Deleted ${maker.name}`);
  } catch (error) {
    return { error: errorMessage(error) };
  }
}

/* ---------------- Pawned items ---------------- */

/** Corrects a pawn's details. Ticket number, category and locker stay as they are. */
export async function updatePawn(id: string, _prev: FormState, fd: FormData): Promise<FormState> {
  try {
    await adminOnly();
    if (!ObjectId.isValid(id)) throw new FormError("Pawn record not found");
    const { pawns } = await getDb();
    const pawn = await pawns.findOne({ _id: new ObjectId(id) });
    if (!pawn) throw new FormError("Pawn record not found");

    const grossWeightMg = optionalWeight(fd, "gross", "Gross weight");
    const netWeightMg = weight(fd, "net", "Net weight");
    if (grossWeightMg != null && netWeightMg > grossWeightMg) throw new FormError("Net weight cannot be more than gross weight");
    const assessedValue = money(fd, "assessedValue", "Assessed value");
    const durationMonths = wholeNumber(fd, "durationMonths", "Duration months", 120);
    const durationDays = wholeNumber(fd, "durationDays", "Duration days", 365);
    if (durationMonths + durationDays === 0) throw new FormError("Enter the loan duration in months and/or days");

    const set: Partial<PawnDoc> = {
      customer: {
        name: text(fd, "name", "Customer name", { required: true, max: 120 }),
        nic: nic(fd),
        phone: phone(fd),
        address: text(fd, "address", "Address", { required: true, max: 300 }),
      },
      standard: oneOf(fd.get("standard"), PAWN_STANDARDS, "Standard"),
      grossWeightMg,
      netWeightMg,
      assessedValue,
      monthlyRate: percent(fd, "monthlyRate", "Monthly interest rate"),
      durationMonths,
      durationDays,
      dueDate: addDaysISO(addMonthsISO(pawn.pawnDate, durationMonths), durationDays),
      notes: text(fd, "notes", "Notes", { max: 1000 }),
      updatedAt: new Date(),
    };
    // Once money has changed hands the loan amount is fixed by the receipts.
    if (pawn.payments.length === 0) {
      const principal = money(fd, "principal", "Loan amount");
      set.principal = principal;
      set.loanAmount = principal;
    }
    const principalNow = set.principal ?? pawn.principal;
    if (principalNow > assessedValue) throw new FormError("Loan amount cannot be more than the assessed value");

    await pawns.updateOne({ _id: pawn._id }, { $set: set });
    return done(`Saved pawn ${pawn.ticketNo}`);
  } catch (error) {
    return { error: errorMessage(error) };
  }
}

/** Removes a pawn record completely (e.g. entered by mistake). */
export async function deletePawn(id: string): Promise<FormState> {
  try {
    await adminOnly();
    if (!ObjectId.isValid(id)) throw new FormError("Pawn record not found");
    const { pawns } = await getDb();
    const pawn = await pawns.findOne({ _id: new ObjectId(id) });
    if (!pawn) throw new FormError("Pawn record not found");
    await pawns.deleteOne({ _id: pawn._id });
    return done(`Deleted pawn ${pawn.ticketNo}`);
  } catch (error) {
    return { error: errorMessage(error) };
  }
}

/* ---------------- Users ---------------- */

function newPassword(fd: FormData) {
  const password = String(fd.get("password") ?? "");
  if (password.length < 8) throw new FormError("Password must be at least 8 characters");
  if (password !== String(fd.get("confirm") ?? "")) throw new FormError("The two passwords don't match");
  return password;
}

export async function createUser(_prev: FormState, fd: FormData): Promise<FormState> {
  try {
    await adminOnly();
    const username = text(fd, "username", "Username", { required: true, max: 30 }).toLowerCase();
    if (!/^[a-z0-9._-]{3,30}$/.test(username)) {
      throw new FormError("Username: 3–30 letters, numbers, dot, dash or underscore (no spaces)");
    }
    if (isOwnerUsername(username)) throw new FormError("That username is reserved for the owner account");
    const name = text(fd, "name", "Full name", { required: true, max: 80 });
    const role = oneOf(fd.get("role"), USER_ROLES.map((r) => r.value) as UserRole[], "Role");
    const password = newPassword(fd);
    const { users } = await getDb();
    if (await users.findOne({ _id: username })) throw new FormError(`Username ${username} is already taken`);
    await users.insertOne({ _id: username, name, role, passwordHash: await hashPassword(password), createdAt: new Date() });
    return done(`Created user ${username}`);
  } catch (error) {
    return { error: errorMessage(error) };
  }
}

export async function updateUser(username: string, _prev: FormState, fd: FormData): Promise<FormState> {
  try {
    const me = await adminOnly();
    const name = text(fd, "name", "Full name", { required: true, max: 80 });
    const role = oneOf(fd.get("role"), USER_ROLES.map((r) => r.value) as UserRole[], "Role");
    if (username === me.username && role !== "admin") throw new FormError("You can't remove your own admin access");
    const set: Record<string, string> = { name, role };
    if (String(fd.get("password") ?? "")) set.passwordHash = await hashPassword(newPassword(fd));
    const { users } = await getDb();
    const result = await users.updateOne({ _id: username }, { $set: set });
    if (result.matchedCount === 0) throw new FormError("User not found");
    return done(set.passwordHash ? `Saved ${username} and changed the password` : `Saved ${username}`);
  } catch (error) {
    return { error: errorMessage(error) };
  }
}

export async function deleteUser(username: string): Promise<FormState> {
  try {
    const me = await adminOnly();
    if (username === me.username) throw new FormError("You can't delete your own account");
    const { users } = await getDb();
    await users.deleteOne({ _id: username });
    return done(`Deleted user ${username}`);
  } catch (error) {
    return { error: errorMessage(error) };
  }
}
