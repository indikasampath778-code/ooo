"use server";

import { ObjectId } from "mongodb";
import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { cartLinesFromForm, getCartItems, saleItem, writeCartIds } from "@/lib/cart";
import { PAY_METHODS } from "@/lib/constants";
import { getDb, nextReceiptNo, nextSequence, padNumber } from "@/lib/db";
import { errorMessage, FormError, oneOf, optionalMoney, phone, text } from "@/lib/form";
import { isValidISODate, round2 } from "@/lib/format";
import { parseOldGold, sumOldGold } from "@/lib/oldGold";
import { reservationTotals } from "@/lib/reservations";
import type { FormState, OrderPayment, ReservationDoc } from "@/lib/types";

function refresh() {
  revalidatePath("/billing");
  revalidatePath("/stock");
  revalidatePath("/dashboard");
  revalidatePath("/lockers");
}

/** Cash/card part plus any old gold; together they are credited to the reservation. */
async function readPayment(fd: FormData, field = "amount"): Promise<Omit<OrderPayment, "receiptNo" | "paidAt"> | null> {
  const cash = optionalMoney(fd, field, "Amount");
  const oldGold = parseOldGold(String(fd.get("oldGold") ?? "[]"));
  const amount = round2(cash + sumOldGold(oldGold));
  if (amount <= 0) return null;
  return {
    amount,
    cash,
    oldGold,
    method: oneOf(fd.get("method"), PAY_METHODS.map((m) => m.value), "Payment method"),
    note: text(fd, "note", "Note", { max: 200 }),
  };
}

/** When the reservation is fully paid: the items become sold to the customer and leave their lockers. */
async function completeIfPaid(reservation: ReservationDoc, lastReceiptNo: string, soldBy: string) {
  const { balance } = reservationTotals(reservation);
  if (balance > 0) return false;
  const { stock, reservations } = await getDb();
  const now = new Date();
  const method = reservation.payments.at(-1)?.method ?? "cash";
  for (const line of reservation.items) {
    await stock.updateOne(
      { _id: line.stockId },
      {
        $set: {
          status: "sold",
          reservationId: null,
          lockerCode: null,
          sale: { receiptNo: lastReceiptNo, customer: reservation.customer, price: line.price, method, soldAt: now, soldBy },
          updatedAt: now,
        },
      },
    );
  }
  await reservations.updateOne({ _id: reservation._id }, { $set: { status: "completed", completedAt: now } });
  return true;
}

/** Billing → Shop sales: hold everything in the cart for a customer, with an optional first payment. */
export async function reserveCart(_prev: FormState, fd: FormData): Promise<FormState> {
  const user = await requireUser();
  const held: ObjectId[] = [];
  try {
    const items = await getCartItems();
    if (!items.length) throw new FormError("The cart is empty");
    const lines = cartLinesFromForm(items, fd);
    const customer = {
      name: text(fd, "customerName", "Customer name", { required: true, max: 120 }),
      phone: phone(fd, "customerPhone"),
    };
    const until = String(fd.get("reserveUntil") ?? "").trim();
    if (until && !isValidISODate(until)) throw new FormError("Enter a valid 'reserve until' date");
    const total = round2(lines.reduce((s, l) => s + l.price, 0));
    const first = await readPayment(fd);
    if (first && first.amount > total) throw new FormError("The first payment is more than the total");

    const _id = new ObjectId();
    const now = new Date();
    const { stock, reservations } = await getDb();
    for (const { item } of lines) {
      const result = await stock.updateOne(
        { _id: item._id, status: "in_stock" },
        { $set: { status: "reserved", reservationId: _id, updatedAt: now } },
      );
      if (result.modifiedCount === 0) throw new FormError(`${item.code} was just sold or reserved elsewhere`);
      held.push(item._id);
    }

    const receiptNo = first ? await nextReceiptNo() : undefined;
    const doc: ReservationDoc = {
      _id,
      code: `RS${padNumber(await nextSequence("reservation"))}`,
      items: lines.map(saleItem),
      customer,
      total,
      payments: first && receiptNo ? [{ ...first, receiptNo, paidAt: now }] : [],
      reserveUntil: until || null,
      notes: text(fd, "reservationNotes", "Notes", { max: 500 }),
      status: "active",
      createdAt: now,
      createdBy: user.name,
      completedAt: null,
      cancelledAt: null,
    };
    await reservations.insertOne(doc);
    await writeCartIds([]);
    const completed = receiptNo ? await completeIfPaid(doc, receiptNo, user.name) : false;
    refresh();
    return {
      success: completed
        ? `Paid in full, so ${doc.code} is complete and the items are sold.`
        : `Reserved as ${doc.code} for ${customer.name}. Balance ${reservationTotals(doc).balance.toLocaleString("en-LK", { minimumFractionDigits: 2 })}.`,
      receiptNo,
      reservationId: _id.toString(),
    };
  } catch (error) {
    if (held.length) {
      const { stock } = await getDb();
      await stock.updateMany({ _id: { $in: held } }, { $set: { status: "in_stock", reservationId: null, updatedAt: new Date() } });
    }
    return { error: errorMessage(error) };
  }
}

/** Billing → Reservations: an installment (cash and/or old gold). The last one completes the sale. */
export async function payReservation(id: string, _prev: FormState, fd: FormData): Promise<FormState> {
  const user = await requireUser();
  let receiptNo: string;
  let completed = false;
  try {
    if (!ObjectId.isValid(id)) throw new FormError("Reservation not found");
    const { reservations } = await getDb();
    const reservation = await reservations.findOne({ _id: new ObjectId(id) });
    if (!reservation) throw new FormError("Reservation not found");
    if (reservation.status !== "active") throw new FormError(`This reservation is ${reservation.status}`);
    const payment = await readPayment(fd);
    if (!payment) throw new FormError("Enter an amount or add old gold");
    const { balance } = reservationTotals(reservation);
    if (payment.amount > balance) throw new FormError("Payment is more than the balance due");
    receiptNo = await nextReceiptNo();
    const entry: OrderPayment = { ...payment, receiptNo, paidAt: new Date() };
    await reservations.updateOne({ _id: reservation._id, status: "active" }, { $push: { payments: entry } });
    completed = await completeIfPaid({ ...reservation, payments: [...reservation.payments, entry] }, receiptNo, user.name);
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh();
  return { success: completed ? "Fully paid — the items are sold. Hand them over to the customer." : "Payment saved", receiptNo };
}

/** Puts the items back in stock. Money already paid is shown so it can be refunded. */
export async function cancelReservation(id: string): Promise<FormState> {
  await requireUser();
  try {
    if (!ObjectId.isValid(id)) throw new FormError("Reservation not found");
    const { reservations, stock } = await getDb();
    const reservation = await reservations.findOne({ _id: new ObjectId(id) });
    if (!reservation || reservation.status !== "active") throw new FormError("Only active reservations can be cancelled");
    await reservations.updateOne({ _id: reservation._id }, { $set: { status: "cancelled", cancelledAt: new Date() } });
    await stock.updateMany(
      { reservationId: reservation._id, status: "reserved" },
      { $set: { status: "in_stock", reservationId: null, updatedAt: new Date() } },
    );
  } catch (error) {
    return { error: errorMessage(error) };
  }
  refresh();
  return { success: "Reservation cancelled. The items are back in stock." };
}
