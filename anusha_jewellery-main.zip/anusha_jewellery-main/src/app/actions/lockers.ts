"use server";

import { revalidatePath } from "next/cache";
import { getCurrentUser } from "@/lib/auth";
import { getDb } from "@/lib/db";
import { errorMessage, FormError, text } from "@/lib/form";
import type { FormState } from "@/lib/types";

async function adminOnly() {
  const user = await getCurrentUser();
  if (!user || user.role !== "admin") throw new FormError("Only admins can add or change lockers");
}

function readLocker(fd: FormData) {
  return {
    name: text(fd, "name", "Locker name", { required: true, max: 40 }),
    description: text(fd, "description", "Description", { max: 120 }),
  };
}

/** Another locker with the same name, ignoring upper/lower case. */
async function nameTaken(name: string, except?: string) {
  const { lockers } = await getDb();
  const same = await lockers.findOne({ _id: { $eq: name, ...(except ? { $ne: except } : {}) } }, { collation: { locale: "en", strength: 2 } });
  return Boolean(same);
}

function done(success: string): FormState {
  revalidatePath("/", "layout");
  return { success };
}

export async function createLocker(_prev: FormState, fd: FormData): Promise<FormState> {
  try {
    await adminOnly();
    const { name, description } = readLocker(fd);
    if (await nameTaken(name)) throw new FormError(`There is already a locker called ${name}`);
    const { lockers } = await getDb();
    const now = new Date();
    await lockers.insertOne({ _id: name, description, createdAt: now, updatedAt: now });
    return done(`Added locker ${name}`);
  } catch (error) {
    return { error: errorMessage(error) };
  }
}

/** Renames a locker and/or changes its description. Items inside move with it. */
export async function updateLocker(current: string, _prev: FormState, fd: FormData): Promise<FormState> {
  try {
    await adminOnly();
    const { name, description } = readLocker(fd);
    const { lockers, orders, pawns, stock } = await getDb();
    const locker = await lockers.findOne({ _id: current });
    if (!locker) throw new FormError("Locker not found");

    if (name === current) {
      await lockers.updateOne({ _id: current }, { $set: { description, updatedAt: new Date() } });
      return done(`Saved ${name}`);
    }
    if (await nameTaken(name, current)) throw new FormError(`There is already a locker called ${name}`);
    // The name is the _id, so a rename is a new document; items keep the name, so they follow it.
    await lockers.insertOne({ ...locker, _id: name, description, updatedAt: new Date() });
    const move = { $set: { lockerCode: name } };
    await Promise.all([
      orders.updateMany({ lockerCode: current }, move),
      pawns.updateMany({ lockerCode: current }, move),
      stock.updateMany({ lockerCode: current }, move),
    ]);
    await lockers.deleteOne({ _id: current });
    return done(`Renamed ${current} to ${name}`);
  } catch (error) {
    return { error: errorMessage(error) };
  }
}

export async function deleteLocker(name: string): Promise<FormState> {
  try {
    await adminOnly();
    const { lockers, orders, pawns, stock } = await getDb();
    const inside = await Promise.all([
      orders.countDocuments({ lockerCode: name }),
      pawns.countDocuments({ lockerCode: name, status: "active" }),
      stock.countDocuments({ lockerCode: name, status: { $ne: "sold" } }),
    ]);
    if (inside.some(Boolean)) throw new FormError("Move the items out of this locker first");
    await lockers.deleteOne({ _id: name });
    return done(`Deleted locker ${name}`);
  } catch (error) {
    return { error: errorMessage(error) };
  }
}
