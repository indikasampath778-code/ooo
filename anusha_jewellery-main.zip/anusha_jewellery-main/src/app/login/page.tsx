import type { Metadata } from "next";
import { login } from "@/app/actions/auth";
import ActionForm from "@/components/ActionForm";
import Logo from "@/components/Logo";
import { Field } from "@/components/ui";
import { SHOP } from "@/lib/constants";

export const metadata: Metadata = { title: "Staff Login | Anusha Jewellers" };

export default async function LoginPage(props: PageProps<"/login">) {
  const { next } = await props.searchParams;

  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-amber-950 p-4">
      <div className="w-full max-w-sm rounded-2xl bg-white p-8 shadow-2xl ring-2 ring-gold/60">
        <div className="text-center text-ink">
          <Logo className="mx-auto w-56" />
          <p className="font-sinhala text-lg font-semibold">{SHOP.nameSi}</p>
          <p className="mt-4 font-bold tracking-widest text-foreground/70">STAFF LOGIN</p>
        </div>
        <ActionForm action={login} submitLabel="Log in" submitClassName="btn-primary w-full" className="mt-6 space-y-4">
          <input type="hidden" name="next" value={typeof next === "string" ? next : ""} />
          <Field label="Username">
            <input name="username" className="input" autoComplete="username" required autoFocus />
          </Field>
          <Field label="Password">
            <input name="password" type="password" className="input" autoComplete="current-password" required />
          </Field>
        </ActionForm>
      </div>
    </main>
  );
}
