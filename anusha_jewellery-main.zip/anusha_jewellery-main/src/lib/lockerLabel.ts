/** "Safe A / Tray 2": where an item is kept, as shown on screen and on labels. */
export function lockerLabel(locker: string | null | undefined, slot?: string | null) {
  if (!locker) return null;
  return slot ? `${locker} / ${slot}` : locker;
}

/** Page that shows an item kept in a locker. */
export function lockerItemHref(item: { kind: "order" | "pawn" | "stock"; id: string }) {
  if (item.kind === "pawn") return `/pawning/${item.id}`;
  if (item.kind === "stock") return `/stock/${item.id}`;
  return `/orders/${item.id}`;
}
