import "server-only";
import { ObjectId, type Filter, type Sort } from "mongodb";
import { requireUser } from "./auth";
import { KARATS } from "./constants";
import { getDb } from "./db";
import { escapeRegex } from "./form";
import { round2, todayISO } from "./format";
import { livePrice, ratePerGram } from "./pricing";
import { getLatestGoldRates } from "./rates";
import type { StockDoc } from "./types";

/**
 * Items still for sale get today's price: rate-priced pieces follow the latest gold
 * rates, the rest keep their fixed price. Reserved and sold pieces keep their price.
 */
export async function withLivePrices<T extends Pick<StockDoc, "price" | "pricing" | "weightMg" | "karat" | "status">>(items: T[]) {
  if (!items.some((i) => i.pricing && i.status === "in_stock")) return items;
  const rates = await getLatestGoldRates();
  return items.map((i) => (i.pricing && i.status === "in_stock" ? { ...i, price: livePrice(i, rates) } : i));
}

export type StockFilter = "in_stock" | "reserved" | "sold" | "all";

export const STOCK_STATUSES: { value: StockFilter; label: string }[] = [
  { value: "in_stock", label: "In stock" },
  { value: "reserved", label: "Reserved" },
  { value: "sold", label: "Sold" },
  { value: "all", label: "All statuses" },
];

/**
 * Status, karat and search term of the Shop Stock list, from its URL (?status=&karat=&q=).
 * The list shows items in stock unless another status is chosen.
 */
export function readStockFilters(sp: Record<string, string | string[] | undefined>) {
  const status: StockFilter = STOCK_STATUSES.find((s) => s.value === sp.status)?.value ?? "in_stock";
  const karat = KARATS.find((k) => String(k) === sp.karat) ?? null;
  const category = typeof sp.category === "string" && /^[A-Z]{2,4}$/.test(sp.category) ? sp.category : null;
  const q = typeof sp.q === "string" ? sp.q.trim() : "";
  return { status, karat, category, q };
}

function searchFilter(q: string): Filter<StockDoc> {
  const pattern = new RegExp(escapeRegex(q), "i");
  return {
    $or: [
      { code: q.toUpperCase() },
      { code: pattern },
      { name: pattern },
      { category: q.toUpperCase() },
      { location: pattern },
      { lockerCode: pattern },
      { lockerSlot: pattern },
      { "sale.customer.name": pattern },
      { "sale.receiptNo": q.toUpperCase() },
    ],
  };
}

export async function listStock(filter: StockFilter, q: string, karat?: number | null, category?: string | null) {
  await requireUser();
  const { stock } = await getDb();
  const query: Filter<StockDoc> = {};
  if (filter !== "all") query.status = filter;
  if (karat) query.karat = karat;
  if (category) query.category = category;
  if (q) Object.assign(query, searchFilter(q));
  const sort: Sort = filter === "sold" ? { "sale.soldAt": -1 } : { createdAt: -1 };
  return withLivePrices(await stock.find(query).sort(sort).limit(300).toArray());
}

export async function searchStock(q: string) {
  await requireUser();
  if (!q) return [];
  const { stock } = await getDb();
  return withLivePrices(await stock.find(searchFilter(q)).sort({ status: 1, createdAt: -1 }).limit(30).toArray());
}

export async function getStockItem(id: string) {
  await requireUser();
  if (!ObjectId.isValid(id)) return null;
  const { stock } = await getDb();
  const item = await stock.findOne({ _id: new ObjectId(id) });
  return item && (await withLivePrices([item]))[0];
}

export async function getSaleByReceipt(receiptNo: string) {
  await requireUser();
  const { sales } = await getDb();
  return sales.findOne({ receiptNo });
}

/**
 * Stock on hand plus today's sales (Sri Lanka time). Counts cart sales, reservations
 * completed today, and single-item sales from before the cart, each once.
 */
export async function stockStats() {
  await requireUser();
  const { stock, sales, reservations } = await getDb();
  const since = new Date(Date.now() - 2 * 86_400_000);
  const [onHand, recentSales, recentSingle, recentReservations] = await Promise.all([
    stock.find({ status: { $in: ["in_stock", "reserved"] } }, { projection: { price: 1, pricing: 1, karat: 1, weightMg: 1, status: 1 } }).toArray(),
    sales.find({ soldAt: { $gte: since } }).toArray(),
    stock.find({ status: "sold", "sale.soldAt": { $gte: since } }, { projection: { sale: 1 } }).toArray(),
    reservations.find({ $or: [{ "payments.paidAt": { $gte: since } }, { completedAt: { $gte: since } }] }).toArray(),
  ]);
  const today = todayISO();
  const isToday = (d: Date | null | undefined) => Boolean(d) && todayISO(d!) === today;
  const inStock = onHand.filter((s) => s.status === "in_stock");
  const rates = await getLatestGoldRates();
  const reserved = onHand.filter((s) => s.status === "reserved");

  const salesToday = recentSales.filter((s) => isToday(s.soldAt));
  const otherReceipts = new Set([
    ...recentSales.map((s) => s.receiptNo),
    ...recentReservations.flatMap((r) => r.payments.map((p) => p.receiptNo)),
  ]);
  const singleToday = recentSingle.filter((s) => s.sale && !otherReceipts.has(s.sale.receiptNo) && isToday(s.sale.soldAt));
  const completedToday = recentReservations.filter((r) => r.status === "completed" && isToday(r.completedAt));
  const installmentsToday = recentReservations.flatMap((r) => r.payments.filter((p) => isToday(p.paidAt)));

  const goldLines = [...salesToday.flatMap((s) => s.oldGold), ...installmentsToday.flatMap((p) => p.oldGold ?? [])];
  return {
    count: inStock.length,
    // Gold value of everything in stock at the latest daily rates (selling prices if no rates yet).
    value: round2(inStock.reduce((sum, s) => sum + (rates ? (s.weightMg / 1000) * ratePerGram(rates, s.karat) : s.price), 0)),
    valueAtRate: Boolean(rates),
    weightMg: inStock.reduce((sum, s) => sum + s.weightMg, 0),
    reservedCount: reserved.length,
    soldTodayCount:
      salesToday.reduce((n, s) => n + s.items.length, 0) + singleToday.length + completedToday.reduce((n, r) => n + r.items.length, 0),
    soldTodayValue: round2(
      salesToday.reduce((sum, s) => sum + s.subtotal, 0) +
        singleToday.reduce((sum, s) => sum + (s.sale?.price ?? 0), 0) +
        completedToday.reduce((sum, r) => sum + r.total, 0),
    ),
    oldGoldTodayMg: goldLines.reduce((n, g) => n + g.weightMg, 0),
    oldGoldTodayValue: round2(goldLines.reduce((sum, g) => sum + g.value, 0)),
    // Money actually received today: cart sales after old gold, old single sales, and reservation installments.
    paidToday: round2(
      salesToday.reduce((sum, s) => sum + s.total, 0) +
        singleToday.reduce((sum, s) => sum + (s.sale?.price ?? 0), 0) +
        installmentsToday.reduce((sum, p) => sum + (p.cash ?? p.amount), 0),
    ),
  };
}
