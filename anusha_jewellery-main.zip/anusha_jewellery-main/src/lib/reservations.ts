import "server-only";
import { ObjectId, type Filter } from "mongodb";
import { requireUser } from "./auth";
import { getDb } from "./db";
import { escapeRegex } from "./form";
import { round2 } from "./format";
import type { ReservationDoc } from "./types";

export function reservationTotals(r: Pick<ReservationDoc, "total" | "payments">) {
  const paid = round2(r.payments.reduce((s, p) => s + p.amount, 0));
  return { paid, balance: round2(r.total - paid) };
}

function searchFilter(q: string): Filter<ReservationDoc> {
  const pattern = new RegExp(escapeRegex(q), "i");
  return {
    $or: [
      { code: q.toUpperCase() },
      { code: pattern },
      { "customer.name": pattern },
      { "customer.phone": pattern },
      { "items.code": q.toUpperCase() },
      { "items.name": pattern },
    ],
  };
}

export async function listReservations(status: ReservationDoc["status"] | "all", q: string) {
  await requireUser();
  const { reservations } = await getDb();
  const query: Filter<ReservationDoc> = {};
  if (status !== "all") query.status = status;
  if (q) Object.assign(query, searchFilter(q));
  return reservations.find(query).sort({ createdAt: -1 }).limit(200).toArray();
}

export async function getReservation(id: string) {
  await requireUser();
  if (!ObjectId.isValid(id)) return null;
  const { reservations } = await getDb();
  return reservations.findOne({ _id: new ObjectId(id) });
}
