import "server-only";
import { cache } from "react";
import { requireUser } from "./auth";
import { getDb } from "./db";

/** Most recent gold rates (today's if they have been set). Cached for one request. */
export const getLatestGoldRates = cache(async () => {
  await requireUser();
  const { goldRates } = await getDb();
  const [latest] = await goldRates.find().sort({ _id: -1 }).limit(1).toArray();
  return latest ?? null;
});
