import "server-only";
import { ObjectId, type Filter, type Sort } from "mongodb";
import { requireUser } from "./auth";
import { getDb } from "./db";
import { escapeRegex } from "./form";
import { addDaysISO, round2, todayISO } from "./format";
import type { OrderDoc } from "./types";

export function orderTotals(order: Pick<OrderDoc, "payments" | "completion">) {
  const paid = round2(order.payments.reduce((sum, p) => sum + p.amount, 0));
  const price = order.completion?.price ?? null;
  const balance = price == null ? null : round2(price - paid);
  return { paid, price, balance };
}

export type OrderFilter = "pending" | "active" | "ready" | "delivered" | "all";

export async function listOrders(filter: OrderFilter, q: string) {
  await requireUser();
  const { orders } = await getDb();
  const query: Filter<OrderDoc> = {};
  if (filter === "pending") query.status = "pending";
  if (filter === "active") query.status = "in_progress";
  if (filter === "ready") query.status = "completed";
  if (filter === "delivered") query.status = "delivered";
  if (q) Object.assign(query, searchFilter(q));
  // Work still to do is listed by delivery date, soonest first.
  const sort: Sort = filter === "pending" || filter === "active" ? { deliveryDate: 1 } : { createdAt: -1 };
  return orders.find(query).sort(sort).limit(200).toArray();
}

function searchFilter(q: string): Filter<OrderDoc> {
  const pattern = new RegExp(escapeRegex(q), "i");
  return {
    $or: [
      { billNo: pattern },
      { barcode: q.toUpperCase() },
      { lockerCode: pattern },
      { lockerSlot: pattern },
      { "customer.name": pattern },
      { "customer.phone": pattern },
    ],
  };
}

export async function searchOrders(q: string) {
  await requireUser();
  if (!q) return [];
  const { orders } = await getDb();
  return orders.find(searchFilter(q)).sort({ createdAt: -1 }).limit(30).toArray();
}

export async function getOrder(id: string) {
  await requireUser();
  if (!ObjectId.isValid(id)) return null;
  const { orders } = await getDb();
  return orders.findOne({ _id: new ObjectId(id) });
}

export async function orderStats() {
  await requireUser();
  const { orders } = await getDb();
  const today = todayISO();
  const [inProgress, dueSoon, overdue, ready] = await Promise.all([
    orders.countDocuments({ status: { $in: ["pending", "in_progress"] } }),
    orders.countDocuments({
      status: { $in: ["pending", "in_progress"] },
      deliveryDate: { $gt: today, $lte: addDaysISO(today, 7) },
    }),
    orders.countDocuments({ status: { $in: ["pending", "in_progress"] }, deliveryDate: { $lte: today } }),
    orders.countDocuments({ status: "completed" }),
  ]);
  return { inProgress, dueSoon, overdue, ready };
}
