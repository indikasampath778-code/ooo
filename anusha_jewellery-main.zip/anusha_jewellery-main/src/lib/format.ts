import { TIME_ZONE } from "./constants";

/** Weights are stored as whole milligrams. */
export function formatWeight(mg: number | null | undefined) {
  if (mg == null) return "—";
  return `${(mg / 1000).toFixed(3)} g`;
}

export function splitWeight(mg: number | null | undefined) {
  if (mg == null) return { g: "", mg: "" };
  return { g: String(Math.floor(mg / 1000)), mg: String(mg % 1000) };
}

export function formatMoney(amount: number | null | undefined) {
  if (amount == null) return "—";
  return `Rs. ${amount.toLocaleString("en-LK", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function round2(n: number) {
  return Math.round(n * 100) / 100;
}

/** Today's date in Sri Lanka as YYYY-MM-DD. */
export function todayISO(now = new Date()) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(now);
}

function isoToUTC(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return Date.UTC(y, m - 1, d);
}

/** Whole calendar days from `from` to `to` (both YYYY-MM-DD). */
export function daysBetween(from: string, to: string) {
  return Math.round((isoToUTC(to) - isoToUTC(from)) / 86_400_000);
}

export function addDaysISO(iso: string, days: number) {
  return new Date(isoToUTC(iso) + days * 86_400_000).toISOString().slice(0, 10);
}

/** Same day `months` later, clamped to the month's last day (31 Jan + 1 month = 28/29 Feb). */
export function addMonthsISO(iso: string, months: number) {
  const [y, m, d] = iso.split("-").map(Number);
  const lastDay = new Date(Date.UTC(y, m - 1 + months + 1, 0)).getUTCDate();
  return new Date(Date.UTC(y, m - 1 + months, Math.min(d, lastDay))).toISOString().slice(0, 10);
}

/** "3 months 10 days", "45 days", "—". */
export function formatDuration(months = 0, days = 0) {
  const parts = [];
  if (months) parts.push(`${months} month${months === 1 ? "" : "s"}`);
  if (days) parts.push(`${days} day${days === 1 ? "" : "s"}`);
  return parts.join(" ") || "—";
}

export function formatDate(iso: string | null | undefined) {
  if (!iso) return "—";
  return new Date(isoToUTC(iso)).toLocaleDateString("en-GB", {
    timeZone: "UTC",
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function formatDateTime(date: Date | null | undefined) {
  if (!date) return "—";
  return date.toLocaleString("en-GB", {
    timeZone: TIME_ZONE,
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function isValidISODate(value: string) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(isoToUTC(value));
}
