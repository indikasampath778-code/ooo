import "server-only";
import { cache } from "react";
import { requireUser } from "./auth";
import { getDb } from "./db";
import { FormError } from "./form";

/** Item categories, sorted by name. Cached for the length of one request. */
export const getCategories = cache(async () => {
  await requireUser();
  const { categories } = await getDb();
  const list = await categories.find().sort({ name: 1 }).toArray();
  return list.map((c) => ({ code: c._id, name: c.name }));
});

export type Category = Awaited<ReturnType<typeof getCategories>>[number];

/** code → name lookup, e.g. names.RIN === "Ring". Falls back to the code for deleted categories. */
export const getCategoryNames = cache(async () => {
  const names: Record<string, string> = {};
  for (const c of await getCategories()) names[c.code] = c.name;
  return (code: string) => names[code] ?? code;
});

export async function assertCategory(value: FormDataEntryValue | null) {
  const code = String(value ?? "");
  const { categories } = await getDb();
  if (!code || !(await categories.findOne({ _id: code }))) {
    throw new FormError("Choose a valid item category");
  }
  return code;
}
