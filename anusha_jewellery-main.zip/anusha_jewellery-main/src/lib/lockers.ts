import "server-only";
import { cache } from "react";
import { requireUser } from "./auth";
import { getDb } from "./db";
import { FormError, text } from "./form";

/** Something kept in a locker: unsold stock, a finished order waiting for pickup or an active pawn. */
export type LockerContent = {
  kind: "order" | "pawn" | "stock";
  id: string;
  ref: string; // stock code, bill or ticket number
  label: string; // item name or customer
  locker: string;
  slot: string;
};

/** An item looked up by its barcode or number, with where it is kept. */
export type LocatedItem = Omit<LockerContent, "locker"> & {
  locker: string | null;
  description: string; // the locker's description
  gone: string | null; // why it is no longer in a locker, e.g. "Sold"
};

const byName = { locale: "en", numericOrdering: true };

/** All lockers by name. Cached for one request (every edit form on a page lists them). */
export const listLockers = cache(async () => {
  await requireUser();
  const { lockers } = await getDb();
  return lockers.find({}).collation(byName).sort({ _id: 1 }).toArray();
});

/**
 * Locker and position chosen in a form. "" is no locker, which only shop stock
 * allows (pieces on open display); orders and pawns must go in a locker.
 */
export async function readLockerFields(fd: FormData, { required }: { required: boolean }) {
  const lockerCode = String(fd.get("locker") ?? "").trim();
  const lockerSlot = text(fd, "lockerSlot", "Position inside locker", { max: 60 });
  if (!lockerCode) {
    if (required) throw new FormError("Choose a locker");
    return { lockerCode: null, lockerSlot: "" };
  }
  const { lockers } = await getDb();
  if (!(await lockers.findOne({ _id: lockerCode }, { projection: { _id: 1 } }))) {
    throw new FormError(`Locker ${lockerCode} no longer exists`);
  }
  return { lockerCode, lockerSlot };
}

const inLocker = { lockerCode: { $nin: [null, ""] } };

/** Everything stored in lockers right now. */
export async function lockerContents(): Promise<LockerContent[]> {
  await requireUser();
  const { orders, pawns, stock } = await getDb();
  const [o, p, s] = await Promise.all([
    orders.find(inLocker).project<{ _id: unknown; billNo: string; customer: { name: string }; lockerCode: string; lockerSlot?: string }>(
      { billNo: 1, "customer.name": 1, lockerCode: 1, lockerSlot: 1 },
    ).toArray(),
    pawns.find({ status: "active" }).project<{ _id: unknown; ticketNo: string; customer: { name: string }; lockerCode: string; lockerSlot?: string }>(
      { ticketNo: 1, "customer.name": 1, lockerCode: 1, lockerSlot: 1 },
    ).toArray(),
    stock.find({ ...inLocker, status: { $ne: "sold" } }).project<{ _id: unknown; code: string; name: string; lockerCode: string; lockerSlot?: string }>(
      { code: 1, name: 1, lockerCode: 1, lockerSlot: 1 },
    ).toArray(),
  ]);
  const slot = (x: { lockerSlot?: string }) => x.lockerSlot ?? "";
  return [
    ...s.map((x) => ({ kind: "stock" as const, id: String(x._id), ref: x.code, label: x.name, locker: x.lockerCode, slot: slot(x) })),
    ...o.map((x) => ({ kind: "order" as const, id: String(x._id), ref: x.billNo, label: x.customer.name, locker: x.lockerCode, slot: slot(x) })),
    ...p.map((x) => ({ kind: "pawn" as const, id: String(x._id), ref: x.ticketNo, label: x.customer.name, locker: x.lockerCode, slot: slot(x) })),
  ].sort((a, b) => a.ref.localeCompare(b.ref, "en", { numeric: true }));
}

/** "Where is this item?": finds a piece by its stock code, order bill/barcode or pawn ticket number. */
export async function locateItem(query: string): Promise<LocatedItem | null> {
  await requireUser();
  const q = query.trim().toUpperCase();
  if (!q) return null;
  const { orders, pawns, stock, lockers } = await getDb();
  const [item, order, pawn] = await Promise.all([
    stock.findOne({ code: q }),
    orders.findOne({ $or: [{ billNo: q }, { barcode: q }] }),
    pawns.findOne({ ticketNo: q }),
  ]);

  let found: Omit<LocatedItem, "description"> | null = null;
  if (item) {
    found = {
      kind: "stock", id: item._id.toString(), ref: item.code, label: item.name,
      locker: item.status === "sold" ? null : (item.lockerCode ?? null), slot: item.lockerSlot ?? "",
      gone: item.status === "sold" ? "Sold" : null,
    };
  } else if (order) {
    const gone = order.status === "delivered" ? "Handed over to the customer" : order.status === "cancelled" ? "Order cancelled" : null;
    found = {
      kind: "order", id: order._id.toString(), ref: order.billNo, label: order.customer.name,
      locker: gone ? null : order.lockerCode, slot: order.lockerSlot ?? "",
      gone: gone ?? (order.lockerCode ? null : "Not in a locker yet (the item isn't finished or placed)"),
    };
  } else if (pawn) {
    const released = pawn.status !== "active";
    found = {
      kind: "pawn", id: pawn._id.toString(), ref: pawn.ticketNo, label: pawn.customer.name,
      locker: released ? null : pawn.lockerCode || null, slot: pawn.lockerSlot ?? "",
      gone: released ? "Released to the customer" : null,
    };
  }
  if (!found) return null;
  const locker = found.locker ? await lockers.findOne({ _id: found.locker }) : null;
  return { ...found, description: locker?.description ?? "" };
}
