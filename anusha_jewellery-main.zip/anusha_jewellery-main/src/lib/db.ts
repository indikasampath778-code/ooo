import "server-only";
import dns from "node:dns";
import { MongoClient, type Db } from "mongodb";
import { attachDatabasePool } from "@vercel/functions";
import { DEFAULT_CATEGORIES } from "./constants";
import type { CategoryDoc, CounterDoc, GoldRateDoc, LockerDoc, MakerDoc, OrderDoc, PawnDoc, ReservationDoc, SaleDoc, StockDoc, UserDoc } from "./types";

const cache = globalThis as unknown as {
  _mongoClient?: MongoClient;
  _mongoUri?: string;
  _mongoIndexes?: Promise<void>;
};

function getClient() {
  const uri = process.env.MONGODB_URI;
  if (!uri) throw new Error("MONGODB_URI is not set");
  // In dev the client survives reloads; start a new one if .env.local changed.
  if (cache._mongoClient && cache._mongoUri !== uri) {
    void cache._mongoClient.close().catch(() => {});
    cache._mongoClient = undefined;
    cache._mongoIndexes = undefined;
  }
  if (!cache._mongoClient) {
    if (process.env.MONGODB_DNS_SERVERS) {
      dns.setServers(process.env.MONGODB_DNS_SERVERS.split(",").map((s) => s.trim()));
    }
    // Opening a connection to Atlas takes over a second (TLS + auth), while a query on an
    // open one takes ~65 ms, so keep connections through the pauses between clicks.
    const client = new MongoClient(uri, { appName: "anusha-jewellers", maxIdleTimeMS: 10 * 60_000 });
    // Lets Vercel close idle connections before a function instance is suspended.
    attachDatabasePool(client);
    cache._mongoClient = client;
    cache._mongoUri = uri;
  }
  return cache._mongoClient;
}

async function ensureIndexes(db: Db) {
  await Promise.all([
    db.collection("orders").createIndexes([
      { key: { billNo: 1 }, unique: true },
      { key: { barcode: 1 }, sparse: true },
      { key: { status: 1, deliveryDate: 1 } },
      { key: { "customer.name": 1 } },
      { key: { "payments.receiptNo": 1 } },
    ]),
    db.collection("pawns").createIndexes([
      { key: { ticketNo: 1 }, unique: true },
      { key: { "customer.nic": 1 } },
      { key: { "customer.name": 1 } },
      { key: { status: 1 } },
      { key: { "payments.receiptNo": 1 } },
    ]),
    db.collection("stock").createIndexes([
      { key: { code: 1 }, unique: true },
      { key: { status: 1, createdAt: -1 } },
      { key: { "sale.receiptNo": 1 }, sparse: true },
    ]),
    db.collection("reservations").createIndexes([
      { key: { code: 1 }, unique: true },
      { key: { status: 1, createdAt: -1 } },
      { key: { "payments.receiptNo": 1 } },
    ]),
    db.collection("sales").createIndexes([
      { key: { receiptNo: 1 }, unique: true },
      { key: { soldAt: -1 } },
    ]),
    db.collection("makers").createIndexes([
      { key: { name: 1 }, unique: true, collation: { locale: "en", strength: 2 } },
    ]),
    db.collection("orders").createIndex({ makerName: 1 }),
    db.collection("stock").createIndex({ makerName: 1 }),
  ]);
  await convertNumberedLockers(db);

  // Save the starting item categories once. The marker stops deleted ones coming back.
  const firstRun = await db
    .collection<CounterDoc>("counters")
    .findOneAndUpdate({ _id: "seed:categories" }, { $setOnInsert: { seq: 1 } }, { upsert: true, returnDocument: "before" });
  if (!firstRun) {
    const now = new Date();
    await db
      .collection<CategoryDoc>("categories")
      .insertMany(DEFAULT_CATEGORIES.map((c) => ({ _id: c.code, name: c.name, createdAt: now })), { ordered: false })
      .catch(() => {}); // another instance may have inserted them at the same moment
  }
}

/** Shape of the one-item lockers (RIN-001, P-RIN-001, S-RIN2-001) used before named lockers. */
type NumberedLocker = {
  _id: string;
  pool?: "order" | "pawn" | "stock"; // missing on the oldest lockers
  category: string;
  set?: number;
  number: number;
  note?: string;
  item: { kind: string } | null;
};

/**
 * Turns the old numbered lockers into named ones: each locker set becomes one locker
 * (P-RIN, S-RIN2 …) and an item's old locker code is kept as its position inside it.
 */
async function convertNumberedLockers(db: Db) {
  const lockers = db.collection<NumberedLocker>("lockers");
  const old = await lockers.find({ number: { $exists: true } }).toArray();
  if (old.length === 0) return;

  const prefix = { order: "", pawn: "P-", stock: "S-" };
  const named = new Map<string, string>(); // name → description
  const moves = old.map((l) => {
    const set = l.set ?? 1;
    const pool = l.pool ?? (l.item?.kind === "pawn" ? "pawn" : "order");
    const name = `${prefix[pool]}${l.category}${set > 1 ? set : ""}`;
    if (!named.get(name)) named.set(name, l.note ?? "");
    return { updateMany: { filter: { lockerCode: l._id }, update: { $set: { lockerCode: name, lockerSlot: l._id } } } };
  });
  for (const collection of ["orders", "pawns", "stock"]) await db.collection(collection).bulkWrite(moves);

  const now = new Date();
  await db.collection<LockerDoc>("lockers").bulkWrite(
    [...named].map(([name, description]) => ({
      updateOne: {
        filter: { _id: name },
        update: { $setOnInsert: { description, createdAt: now, updatedAt: now } },
        upsert: true,
      },
    })),
  );
  await lockers.deleteMany({ number: { $exists: true } });
}

export async function getDb() {
  const db = getClient().db(process.env.MONGODB_DB ?? "anusha_jewellers");
  cache._mongoIndexes ??= ensureIndexes(db).catch((error) => {
    cache._mongoIndexes = undefined;
    throw error;
  });
  await cache._mongoIndexes;
  return {
    orders: db.collection<OrderDoc>("orders"),
    pawns: db.collection<PawnDoc>("pawns"),
    lockers: db.collection<LockerDoc>("lockers"),
    counters: db.collection<CounterDoc>("counters"),
    categories: db.collection<CategoryDoc>("categories"),
    makers: db.collection<MakerDoc>("makers"),
    goldRates: db.collection<GoldRateDoc>("goldRates"),
    stock: db.collection<StockDoc>("stock"),
    sales: db.collection<SaleDoc>("sales"),
    reservations: db.collection<ReservationDoc>("reservations"),
    users: db.collection<UserDoc>("users"),
  };
}

/** Atomically reserves `count` numbers from a named sequence and returns the last one. */
export async function nextSequence(name: string, count = 1) {
  const { counters } = await getDb();
  const doc = await counters.findOneAndUpdate(
    { _id: name },
    { $inc: { seq: count } },
    { upsert: true, returnDocument: "after" },
  );
  return doc!.seq;
}

export function padNumber(n: number, width = 6) {
  return String(n).padStart(width, "0");
}

export async function nextReceiptNo() {
  return `R${padNumber(await nextSequence("receipt"))}`;
}
