import type { OrderStatus } from "./constants";
import { daysBetween, round2, todayISO } from "./format";

export type Urgency = "red" | "orange" | "yellow" | null;

/**
 * Delivery highlight for orders still being made:
 * due today or overdue → red, within 3 days → orange, within 1 week → yellow.
 * Completed, delivered and cancelled orders are never highlighted.
 */
export function deliveryUrgency(
  status: OrderStatus,
  deliveryDate: string,
  today = todayISO(),
): Urgency {
  if (status !== "pending" && status !== "in_progress") return null;
  const daysLeft = daysBetween(today, deliveryDate);
  if (daysLeft <= 0) return "red";
  if (daysLeft <= 3) return "orange";
  if (daysLeft <= 7) return "yellow";
  return null;
}

export function deliveryLabel(deliveryDate: string, today = todayISO()) {
  const daysLeft = daysBetween(today, deliveryDate);
  if (daysLeft < 0) return `Overdue ${-daysLeft} day${daysLeft === -1 ? "" : "s"}`;
  if (daysLeft === 0) return "Due today";
  return `${daysLeft} day${daysLeft === 1 ? "" : "s"} left`;
}

/**
 * Pawn interest is charged at the monthly rate, pro-rated per day
 * (30-day month) since interest was last paid.
 */
export function accruedInterest(
  principal: number,
  monthlyRatePercent: number,
  fromISO: string,
  toISO = todayISO(),
) {
  const days = Math.max(0, daysBetween(fromISO, toISO));
  const amount = round2(((principal * monthlyRatePercent) / 100) * (days / 30));
  return { days, amount };
}
