import "server-only";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { cache } from "react";
import type { UserRole } from "./constants";
import { getDb } from "./db";
import { SESSION_COOKIE, verifySessionToken } from "./session";

export type CurrentUser = { username: string; name: string; role: UserRole; isOwner: boolean };

/** The owner account from ADMIN_USERNAME / ADMIN_PASSWORD; it always exists and is always an admin. */
export function isOwnerUsername(username: string) {
  return Boolean(process.env.ADMIN_USERNAME) && username === process.env.ADMIN_USERNAME;
}

/**
 * Signed-in user for this request, or null. Staff accounts are looked up each
 * request so a deleted user is signed out straight away.
 */
export const getCurrentUser = cache(async (): Promise<CurrentUser | null> => {
  const session = await verifySessionToken((await cookies()).get(SESSION_COOKIE)?.value);
  if (!session) return null;
  if (isOwnerUsername(session.username)) {
    return { username: session.username, name: session.username, role: "admin", isOwner: true };
  }
  const { users } = await getDb();
  const user = await users.findOne({ _id: session.username });
  if (!user) return null;
  return { username: user._id, name: user.name, role: user.role, isOwner: false };
});

/** Every page, data read and action calls this — the proxy check alone is not enough. */
export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

/** Settings pages and actions: admins only. */
export async function requireAdmin() {
  const user = await requireUser();
  if (user.role !== "admin") redirect("/dashboard");
  return user;
}
