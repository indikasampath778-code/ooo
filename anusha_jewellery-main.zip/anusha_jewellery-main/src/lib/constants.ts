export const SHOP = {
  name: "Anusha Jewellers",
  nameSi: "අනුෂා ජුවලර්ස්",
  address: "Malawa, Kuruwita",
  phone: "045 226 2751",
};

export const TIME_ZONE = "Asia/Colombo";

// Starting item categories, saved to the database on first run and then managed in
// Settings. Each category's code is also its locker prefix (RIN-001, EA-002, ...).
export const DEFAULT_CATEGORIES = [
  { code: "RIN", name: "Ring" },
  { code: "EA", name: "Earrings" },
  { code: "NEC", name: "Necklace" },
  { code: "CHA", name: "Chain" },
  { code: "BAN", name: "Bangle" },
  { code: "BRA", name: "Bracelet" },
  { code: "PEN", name: "Pendant" },
  { code: "ANK", name: "Anklet" },
  { code: "BRS", name: "Bridal Set" },
  { code: "OTH", name: "Other" },
] as const;

export const USER_ROLES = [
  { value: "admin", label: "Admin", hint: "Everything, including Settings" },
  { value: "staff", label: "Staff", hint: "Orders, billing, pawning and lockers" },
] as const;

export type UserRole = (typeof USER_ROLES)[number]["value"];

export const KARATS = [24, 22, 21, 18, 14] as const;

export const PAWN_STANDARDS = ["24K", "22K", "18K"] as const;
export type PawnStandard = (typeof PAWN_STANDARDS)[number];

export const ORDER_STATUSES = [
  { value: "pending", label: "Pending" },
  { value: "in_progress", label: "In Progress" },
  { value: "completed", label: "Completed" },
  { value: "delivered", label: "Delivered" },
  { value: "cancelled", label: "Cancelled" },
] as const;

export type OrderStatus = (typeof ORDER_STATUSES)[number]["value"];

export function statusLabel(status: string) {
  return ORDER_STATUSES.find((s) => s.value === status)?.label ?? status;
}

export const PAY_METHODS = [
  { value: "cash", label: "Cash" },
  { value: "card", label: "Card" },
  { value: "bank", label: "Bank Transfer" },
] as const;

export type PayMethod = (typeof PAY_METHODS)[number]["value"];

export function payMethodLabel(method: string) {
  return PAY_METHODS.find((m) => m.value === method)?.label ?? method;
}

/** Grams in one sovereign (pawn), used to show gold rates per sovereign. */
export const SOVEREIGN_GRAMS = 8;
