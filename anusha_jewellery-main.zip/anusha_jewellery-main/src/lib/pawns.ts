import "server-only";
import { ObjectId, type Filter } from "mongodb";
import { requireUser } from "./auth";
import { getDb } from "./db";
import { escapeRegex } from "./form";
import { daysBetween, round2, todayISO } from "./format";
import { accruedInterest } from "./rules";
import type { PawnDoc } from "./types";

/** Live figures for an active pawn as of today. */
export function pawnFigures(pawn: PawnDoc, today = todayISO()) {
  const daysElapsed = Math.max(0, daysBetween(pawn.pawnDate, today));
  // Until the first interest payment, interest always runs from the pawn date.
  const interestFrom = pawn.payments.length === 0 ? pawn.pawnDate : pawn.interestPaidUntil;
  const interest = accruedInterest(pawn.principal, pawn.monthlyRate, interestFrom, today);
  const interestPaid = round2(
    pawn.payments.reduce((sum, p) => sum + p.interest, 0),
  );
  return {
    daysElapsed,
    interestFrom,
    interestDays: interest.days,
    accruedInterest: pawn.status === "active" ? interest.amount : 0,
    settlementAmount: pawn.status === "active" ? round2(pawn.principal + interest.amount) : 0,
    interestPaid,
  };
}

/** Loan principal owed just before the given payment was made (installments reduce it over time). */
export function principalBefore(pawn: PawnDoc, receiptNo: string) {
  const index = pawn.payments.findIndex((p) => p.receiptNo === receiptNo);
  // Settlement leaves pawn.principal unchanged, so add back only later installments.
  const repaidLater = pawn.payments
    .slice(index)
    .filter((p) => p.type === "installment")
    .reduce((sum, p) => sum + p.principal, 0);
  return round2(pawn.principal + repaidLater);
}

function searchFilter(q: string): Filter<PawnDoc> {
  const pattern = new RegExp(escapeRegex(q), "i");
  return {
    $or: [
      { ticketNo: q.toUpperCase() },
      { ticketNo: pattern },
      { "customer.nic": q.toUpperCase() },
      { "customer.name": pattern },
      { "customer.phone": pattern },
      { lockerCode: pattern },
      { lockerSlot: pattern },
    ],
  };
}

export async function listPawns(status: "active" | "released" | "all", q: string) {
  await requireUser();
  const { pawns } = await getDb();
  const query: Filter<PawnDoc> = {};
  if (status !== "all") query.status = status;
  if (q) Object.assign(query, searchFilter(q));
  return pawns.find(query).sort({ pawnDate: 1, createdAt: 1 }).limit(500).toArray();
}

export async function searchPawns(q: string) {
  await requireUser();
  if (!q) return [];
  const { pawns } = await getDb();
  return pawns.find(searchFilter(q)).sort({ status: 1, createdAt: -1 }).limit(30).toArray();
}

export async function getPawn(id: string) {
  await requireUser();
  if (!ObjectId.isValid(id)) return null;
  const { pawns } = await getDb();
  return pawns.findOne({ _id: new ObjectId(id) });
}

export async function pawnStock() {
  await requireUser();
  const { pawns } = await getDb();
  const active = await pawns.find({ status: "active" }).toArray();
  const today = todayISO();
  const byStandard: Record<string, { count: number; netWeightMg: number }> = {};
  let principal = 0;
  let assessed = 0;
  let interest = 0;
  let netWeightMg = 0;
  for (const pawn of active) {
    principal += pawn.principal;
    assessed += pawn.assessedValue;
    netWeightMg += pawn.netWeightMg;
    interest += pawnFigures(pawn, today).accruedInterest;
    const s = (byStandard[pawn.standard] ??= { count: 0, netWeightMg: 0 });
    s.count += 1;
    s.netWeightMg += pawn.netWeightMg;
  }
  return {
    count: active.length,
    principal: round2(principal),
    assessed: round2(assessed),
    interest: round2(interest),
    netWeightMg,
    byStandard,
  };
}
