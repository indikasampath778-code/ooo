import { addDaysISO, addMonthsISO, round2 } from "./format";
import type { InstallmentPlan } from "./types";

export type InstallmentStatus = "paid" | "part" | "due" | "overdue" | "upcoming";

/** Equal installments of (total − advance); the last one absorbs the rounding. */
export function planDates(plan: Pick<InstallmentPlan, "total" | "count" | "frequency" | "firstDue" | "startPaid">) {
  const toPay = Math.max(0, round2(plan.total - plan.startPaid));
  const each = round2(toPay / plan.count);
  return Array.from({ length: plan.count }, (_, i) => ({
    no: i + 1,
    dueDate: plan.frequency === "weekly" ? addDaysISO(plan.firstDue, i * 7) : addMonthsISO(plan.firstDue, i),
    amount: i === plan.count - 1 ? round2(toPay - each * (plan.count - 1)) : each,
  }));
}

/**
 * Schedule with each installment's status. Everything paid after the advance is
 * applied to the installments in order, so paying early or in odd amounts still works.
 */
export function installmentSchedule(plan: InstallmentPlan, totalPaid: number, today: string) {
  let pool = Math.max(0, round2(totalPaid - plan.startPaid));
  const rows = planDates(plan).map((row) => {
    const paid = round2(Math.min(pool, row.amount));
    pool = round2(pool - paid);
    const status: InstallmentStatus =
      paid >= row.amount ? "paid"
      : row.dueDate < today ? "overdue"
      : row.dueDate === today ? "due"
      : paid > 0 ? "part"
      : "upcoming";
    return { ...row, paid, status };
  });
  const next = rows.find((r) => r.status !== "paid");
  return { rows, next: next ? { ...next, owed: round2(next.amount - next.paid) } : null };
}
