import type { ObjectId } from "mongodb";
import type { OrderStatus, PawnStandard, PayMethod, UserRole } from "./constants";

export type CounterDoc = { _id: string; seq: number };

/** A named place where pieces are kept (safe, tray, display unit). It holds any number of items. */
export type LockerDoc = {
  _id: string; // the locker's name, e.g. "Safe A"; items keep it in lockerCode
  description: string; // where it is, e.g. "Back room, top shelf"
  createdAt: Date;
  updatedAt: Date;
};

/** A piece made by the shop and kept in stock for sale. */
export type StockDoc = {
  _id: ObjectId;
  code: string; // also the barcode, e.g. ST000001
  name: string;
  category: string;
  karat: number;
  weightMg: number;
  price: number; // fixed selling price; for rate-priced items, the price when last saved
  /** Set when the price follows the daily gold rate (see lib/pricing). */
  pricing?: { makingCharge: number; wastagePercent: number; stoneValue: number } | null;
  costPrice: number | null; // optional, for the owner's reference
  makerName: string;
  location: string; // e.g. "Showcase 2"
  lockerCode?: string | null; // locker name; none for items on open display
  lockerSlot?: string; // position inside the locker, e.g. "Tray 2, slot 5"
  notes: string;
  status: "in_stock" | "reserved" | "sold";
  reservationId?: ObjectId | null; // set while held for a customer
  sale: {
    receiptNo: string;
    customer: { name: string; phone: string };
    price: number; // final price after any discount
    method: PayMethod;
    soldAt: Date;
    soldBy: string;
  } | null;
  createdAt: Date;
  updatedAt: Date;
};

/** Old gold the customer hands in. Its value (entered at the counter) is taken off the bill. */
export type OldGoldLine = {
  description: string;
  weightMg: number; // for reference only
  karat: number;
  ratePerGram?: number; // only on sales recorded before the value was entered directly
  value: number;
};

/** One checkout of one or more shop stock items (with any old gold exchange). */
export type SaleDoc = {
  _id: ObjectId;
  receiptNo: string;
  items: {
    stockId: ObjectId;
    code: string;
    name: string;
    category: string;
    karat: number;
    weightMg: number;
    listPrice: number;
    price: number;
    goldRate?: number; // rate per gram used at the counter
  }[];
  oldGold: OldGoldLine[];
  subtotal: number;
  oldGoldTotal: number;
  total: number; // amount the customer paid
  method: PayMethod;
  customer: { name: string; phone: string };
  soldAt: Date;
  soldBy: string;
};

/** Stock items held for a customer who pays in installments (lay-by). */
export type ReservationDoc = {
  _id: ObjectId;
  code: string; // e.g. RS000001
  items: SaleDoc["items"];
  customer: { name: string; phone: string };
  total: number; // agreed price of all items
  payments: OrderPayment[]; // cash and/or old gold, like order payments
  reserveUntil: string | null; // YYYY-MM-DD, optional
  notes: string;
  status: "active" | "completed" | "cancelled";
  createdAt: Date;
  createdBy: string;
  completedAt: Date | null;
  cancelledAt: Date | null;
};

export type CategoryDoc = {
  _id: string; // code, also the locker prefix, e.g. RIN
  name: string;
  createdAt: Date;
};

/** Goldsmith or supplier who makes items; orders and stock keep a copy of the name. */
export type MakerDoc = {
  _id: ObjectId;
  name: string;
  phone?: string;
  note?: string;
  createdAt: Date;
};

/** Gold rates per gram set each morning; one document per day. */
export type GoldRateDoc = {
  _id: string; // YYYY-MM-DD
  rate24: number;
  rate22: number;
  rate18: number;
  updatedAt: Date;
  updatedBy: string;
};

export type UserDoc = {
  _id: string; // username, lowercase
  name: string;
  role: UserRole;
  passwordHash: string;
  createdAt: Date;
};

export type OrderPayment = {
  receiptNo: string;
  amount: number; // total credited to the bill = cash + old gold
  cash?: number; // missing on payments made before old gold was accepted (then cash = amount)
  oldGold?: OldGoldLine[];
  method: PayMethod;
  note: string;
  paidAt: Date;
};

export type OrderDoc = {
  _id: ObjectId;
  billNo: string;
  customer: { name: string; phone: string; address: string };
  category: string;
  weightMg: number | null; // optional estimate when ordering
  karat: number;
  makerName: string;
  status: OrderStatus;
  deliveryDate: string; // YYYY-MM-DD
  notes: string;
  // price may be left empty when completing and set later (gold prices change day to day)
  completion: { finalWeightMg: number; karat: number; price: number | null; completedAt: Date } | null;
  lockerCode: string | null; // locker name
  lockerSlot?: string; // position inside the locker
  barcode: string | null;
  payments: OrderPayment[];
  installmentPlan?: InstallmentPlan | null;
  createdAt: Date;
  updatedAt: Date;
  deliveredAt: Date | null;
  cancelledAt?: Date | null; // missing on orders cancelled before this was recorded (updatedAt is used)
};

/** Agreed when the order is taken: the estimated price less the advance, split into equal installments. */
export type InstallmentPlan = {
  total: number; // estimated price of the order
  count: number;
  frequency: "weekly" | "monthly";
  firstDue: string; // YYYY-MM-DD
  startPaid: number; // advance already paid when the plan was made
};

export type PawnPayment = {
  receiptNo: string;
  // installment = part payment: clears the interest due, the rest reduces the principal
  type: "interest" | "installment" | "settlement";
  amount: number;
  interest: number;
  principal: number; // principal repaid by this payment
  principalAfter?: number; // loan balance left after an installment
  days: number;
  periodFrom: string;
  periodTo: string;
  method: PayMethod;
  paidAt: Date;
};

export type PawnDoc = {
  _id: ObjectId;
  ticketNo: string; // also the barcode
  customer: { name: string; phone: string; address: string; nic: string };
  category: string;
  standard: PawnStandard;
  grossWeightMg: number | null; // optional
  netWeightMg: number;
  assessedValue: number;
  principal: number; // loan still owed; installments reduce it
  loanAmount?: number; // principal lent on the pawn date (missing on older pawns = principal)
  monthlyRate: number; // percent per month
  durationMonths?: number; // agreed loan period
  durationDays?: number;
  dueDate?: string; // YYYY-MM-DD, pawn date + duration
  lockerCode: string; // locker name
  lockerSlot?: string; // position inside the locker
  status: "active" | "released";
  pawnDate: string; // YYYY-MM-DD
  interestPaidUntil: string; // YYYY-MM-DD
  renewals: number;
  notes: string;
  payments: PawnPayment[];
  createdAt: Date;
  updatedAt: Date;
  releasedAt: Date | null;
};

/** Shape returned by form server actions to useActionState. */
export type FormState = {
  error?: string;
  success?: string;
  receiptNo?: string;
  reservationId?: string;
};
