import type { GoldRateDoc, StockDoc } from "./types";

export type Rates = Pick<GoldRateDoc, "rate24" | "rate22" | "rate18">;
export type StockPricing = NonNullable<StockDoc["pricing"]>;

const round = (n: number) => Math.round(n * 100) / 100;

/** Rate per gram for a karat: the daily 24/22/18K rates, other karats in proportion to 24K. */
export function ratePerGram(rates: Rates, karat: number) {
  if (karat === 24) return rates.rate24;
  if (karat === 22) return rates.rate22;
  if (karat === 18) return rates.rate18;
  return round((rates.rate24 * karat) / 24);
}

/**
 * Price of a gold-rate priced item:
 * (weight × rate) + wastage % of the gold value + making charge + stone value.
 */
export function goldRatePrice(weightMg: number, karat: number, pricing: StockPricing, rates: Rates) {
  return priceAtRate(weightMg, ratePerGram(rates, karat), pricing);
}

/** Same formula with a given rate per gram (e.g. one typed at the counter). */
export function priceAtRate(weightMg: number, rate: number, pricing: StockPricing) {
  const gold = round((weightMg / 1000) * rate);
  const wastage = round((gold * pricing.wastagePercent) / 100);
  const total = Math.round(gold + wastage + pricing.makingCharge + pricing.stoneValue);
  return { rate, gold, wastage, making: pricing.makingCharge, stones: pricing.stoneValue, total };
}

/** Today's selling price: follows the gold rate when the item is rate-priced, otherwise its fixed price. */
export function livePrice(item: Pick<StockDoc, "price" | "pricing" | "weightMg" | "karat">, rates: Rates | null) {
  if (!item.pricing || !rates) return item.price;
  return goldRatePrice(item.weightMg, item.karat, item.pricing, rates).total;
}
