import "server-only";
import { requireUser } from "./auth";
import { getDb } from "./db";

export async function findReceipt(receiptNo: string) {
  await requireUser();
  const { orders, pawns, stock, sales, reservations } = await getDb();
  // A receipt number lives in exactly one collection; look in all of them at once.
  const [sale, reservation, order, pawn, item] = await Promise.all([
    sales.findOne({ receiptNo }),
    reservations.findOne({ "payments.receiptNo": receiptNo }),
    orders.findOne({ "payments.receiptNo": receiptNo }),
    pawns.findOne({ "payments.receiptNo": receiptNo }),
    // Single-item sales made before the cart existed.
    stock.findOne({ "sale.receiptNo": receiptNo }),
  ]);
  if (sale) return { kind: "sale" as const, sale };
  if (reservation) {
    const index = reservation.payments.findIndex((p) => p.receiptNo === receiptNo);
    return { kind: "reservation" as const, reservation, payment: reservation.payments[index], index };
  }
  if (order) {
    const payment = order.payments.find((p) => p.receiptNo === receiptNo)!;
    return { kind: "order" as const, order, payment };
  }
  if (pawn) {
    const payment = pawn.payments.find((p) => p.receiptNo === receiptNo)!;
    return { kind: "pawn" as const, pawn, payment };
  }
  if (item?.sale) return { kind: "stock" as const, item, sale: item.sale };
  return null;
}
