import { KARATS } from "./constants";
import { FormError, oneOf } from "./form";
import { round2 } from "./format";
import type { OldGoldLine } from "./types";

/** Reads the old gold lines sent by the OldGoldEditor (JSON in the 'oldGold' form field). */
export function parseOldGold(raw: string): OldGoldLine[] {
  let rows: unknown;
  try {
    rows = JSON.parse(raw || "[]");
  } catch {
    throw new FormError("Old gold details could not be read");
  }
  if (!Array.isArray(rows)) return [];
  return rows.map((row, i) => {
    const r = row as Record<string, unknown>;
    const weightMg = Number(r.weightMg ?? 0);
    const value = Number(r.value);
    const label = `Old gold line ${i + 1}`;
    if (!Number.isInteger(weightMg) || weightMg < 0) throw new FormError(`${label}: weight must be whole grams and 0–999 mg`);
    if (!Number.isFinite(value) || value <= 0) throw new FormError(`${label}: enter the old gold value`);
    // The weight is recorded for reference only; the value entered is what comes off the bill.
    return {
      description: String(r.description ?? "").trim().slice(0, 120) || "Old gold",
      weightMg,
      karat: oneOf(Number(r.karat), KARATS, "Karat"),
      value: round2(value),
    };
  });
}

export function sumOldGold(lines: OldGoldLine[]) {
  return round2(lines.reduce((s, g) => s + g.value, 0));
}
