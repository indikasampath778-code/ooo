import "server-only";
import { cache } from "react";
import { requireUser } from "./auth";
import { getDb } from "./db";

/** Item makers, sorted by name. Cached for the length of one request. */
export const getMakers = cache(async () => {
  await requireUser();
  const { makers } = await getDb();
  const list = await makers.find().collation({ locale: "en" }).sort({ name: 1 }).toArray();
  return list.map((m) => ({ id: m._id.toString(), name: m.name, phone: m.phone ?? "", note: m.note ?? "" }));
});

export type Maker = Awaited<ReturnType<typeof getMakers>>[number];
