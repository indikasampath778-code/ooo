import { isValidISODate } from "./format";

/** Thrown by the helpers below; actions turn it into a form error message. */
export class FormError extends Error {}

export function text(fd: FormData, key: string, label: string, opts: { required?: boolean; max?: number } = {}) {
  const value = String(fd.get(key) ?? "").trim();
  if (opts.required && !value) throw new FormError(`${label} is required`);
  if (value.length > (opts.max ?? 300)) throw new FormError(`${label} is too long`);
  return value;
}

export function money(fd: FormData, key: string, label: string, opts: { allowZero?: boolean } = {}) {
  const raw = String(fd.get(key) ?? "").replace(/,/g, "").trim();
  const value = Number(raw);
  if (!raw || !Number.isFinite(value) || value < 0 || (!opts.allowZero && value === 0)) {
    throw new FormError(`${label} must be a valid amount`);
  }
  return Math.round(value * 100) / 100;
}

export function optionalMoney(fd: FormData, key: string, label: string) {
  const raw = String(fd.get(key) ?? "").trim();
  return raw ? money(fd, key, label, { allowZero: true }) : 0;
}

export function percent(fd: FormData, key: string, label: string) {
  const value = Number(String(fd.get(key) ?? "").trim());
  if (!Number.isFinite(value) || value < 0 || value > 20) {
    throw new FormError(`${label} must be between 0 and 20`);
  }
  return value;
}

/** Whole number from 0 to `max`; an empty box counts as 0. */
export function wholeNumber(fd: FormData, key: string, label: string, max: number) {
  const value = Number(String(fd.get(key) ?? "").trim() || "0");
  if (!Number.isInteger(value) || value < 0 || value > max) {
    throw new FormError(`${label} must be a whole number from 0 to ${max}`);
  }
  return value;
}

/** Like `weight()`, but both boxes may be left empty (returns null). */
export function optionalWeight(fd: FormData, name: string, label: string) {
  const g = String(fd.get(`${name}_g`) ?? "").trim();
  const mg = String(fd.get(`${name}_mg`) ?? "").trim();
  if ((!g || g === "0") && (!mg || mg === "0")) return null;
  return weight(fd, name, label);
}

/** Reads a weight entered as separate gram and milligram boxes (`name_g`, `name_mg`). */
export function weight(fd: FormData, name: string, label: string) {
  const g = Number(String(fd.get(`${name}_g`) ?? "0").trim() || "0");
  const mg = Number(String(fd.get(`${name}_mg`) ?? "0").trim() || "0");
  if (!Number.isInteger(g) || g < 0 || !Number.isInteger(mg) || mg < 0 || mg > 999) {
    throw new FormError(`${label}: enter whole grams and 0–999 mg`);
  }
  const total = g * 1000 + mg;
  if (total === 0) throw new FormError(`${label} is required`);
  return total;
}

export function isoDate(fd: FormData, key: string, label: string) {
  const value = String(fd.get(key) ?? "").trim();
  if (!isValidISODate(value)) throw new FormError(`${label} is required`);
  return value;
}

export function oneOf<T extends string | number>(value: unknown, allowed: readonly T[], label: string): T {
  const match = allowed.find((a) => String(a) === String(value));
  if (match === undefined) throw new FormError(`Choose a valid ${label.toLowerCase()}`);
  return match;
}

export function phone(fd: FormData, key = "phone") {
  const value = text(fd, key, "Phone number", { required: true, max: 20 });
  if (!/^\+?[\d\s-]{9,15}$/.test(value)) throw new FormError("Enter a valid phone number");
  return value;
}

/** Sri Lankan NIC: old format 9 digits + V/X, new format 12 digits. */
export function nic(fd: FormData, key = "nic") {
  const value = text(fd, key, "NIC number", { required: true, max: 12 }).toUpperCase();
  if (!/^(\d{9}[VX]|\d{12})$/.test(value)) {
    throw new FormError("NIC must be 9 digits + V/X, or 12 digits");
  }
  return value;
}

export function escapeRegex(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function errorMessage(error: unknown) {
  if (error instanceof FormError) return error.message;
  if (typeof error === "object" && error && "code" in error && error.code === 11000) {
    return "That number is already used. Please use a different one.";
  }
  console.error(error);
  return "Something went wrong. Please try again.";
}
