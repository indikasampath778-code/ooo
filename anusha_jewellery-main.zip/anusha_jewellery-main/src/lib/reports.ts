import "server-only";
import { requireUser } from "./auth";
import { getCategoryNames } from "./categories";
import { getDb } from "./db";
import { addDaysISO, addMonthsISO, formatDate, formatMoney, formatWeight, todayISO } from "./format";
import { lockerLabel } from "./lockerLabel";

export type ReportKind = "stock" | "pawn" | "order";

export const REPORT_KINDS: { value: ReportKind; label: string; inLabel: string; outLabel: string; valueLabel: string | null }[] = [
  { value: "stock", label: "Shop stock", inLabel: "Added", outLabel: "Sold", valueLabel: "Value" },
  { value: "pawn", label: "Pawning", inLabel: "Pawned", outLabel: "Released", valueLabel: "Loan amount" },
  { value: "order", label: "Customer orders", inLabel: "New orders", outLabel: "Delivered / cancelled", valueLabel: null },
];

/** Count, gold weight and value of a group of items. */
export type Tally = { count: number; weightMg: number; value: number };

export type CategoryRow = { category: string; name: string; opening: Tally; in: Tally; out: Tally; closing: Tally };

export type ReportSection = { kind: ReportKind; rows: CategoryRow[]; total: Omit<CategoryRow, "category" | "name"> };

/** One item's time in the shop: from `inAt` until `outAt` (null = still here). */
type Movement = { category: string; weightMg: number; value: number; outValue: number; inAt: Date; outAt: Date | null };

/** Start of a Sri Lankan calendar day (YYYY-MM-DD). Sri Lanka is UTC+05:30 all year. */
function startOfDay(iso: string) {
  return new Date(`${iso}T00:00:00+05:30`);
}

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Report choices from the URL: "Stock on a date" (default, `date` = today) or the
 * movement report (`view=movement`, `from`–`to`, default the current month so far).
 */
export function readReportRange(sp: Record<string, string | string[] | undefined>) {
  const today = todayISO();
  const isoParam = (value: unknown) => (typeof value === "string" && ISO_DATE.test(value) ? value : null);
  let from = isoParam(sp.from) ?? `${today.slice(0, 8)}01`;
  let to = isoParam(sp.to) ?? today;
  if (from > to) [from, to] = [to, from];
  const date = isoParam(sp.date) ?? today;
  const view: "onhand" | "movement" = sp.view === "movement" ? "movement" : "onhand";
  const kind = REPORT_KINDS.find((k) => k.value === sp.type)?.value ?? null; // null = all
  return { view, date, from, to, kind };
}

const empty = (): Tally => ({ count: 0, weightMg: 0, value: 0 });

function add(t: Tally, weightMg: number, value: number) {
  t.count += 1;
  t.weightMg += weightMg;
  t.value += value;
}

/**
 * Opening stock at the start of `from`, items in and out during the range, and the
 * closing stock at the end of `to`, per item category.
 */
function tallyByCategory(kind: ReportKind, items: Movement[], from: string, to: string, name: (code: string) => string): ReportSection {
  const start = startOfDay(from);
  const end = startOfDay(addDaysISO(to, 1)); // exclusive
  const byCategory = new Map<string, CategoryRow>();
  const total = { opening: empty(), in: empty(), out: empty(), closing: empty() };

  for (const m of items) {
    if (m.inAt >= end) continue; // came in after the range
    if (m.outAt && m.outAt < start) continue; // gone before the range
    let row = byCategory.get(m.category);
    if (!row) byCategory.set(m.category, (row = { category: m.category, name: name(m.category), opening: empty(), in: empty(), out: empty(), closing: empty() }));

    const parts: (keyof typeof total)[] = [];
    if (m.inAt < start) parts.push("opening");
    else parts.push("in");
    if (m.outAt && m.outAt < end) parts.push("out");
    else parts.push("closing");
    for (const part of parts) {
      const value = part === "out" ? m.outValue : m.value;
      add(row[part], m.weightMg, value);
      add(total[part], m.weightMg, value);
    }
  }

  const rows = [...byCategory.values()].sort((a, b) => a.name.localeCompare(b.name));
  return { kind, rows, total };
}

/** A section as a table of text cells, shared by the Reports page and the PDF. */
export function reportTable(section: ReportSection) {
  const meta = REPORT_KINDS.find((k) => k.value === section.kind)!;
  const withValue = meta.valueLabel !== null;
  const groups = [
    { label: "Opening stock", span: 2 },
    { label: meta.inLabel, span: 2 },
    { label: meta.outLabel, span: withValue ? 3 : 2 },
    { label: "Closing stock", span: withValue ? 3 : 2 },
  ];
  const headers = ["Category", "Qty", "Weight", "Qty", "Weight", "Qty", "Weight", ...(withValue ? [meta.valueLabel!] : []), "Qty", "Weight", ...(withValue ? [meta.valueLabel!] : [])];
  const cells = (r: Omit<CategoryRow, "category" | "name">) => [
    String(r.opening.count), formatWeight(r.opening.weightMg),
    String(r.in.count), formatWeight(r.in.weightMg),
    String(r.out.count), formatWeight(r.out.weightMg), ...(withValue ? [formatMoney(r.out.value)] : []),
    String(r.closing.count), formatWeight(r.closing.weightMg), ...(withValue ? [formatMoney(r.closing.value)] : []),
  ];
  return {
    title: meta.label,
    groups,
    headers,
    rows: section.rows.map((r) => [`${r.name} (${r.category})`, ...cells(r)]),
    total: ["Total", ...cells(section.total)],
  };
}

/** An item's movement plus its details for the "Stock on a date" item list. */
type ListedMovement = Movement & { ref: string; detail: string[] };

/** Every shop stock item, pawn or order (by `kind`) with when it came in and went out. */
async function loadMovements(kind: ReportKind, name: (code: string) => string): Promise<ListedMovement[]> {
  const { stock, pawns, orders } = await getDb();
  if (kind === "stock") {
    const items = await stock.find({}).toArray();
    return items.map((s) => ({
      category: s.category,
      weightMg: s.weightMg,
      value: s.price,
      outValue: s.sale?.price ?? s.price,
      inAt: s.createdAt,
      outAt: s.sale?.soldAt ?? null,
      ref: s.code,
      detail: [s.code, s.name, name(s.category), `${s.karat}K`, formatWeight(s.weightMg), lockerLabel(s.lockerCode, s.lockerSlot) ?? s.location ?? "", formatMoney(s.price)],
    }));
  }
  if (kind === "pawn") {
    const items = await pawns.find({}).toArray();
    return items.map((p) => {
      const loan = p.loanAmount ?? p.principal;
      return {
        category: p.category,
        weightMg: p.netWeightMg,
        value: loan,
        outValue: loan,
        inAt: startOfDay(p.pawnDate),
        outAt: p.releasedAt,
        ref: p.ticketNo,
        detail: [p.ticketNo, p.customer.name, name(p.category), formatDate(p.pawnDate), formatWeight(p.netWeightMg), formatMoney(loan)],
      };
    });
  }
  const items = await orders.find({}).toArray();
  return items.map((o) => {
    const weightMg = o.completion?.finalWeightMg ?? o.weightMg ?? 0;
    return {
      category: o.category,
      weightMg,
      value: 0,
      outValue: 0,
      inAt: o.createdAt,
      outAt: o.status === "delivered" ? o.deliveredAt : o.status === "cancelled" ? (o.cancelledAt ?? o.updatedAt) : null,
      ref: o.billNo,
      detail: [o.billNo, o.customer.name, name(o.category), formatDate(todayISO(o.createdAt)), formatWeight(weightMg), formatDate(o.deliveryDate)],
    };
  });
}

const kindsFor = (kind: ReportKind | null) => (kind ? [kind] : REPORT_KINDS.map((k) => k.value));

/** Movement report: opening, in, out and closing stock per category between two dates. */
export async function stockReport(from: string, to: string, kind: ReportKind | null) {
  await requireUser();
  const name = await getCategoryNames();
  return Promise.all(kindsFor(kind).map(async (k) => tallyByCategory(k, await loadMovements(k, name), from, to, name)));
}

const ITEM_HEADERS: Record<ReportKind, string[]> = {
  stock: ["Item no.", "Name", "Category", "Karat", "Weight", "Locker / location", "Price"],
  pawn: ["Ticket no.", "Customer", "Category", "Pawn date", "Net weight", "Loan amount"],
  order: ["Bill no.", "Customer", "Category", "Order date", "Weight", "Delivery date"],
};

/** Stock on a date: what was on hand at the end of `date`, per category and item by item. */
export async function stockOnDate(date: string, kind: ReportKind | null) {
  await requireUser();
  const name = await getCategoryNames();
  const end = startOfDay(addDaysISO(date, 1));
  return Promise.all(
    kindsFor(kind).map(async (k) => {
      const meta = REPORT_KINDS.find((m) => m.value === k)!;
      const onHand = (await loadMovements(k, name))
        .filter((m) => m.inAt < end && (!m.outAt || m.outAt >= end))
        .sort((a, b) => name(a.category).localeCompare(name(b.category)) || a.ref.localeCompare(b.ref, "en", { numeric: true }));

      const byCategory = new Map<string, Tally>();
      const total = empty();
      for (const m of onHand) {
        if (!byCategory.has(m.category)) byCategory.set(m.category, empty());
        add(byCategory.get(m.category)!, m.weightMg, m.value);
        add(total, m.weightMg, m.value);
      }
      const withValue = meta.valueLabel !== null;
      const cells = (t: Tally) => [String(t.count), formatWeight(t.weightMg), ...(withValue ? [formatMoney(t.value)] : [])];
      return {
        kind: k,
        title: meta.label,
        summary: {
          headers: ["Category", "Qty", "Weight", ...(withValue ? [meta.valueLabel!] : [])],
          rows: [...byCategory].map(([code, t]) => [`${name(code)} (${code})`, ...cells(t)]),
          total: ["Total", ...cells(total)],
        },
        items: { headers: ITEM_HEADERS[k], rows: onHand.map((m) => m.detail) },
      };
    }),
  );
}

/** Last day of the month before `iso`'s month, and of `iso`'s own month. */
export function monthEnds(iso: string) {
  const firstOfMonth = `${iso.slice(0, 8)}01`;
  return { lastMonth: addDaysISO(firstOfMonth, -1), thisMonth: addDaysISO(addMonthsISO(firstOfMonth, 1), -1) };
}
