import "server-only";
import { ObjectId } from "mongodb";
import { cookies } from "next/headers";
import { requireUser } from "./auth";
import { getDb } from "./db";
import { FormError } from "./form";
import { round2 } from "./format";
import { withLivePrices } from "./stock";
import type { SaleDoc, StockDoc } from "./types";

/** The shop sales cart lives in a cookie on the counter computer: a list of stock item ids. */
export const CART_COOKIE = "aj_cart";
export const CART_LIMIT = 50;

export async function readCartIds() {
  const raw = (await cookies()).get(CART_COOKIE)?.value;
  if (!raw) return [];
  try {
    const ids = JSON.parse(raw);
    return Array.isArray(ids) ? ids.filter((id): id is string => typeof id === "string" && ObjectId.isValid(id)) : [];
  } catch {
    return [];
  }
}

export async function writeCartIds(ids: string[]) {
  (await cookies()).set(CART_COOKIE, JSON.stringify([...new Set(ids)].slice(0, CART_LIMIT)), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
}

/** Items in the cart that are still in stock, in the order they were added. */
export async function getCartItems() {
  await requireUser();
  const ids = await readCartIds();
  if (!ids.length) return [];
  const { stock } = await getDb();
  const docs = await stock.find({ _id: { $in: ids.map((id) => new ObjectId(id)) }, status: "in_stock" }).toArray();
  // Prices are today's (gold-rate priced pieces follow the latest rates).
  const priced = await withLivePrices(docs);
  return ids.map((id) => priced.find((d) => d._id.toString() === id)).filter((d) => d !== undefined);
}

/** Prices typed in the checkout form (price_<id>), one per cart item. */
export function cartLinesFromForm(items: StockDoc[], fd: FormData) {
  return items.map((item) => {
    const raw = String(fd.get(`price_${item._id}`) ?? "").replace(/,/g, "").trim();
    const price = Number(raw);
    if (!raw || !Number.isFinite(price) || price <= 0) throw new FormError(`Enter a price for ${item.code}`);
    const rate = Number(String(fd.get(`rate_${item._id}`) ?? "").replace(/,/g, "").trim());
    return { item, price: round2(price), goldRate: Number.isFinite(rate) && rate > 0 ? round2(rate) : undefined };
  });
}

/** The item snapshot kept on sales and reservations. */
export function saleItem({ item, price, goldRate }: { item: StockDoc; price: number; goldRate?: number }): SaleDoc["items"][number] {
  return {
    stockId: item._id,
    code: item.code,
    name: item.name,
    category: item.category,
    karat: item.karat,
    weightMg: item.weightMg,
    listPrice: item.price,
    price,
    ...(goldRate ? { goldRate } : {}),
  };
}
