import Link from "next/link";
import { addOrderPayment, placeOrderInLocker, setOrderPrice } from "@/app/actions/orders";
import ActionForm from "@/components/ActionForm";
import ClickableRow from "@/components/ClickableRow";
import LockerFields from "@/components/LockerFields";
import MakerSelect from "@/components/MakerSelect";
import OrderPaymentFields from "@/components/OrderPaymentFields";
import StatusSelect from "@/components/StatusSelect";
import { Field, StatusBadge, UrgencyBadge, urgencyRow } from "@/components/ui";
import WeightInput from "@/components/WeightInput";
import { KARATS, PAY_METHODS, payMethodLabel } from "@/lib/constants";
import { getCategories, getCategoryNames } from "@/lib/categories";
import { lockerLabel } from "@/lib/lockerLabel";
import { formatDate, formatDateTime, formatMoney, formatWeight, todayISO } from "@/lib/format";
import { installmentSchedule, type InstallmentStatus } from "@/lib/installments";
import { orderTotals } from "@/lib/orders";
import { deliveryLabel, deliveryUrgency } from "@/lib/rules";
import type { OrderDoc } from "@/lib/types";

/**
 * Inputs shared by the new-order and edit-order forms. `wide` lays them out in
 * four columns (three rows) for the full-width New Order page.
 */
export async function OrderFields({ order, wide = false }: { order?: OrderDoc; wide?: boolean }) {
  const categories = await getCategories();
  return (
    <div className={`grid gap-4 sm:grid-cols-2 ${wide ? "lg:grid-cols-4" : ""}`}>
      <Field label="Customer name">
        <input name="name" className="input" required defaultValue={order?.customer.name} />
      </Field>
      <Field label="Phone number">
        <input name="phone" type="tel" className="input" required defaultValue={order?.customer.phone} placeholder="07X XXX XXXX" />
      </Field>
      <Field label="Address" className="sm:col-span-2">
        <input name="address" className="input" defaultValue={order?.customer.address} />
      </Field>
      <Field label="Bill number">
        <input
          name="billNo"
          className="input uppercase"
          required={Boolean(order)}
          defaultValue={order?.billNo}
          placeholder={order ? undefined : "Leave blank to auto-generate"}
        />
      </Field>
      <Field label="Item category">
        <select name="category" className="input" defaultValue={order?.category ?? categories[0]?.code}>
          {categories.map((c) => (
            <option key={c.code} value={c.code}>
              {c.name} ({c.code})
            </option>
          ))}
        </select>
      </Field>
      <WeightInput name="weight" label="Weight (optional)" defaultMg={order?.weightMg} required={false} />
      <Field label="Number of carats">
        <select name="karat" className="input" defaultValue={order?.karat ?? 22}>
          {KARATS.map((k) => (
            <option key={k} value={k}>
              {k}K
            </option>
          ))}
        </select>
      </Field>
      <MakerSelect label="Item maker name" required defaultValue={order?.makerName} />
      <Field label="Delivery date">
        <input
          name="deliveryDate"
          type="date"
          className="input"
          required
          defaultValue={order?.deliveryDate}
          min={order ? undefined : todayISO()}
        />
      </Field>
      <Field label="Notes (design, size, etc.)" className="sm:col-span-2">
        <textarea name="notes" rows={wide ? 1 : 2} className="input" defaultValue={order?.notes} />
      </Field>
    </div>
  );
}

export function PayMethodSelect({ name = "method" }: { name?: string }) {
  return (
    <select name={name} className="input" defaultValue="cash">
      {PAY_METHODS.map((m) => (
        <option key={m.value} value={m.value}>
          {m.label}
        </option>
      ))}
    </select>
  );
}

/** Advance, installment or final payment for an order (cash and/or old gold). */
export function OrderPaymentForm({ order, submitLabel = "Save payment" }: { order: OrderDoc; submitLabel?: string }) {
  const { balance, paid } = orderTotals(order);
  const next = order.installmentPlan ? installmentSchedule(order.installmentPlan, paid, todayISO()).next : null;
  return (
    <OrderPaymentFields
      action={addOrderPayment.bind(null, order._id.toString())}
      balance={balance}
      canHandOver={order.status === "completed"}
      submitLabel={submitLabel}
      suggested={next ? { label: `Pay installment ${next.no}`, amount: balance == null ? next.owed : Math.min(next.owed, balance), note: `Installment ${next.no}` } : undefined}
    />
  );
}

const installmentStyles: Record<InstallmentStatus, [string, string]> = {
  paid: ["Paid", "bg-emerald-50 text-emerald-800 ring-emerald-200"],
  part: ["Part paid", "bg-blue-50 text-blue-800 ring-blue-200"],
  due: ["Due today", "bg-amber-50 text-amber-800 ring-amber-200"],
  overdue: ["Overdue", "bg-rose-50 text-rose-700 ring-rose-200"],
  upcoming: ["Upcoming", "bg-slate-100 text-slate-600 ring-slate-300"],
};

/** Installment plan agreed when the order was taken, with what has been paid against it. */
export function InstallmentSchedule({ order }: { order: OrderDoc }) {
  const plan = order.installmentPlan;
  if (!plan) return null;
  const { rows } = installmentSchedule(plan, orderTotals(order).paid, todayISO());
  return (
    <div>
      <h3 className="mb-1 text-sm font-semibold text-ink">Installment plan</h3>
      <p className="mb-2 text-xs text-foreground/60">
        Estimated {formatMoney(plan.total)} − advance {formatMoney(plan.startPaid)}, {plan.count} {plan.frequency} installments
      </p>
      <div className="overflow-x-auto rounded-xl border border-slate-200">
        <table className="table">
          <thead><tr><th>#</th><th>Due</th><th className="text-right">Amount</th><th className="text-right">Paid</th><th>Status</th></tr></thead>
          <tbody>
            {rows.map((r) => {
              const [label, style] = installmentStyles[r.status];
              return (
                <tr key={r.no}>
                  <td>{r.no}</td>
                  <td className="whitespace-nowrap">{formatDate(r.dueDate)}</td>
                  <td className="text-right whitespace-nowrap">{formatMoney(r.amount)}</td>
                  <td className="text-right whitespace-nowrap">{formatMoney(r.paid)}</td>
                  <td><span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold whitespace-nowrap ring-1 ${style}`}>{label}</span></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/** Puts a completed order's item in a locker and generates its barcode. */
export function OrderLockerForm({ order }: { order: OrderDoc }) {
  return (
    <ActionForm action={placeOrderInLocker.bind(null, order._id.toString())} submitLabel="Put in locker & generate barcode" submitClassName="btn-primary w-full">
      <LockerFields required />
    </ActionForm>
  );
}

/** Set or change the final price of a completed order (left empty when it was completed). */
export function OrderPriceForm({ order }: { order: OrderDoc }) {
  const price = order.completion?.price ?? null;
  return (
    <ActionForm
      action={setOrderPrice.bind(null, order._id.toString())}
      submitLabel={price == null ? "Save final price" : "Change price"}
      submitClassName="btn-primary w-full"
      className="space-y-3"
    >
      {price == null && (
        <p className="rounded-lg bg-amber-50 p-3 text-sm text-amber-900 ring-1 ring-amber-200">
          The final price is not set yet. Enter it (at today&apos;s gold rate) before taking the final payment.
        </p>
      )}
      <Field label="Final price (Rs.)">
        <input name="price" type="number" min="0.01" step="0.01" className="input" required defaultValue={price ?? undefined} />
      </Field>
    </ActionForm>
  );
}

export function PaymentSummary({ order }: { order: OrderDoc }) {
  const { paid, price, balance } = orderTotals(order);
  return (
    <dl className="space-y-1.5 rounded-xl bg-canvas p-3 text-sm">
      <div className="flex justify-between gap-4">
        <dt className="text-foreground/60">Price</dt>
        <dd className="font-bold whitespace-nowrap">{price == null ? "Not set yet" : formatMoney(price)}</dd>
      </div>
      <div className="flex justify-between gap-4">
        <dt className="text-foreground/60">Paid</dt>
        <dd className="font-bold whitespace-nowrap text-emerald-700">{formatMoney(paid)}</dd>
      </div>
      <div className="flex justify-between gap-4 border-t border-slate-200 pt-1.5 text-base">
        <dt className="font-semibold">Balance</dt>
        <dd className={`font-bold whitespace-nowrap ${balance ? "text-red-700" : ""}`}>{balance == null ? "—" : formatMoney(balance)}</dd>
      </div>
    </dl>
  );
}

export function PaymentHistory({ order }: { order: OrderDoc }) {
  if (order.payments.length === 0) return <p className="text-sm text-foreground/50">No payments yet.</p>;
  return (
    <ul className="divide-y divide-slate-100 text-sm">
      {order.payments.map((p) => (
        <li key={p.receiptNo} className="flex items-center justify-between gap-2 py-2">
          <div>
            <p className="font-semibold">{formatMoney(p.amount)}</p>
            <p className="text-xs text-foreground/60">
              {formatDateTime(p.paidAt)} · {payMethodLabel(p.method)}
              {p.oldGold && p.oldGold.length > 0 && ` · incl. old gold ${formatMoney(p.amount - (p.cash ?? 0))}`}
              {p.note && ` · ${p.note}`}
            </p>
          </div>
          <a href={`/print/receipt/${p.receiptNo}`} className="text-xs font-semibold text-ink underline">
            {p.receiptNo}
          </a>
        </li>
      ))}
    </ul>
  );
}

export async function OrdersTable({ orders, linkBase = "/orders", bare = false }: {
  orders: OrderDoc[];
  linkBase?: string;
  /** Render without its own card frame, for use inside another card. */
  bare?: boolean;
}) {
  const today = todayISO();
  const categoryName = await getCategoryNames();
  return (
    <div className={`overflow-x-auto ${bare ? "" : "rounded-2xl border border-slate-200 bg-white shadow-sm"}`}>
      <table className="table">
        <thead>
          <tr>
            <th>Bill No</th>
            <th>Customer details</th>
            <th>Item specs</th>
            <th>Item maker</th>
            <th>Delivery date</th>
            <th>Status</th>
            <th className="text-right">Balance</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => {
            const urgency = deliveryUrgency(order.status, order.deliveryDate, today);
            const { balance } = orderTotals(order);
            const href = linkBase === "/orders" ? `/orders/${order._id}` : `${linkBase}?id=${order._id}`;
            return (
              <ClickableRow key={order._id.toString()} href={href} className={urgency ? urgencyRow[urgency] : "hover:bg-canvas/70"}>
                <td>
                  <Link href={href} className="font-semibold text-ink underline decoration-gold underline-offset-2">
                    {order.billNo}
                  </Link>
                </td>
                <td>
                  <p className="font-medium">{order.customer.name}</p>
                  <p className="text-xs text-foreground/60">{order.customer.phone}</p>
                </td>
                <td>
                  <p className="font-medium whitespace-nowrap">
                    {categoryName(order.category)} ({order.completion?.karat ?? order.karat}K)
                  </p>
                  <p className="max-w-xs truncate text-xs text-foreground/60">
                    {formatWeight(order.completion?.finalWeightMg ?? order.weightMg)}
                    {order.notes && ` • ${order.notes}`}
                  </p>
                </td>
                <td className="whitespace-nowrap">{order.makerName}</td>
                <td className="whitespace-nowrap">
                  <span className="flex items-center gap-2">
                    {formatDate(order.deliveryDate)}
                    <UrgencyBadge urgency={urgency} label={deliveryLabel(order.deliveryDate, today)} />
                  </span>
                </td>
                <td className="whitespace-nowrap">
                  <span className="flex items-center gap-2">
                    {order.status === "pending" || order.status === "in_progress" ? (
                      <StatusSelect id={order._id.toString()} status={order.status} />
                    ) : (
                      <StatusBadge status={order.status} />
                    )}
                    {order.lockerCode && <span className="text-xs font-semibold text-ink">{lockerLabel(order.lockerCode, order.lockerSlot)}</span>}
                  </span>
                </td>
                <td className="text-right whitespace-nowrap">{balance == null ? "—" : formatMoney(balance)}</td>
              </ClickableRow>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
