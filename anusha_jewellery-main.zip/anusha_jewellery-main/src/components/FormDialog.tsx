"use client";

import { useSearchParams } from "next/navigation";
import { useEffect, useRef, type ReactNode } from "react";

/**
 * Button that opens its children (usually a form) in a popup dialog on the same
 * screen. Clicking the backdrop doesn't close it, so typed values aren't lost.
 */
export default function FormDialog({ label, title, buttonClassName = "btn-gold", width = "lg", children }: {
  label: ReactNode;
  title: string;
  buttonClassName?: string;
  width?: "sm" | "lg";
  children: ReactNode;
}) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const close = () => dialogRef.current?.close();

  // A save that returns to this same screen (e.g. /orders?created=…) closes the popup
  // and clears the form for the next entry.
  const params = useSearchParams().toString();
  useEffect(() => {
    dialogRef.current?.close();
    dialogRef.current?.querySelectorAll("form").forEach((form) => form.reset());
  }, [params]);

  return (
    <>
      <button type="button" onClick={() => dialogRef.current?.showModal()} className={buttonClassName}>
        {label}
      </button>
      <dialog
        ref={dialogRef}
        aria-label={title}
        className={`m-auto max-h-[92vh] ${width === "sm" ? "w-[min(94vw,28rem)]" : "w-[min(94vw,64rem)]"} overflow-y-auto rounded-2xl bg-white p-6 text-slate-900 shadow-2xl backdrop:bg-slate-950/70`}
      >
        <div className="mb-4 flex items-start justify-between border-b border-slate-200 pb-3">
          <h2 className="text-base font-bold">{title}</h2>
          <button type="button" onClick={close} aria-label="Close" className="text-lg text-slate-400 hover:text-slate-700">
            &times;
          </button>
        </div>
        {children}
      </dialog>
    </>
  );
}
