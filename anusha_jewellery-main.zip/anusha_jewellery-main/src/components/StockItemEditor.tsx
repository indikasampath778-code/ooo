"use client";

import { useState, type ReactNode } from "react";
import ActionForm from "@/components/ActionForm";
import CancelButton from "@/components/CancelButton";
import type { FormState } from "@/lib/types";

/**
 * A stock item opens as a read-only preview; "Edit" swaps in the form, whose button
 * then reads "Save changes". A successful save returns to the (refreshed) preview.
 */
export default function StockItemEditor({ action, preview, fields, deleteButton }: {
  action: (state: FormState, formData: FormData) => Promise<FormState>;
  preview: ReactNode;
  fields: ReactNode;
  deleteButton?: ReactNode;
}) {
  const [editing, setEditing] = useState(false);
  const [saved, setSaved] = useState("");

  if (!editing) {
    return (
      <div className="space-y-4">
        {saved && (
          <p role="status" className="rounded-lg border border-emerald-300 bg-emerald-50 px-3 py-2 text-sm font-medium text-emerald-800">
            {saved}
          </p>
        )}
        {preview}
        <div className="flex flex-wrap items-center justify-end gap-2">
          <CancelButton fallback="/stock" />
          {deleteButton}
          <button
            type="button"
            className="btn-primary"
            onClick={() => {
              setSaved("");
              setEditing(true);
            }}
          >
            Edit
          </button>
        </div>
      </div>
    );
  }

  return (
    <ActionForm
      action={action}
      submitLabel="Save changes"
      onSuccess={(message) => {
        setSaved(message);
        setEditing(false);
      }}
      beforeSubmit={
        <>
          <button type="button" className="btn-outline" onClick={() => setEditing(false)}>
            Cancel
          </button>
          {deleteButton}
        </>
      }
    >
      {fields}
    </ActionForm>
  );
}
