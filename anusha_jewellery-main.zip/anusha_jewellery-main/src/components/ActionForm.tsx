"use client";

import { startTransition, useActionState, useEffect, useRef, type ReactNode } from "react";
import type { FormState } from "@/lib/types";

type ActionFormProps = {
  action: (state: FormState, formData: FormData) => Promise<FormState>;
  children: ReactNode;
  submitLabel: string;
  submitClassName?: string;
  className?: string;
  confirmMessage?: string;
  /** Extra buttons before the submit button (type="button"); the row is then right-aligned. */
  beforeSubmit?: ReactNode;
  /** Called with the success message after a successful save. */
  onSuccess?: (message: string) => void;
};

/**
 * Form wired to a server action. Submits through a transition (instead of the
 * native form action) so typed values survive a validation error; the form
 * resets only after a successful save.
 */
export default function ActionForm({
  action,
  children,
  submitLabel,
  submitClassName = "btn-primary",
  className = "space-y-4",
  confirmMessage,
  beforeSubmit,
  onSuccess,
}: ActionFormProps) {
  const [state, formAction, pending] = useActionState(action, {});
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (!state.success) return;
    formRef.current?.reset();
    onSuccess?.(state.success);
    // Only when a new result arrives.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  return (
    <form
      ref={formRef}
      className={className}
      onSubmit={(event) => {
        event.preventDefault();
        if (confirmMessage && !window.confirm(confirmMessage)) return;
        const formData = new FormData(event.currentTarget);
        startTransition(() => formAction(formData));
      }}
    >
      {children}

      {state.error && (
        <p role="alert" className="rounded-lg border border-red-300 bg-red-50 px-3 py-2 text-sm font-medium text-red-800">
          {state.error}
        </p>
      )}
      {state.success && (
        <div role="status" className="flex flex-wrap items-center gap-3 rounded-lg border border-emerald-300 bg-emerald-50 px-3 py-2 text-sm font-medium text-emerald-800">
          <span>{state.success}</span>
          {state.receiptNo && (
            <a href={`/print/receipt/${state.receiptNo}`} className="btn-primary px-3 py-1">
              Print receipt {state.receiptNo}
            </a>
          )}
        </div>
      )}

      {beforeSubmit ? (
        <div className="flex flex-wrap items-center justify-end gap-2">
          {beforeSubmit}
          <button type="submit" disabled={pending} className={submitClassName}>
            {pending ? "Saving…" : submitLabel}
          </button>
        </div>
      ) : (
        <button type="submit" disabled={pending} className={submitClassName}>
          {pending ? "Saving…" : submitLabel}
        </button>
      )}
    </form>
  );
}
