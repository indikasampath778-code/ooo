"use client";

import JsBarcode from "jsbarcode";
import { useEffect, useRef } from "react";

/** CODE128 barcode that stretches to fill its box (bar ratios are kept). */
export default function Barcode({ value, className }: { value: string; className?: string }) {
  const ref = useRef<SVGSVGElement>(null);

  useEffect(() => {
    const svg = ref.current;
    if (!svg) return;
    JsBarcode(svg, value, { format: "CODE128", displayValue: false, margin: 0, height: 40, width: 2 });
    const width = svg.getAttribute("width");
    const height = svg.getAttribute("height");
    if (width && height && !svg.getAttribute("viewBox")) {
      svg.setAttribute("viewBox", `0 0 ${parseFloat(width)} ${parseFloat(height)}`);
    }
    svg.removeAttribute("width");
    svg.removeAttribute("height");
    svg.setAttribute("preserveAspectRatio", "none");
  }, [value]);

  return <svg ref={ref} className={className} aria-label={`Barcode ${value}`} role="img" />;
}
