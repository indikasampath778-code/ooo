type LogoProps = {
  className?: string;
};

// Vector recreation of the Anusha Jewellers box stamp: curved name over an
// "A.J" monogram hanging inside a beaded necklace.
export default function Logo({ className }: LogoProps) {
  return (
    <svg
      viewBox="0 0 400 230"
      role="img"
      aria-label="Anusha Jewellers"
      className={className}
    >
      <defs>
        <path id="logo-arc" d="M48,200 A152,152 0 0,1 352,200" />
      </defs>

      <text
        fill="currentColor"
        fontSize="36"
        fontWeight="700"
        letterSpacing="3"
        style={{ fontFamily: "var(--font-cinzel)" }}
      >
        <textPath href="#logo-arc" startOffset="50%" textAnchor="middle">
          ANUSHA JEWELLERS
        </textPath>
      </text>

      {/* Necklace chain */}
      <path
        d="M138,104 C138,196 262,196 262,104"
        fill="none"
        stroke="currentColor"
        strokeWidth="7"
        strokeLinecap="round"
        strokeDasharray="0.1 10"
      />
      <path
        d="M132,98 C132,206 268,206 268,98"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
      />

      {/* Pendant */}
      <circle cx="200" cy="184" r="7" fill="currentColor" />
      <path d="M200,190 L208,202 L200,214 L192,202 Z" fill="currentColor" />

      <text
        x="200"
        y="146"
        textAnchor="middle"
        fill="currentColor"
        fontSize="42"
        fontWeight="700"
        style={{ fontFamily: "var(--font-cinzel)" }}
      >
        A.J
      </text>
    </svg>
  );
}
