"use client";

import { useEffect, useRef, useState } from "react";
import { goldRatePrice, type Rates } from "@/lib/pricing";
import type { StockDoc } from "@/lib/types";

const rs = (n: number) => `Rs. ${n.toLocaleString("en-LK", { maximumFractionDigits: 2 })}`;

/**
 * Selling price for a stock item: it follows the daily gold rate
 * (weight × rate + wastage % + making charge + stones). When editing an existing
 * item it can be switched to a fixed price instead.
 * Reads weight and carats from the rest of the form for the live preview.
 */
export default function StockPriceFields({ item, rates, showCost = false, wide = false }: {
  item?: Pick<StockDoc, "pricing" | "weightMg" | "karat" | "price">;
  rates: Rates | null;
  /** Show cost price and margin (admins only). */
  showCost?: boolean;
  /** Inside the four-column form: span the full width. */
  wide?: boolean;
}) {
  const ref = useRef<HTMLFieldSetElement>(null);
  const [mode, setMode] = useState<"rate" | "fixed">(item && !item.pricing ? "fixed" : "rate");
  const [making, setMaking] = useState(String(item?.pricing?.makingCharge ?? ""));
  const [wastage, setWastage] = useState(String(item?.pricing?.wastagePercent ?? ""));
  const [stones, setStones] = useState(String(item?.pricing?.stoneValue ?? ""));
  const [shape, setShape] = useState({ weightMg: item?.weightMg ?? 0, karat: item?.karat ?? 22 });
  // Cost price and fixed price as typed, for the cost / margin lines.
  const [cost, setCost] = useState(0);
  const [fixedPrice, setFixedPrice] = useState(item?.price ?? 0);

  // Follow the weight and carats boxes elsewhere in the same form.
  useEffect(() => {
    const form = ref.current?.form;
    if (!form) return;
    const read = () => {
      const g = Number((form.elements.namedItem("weight_g") as HTMLInputElement | null)?.value) || 0;
      const mg = Number((form.elements.namedItem("weight_mg") as HTMLInputElement | null)?.value) || 0;
      const karat = Number((form.elements.namedItem("karat") as HTMLSelectElement | null)?.value) || 22;
      setShape({ weightMg: g * 1000 + mg, karat });
      setCost(Number((form.elements.namedItem("costPrice") as HTMLInputElement | null)?.value) || 0);
      const price = form.elements.namedItem("price") as HTMLInputElement | null;
      if (price) setFixedPrice(Number(price.value) || 0);
    };
    read();
    // Read after React has handled the keystroke. Updating state during the native event,
    // before React sees it, re-renders first and puts the typed box back to its old value.
    let timer: ReturnType<typeof setTimeout> | undefined;
    const later = () => {
      clearTimeout(timer);
      timer = setTimeout(read, 0);
    };
    form.addEventListener("input", later);
    form.addEventListener("change", later);
    return () => {
      clearTimeout(timer);
      form.removeEventListener("input", later);
      form.removeEventListener("change", later);
    };
  }, []);

  const preview =
    rates && shape.weightMg > 0
      ? goldRatePrice(shape.weightMg, shape.karat, {
          makingCharge: Number(making) || 0,
          wastagePercent: Number(wastage) || 0,
          stoneValue: Number(stones) || 0,
        }, rates)
      : null;

  return (
    <fieldset ref={ref} className={`space-y-3 rounded-xl border border-slate-200 p-3 sm:col-span-2 ${wide ? "lg:col-span-4" : ""}`}>
      <input type="hidden" name="pricingMode" value={mode} />
      {/* New items are always priced by the gold rate; only existing items can be fixed-price. */}
      {item && (
        <>
          <legend className="px-1 text-sm font-semibold text-ink">Selling price</legend>
          <div className="flex w-fit gap-1 rounded-lg bg-slate-100 p-1">
            {(["rate", "fixed"] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMode(m)}
                className={`rounded-md px-3 py-1.5 text-sm font-semibold ${mode === m ? "bg-ink text-white shadow-sm" : "text-ink hover:bg-white"}`}
              >
                {m === "rate" ? "Daily gold rate" : "Fixed price"}
              </button>
            ))}
          </div>
        </>
      )}

      {mode === "rate" ? (
        // Charges on the left, the price breakdown beside them on wide screens.
        <div className="grid gap-3 lg:grid-cols-2 lg:items-start">
          <div className="space-y-2">
            <div className="grid gap-3 sm:grid-cols-3">
              <label className="block">
                <span className="label">Making charge (Rs.)</span>
                <input name="makingCharge" type="number" min="0" step="0.01" className="input" value={making} onChange={(e) => setMaking(e.target.value)} placeholder="0" />
              </label>
              <label className="block">
                <span className="label">Wastage (%)</span>
                <input name="wastagePercent" type="number" min="0" max="100" step="0.1" className="input" value={wastage} onChange={(e) => setWastage(e.target.value)} placeholder="0" />
              </label>
              <label className="block">
                <span className="label">Stone value (Rs.)</span>
                <input name="stoneValue" type="number" min="0" step="0.01" className="input" value={stones} onChange={(e) => setStones(e.target.value)} placeholder="0" />
              </label>
            </div>
            <p className="text-xs text-foreground/50">The price updates automatically whenever the daily gold rates change.</p>
          </div>
          {!rates ? (
            <p className="rounded-lg bg-amber-50 p-3 text-sm text-amber-900 ring-1 ring-amber-200">
              No gold rates set yet. Set today&apos;s rates with ⚡ Set Rates in the top bar first.
            </p>
          ) : preview ? (
            <dl className="space-y-0.5 rounded-xl bg-canvas px-3 py-2 text-sm">
              <div className="flex justify-between"><dt className="text-foreground/60">Gold ({(shape.weightMg / 1000).toFixed(3)} g × {rs(preview.rate)})</dt><dd>{rs(preview.gold)}</dd></div>
              <div className="flex justify-between"><dt className="text-foreground/60">Wastage</dt><dd>{rs(preview.wastage)}</dd></div>
              <div className="flex justify-between"><dt className="text-foreground/60">Making charge</dt><dd>{rs(preview.making)}</dd></div>
              <div className="flex justify-between"><dt className="text-foreground/60">Stones</dt><dd>{rs(preview.stones)}</dd></div>
              <div className="flex justify-between border-t border-slate-200 pt-1 text-base font-bold"><dt>Today&apos;s price</dt><dd>{rs(preview.total)}</dd></div>
              {showCost && <CostLines price={preview.total} cost={cost} />}
            </dl>
          ) : (
            <p className="text-xs text-foreground/50">Enter the weight to see today&apos;s price.</p>
          )}
        </div>
      ) : (
        <div className="space-y-3 sm:max-w-xs">
          <label className="block">
            <span className="label">Selling price (Rs.)</span>
            <input name="price" type="number" min="0.01" step="0.01" className="input" required defaultValue={item?.price} />
          </label>
          {showCost && cost > 0 && (
            <dl className="space-y-1 rounded-xl bg-canvas p-3 text-sm">
              <CostLines price={fixedPrice} cost={cost} />
            </dl>
          )}
        </div>
      )}
    </fieldset>
  );
}

/** Cost price and the margin over it, when a cost price has been entered. */
function CostLines({ price, cost }: { price: number; cost: number }) {
  if (cost <= 0) return null;
  const margin = Math.round((price - cost) * 100) / 100;
  return (
    <>
      <div className="flex justify-between pt-1"><dt className="text-foreground/60">Cost price</dt><dd>{rs(cost)}</dd></div>
      <div className={`flex justify-between font-semibold ${margin < 0 ? "text-red-700" : "text-emerald-700"}`}>
        <dt>Margin</dt>
        <dd>{rs(margin)}{price > 0 && ` (${((margin / price) * 100).toFixed(1)}%)`}</dd>
      </div>
    </>
  );
}
