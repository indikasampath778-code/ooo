"use client";

import { useEffect, useRef, useState } from "react";
import { splitWeight } from "@/lib/format";

/**
 * Weight entry as separate gram and milligram boxes (`name_g`, `name_mg`, read by
 * `weight()` in lib/form), with the combined total shown underneath as you type.
 */
export default function WeightInput({ name, label, defaultMg, required = true }: {
  name: string;
  label: string;
  defaultMg?: number | null;
  required?: boolean;
}) {
  const parts = splitWeight(defaultMg);
  const gRef = useRef<HTMLInputElement>(null);
  const mgRef = useRef<HTMLInputElement>(null);
  const [total, setTotal] = useState(() => describe(parts.g, parts.mg));

  function update() {
    setTotal(describe(gRef.current?.value ?? "", mgRef.current?.value ?? ""));
  }

  // Re-read after the form is reset following a successful save.
  useEffect(() => {
    const form = gRef.current?.form;
    if (!form) return;
    const onReset = () => setTimeout(update, 0);
    form.addEventListener("reset", onReset);
    return () => form.removeEventListener("reset", onReset);
  }, []);

  return (
    <fieldset>
      <legend className="label">{label}</legend>
      <div className="flex gap-2">
        <div className="relative flex-1">
          <input ref={gRef} onInput={update} name={`${name}_g`} type="number" min={0} step={1} inputMode="numeric" defaultValue={parts.g} required={required} className="input pr-8" placeholder="0" />
          <span className="pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-sm text-foreground/50">g</span>
        </div>
        <div className="relative flex-1">
          <input ref={mgRef} onInput={update} name={`${name}_mg`} type="number" min={0} max={999} step={1} inputMode="numeric" defaultValue={parts.mg} className="input pr-10" placeholder="0" />
          <span className="pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-sm text-foreground/50">mg</span>
        </div>
      </div>
      <p className={`mt-1 text-xs ${total.ok ? "text-foreground/55" : "text-red-700"}`}>{total.text}</p>
    </fieldset>
  );
}

function describe(g: string, mg: string) {
  if (!g && !mg) return { ok: true, text: "mg box: 500 = 0.5 g, 50 = 0.05 g" };
  const grams = Number(g || 0);
  const milligrams = Number(mg || 0);
  if (!Number.isInteger(grams) || !Number.isInteger(milligrams) || grams < 0 || milligrams < 0 || milligrams > 999) {
    return { ok: false, text: "Whole grams, and 0–999 in the mg box" };
  }
  return { ok: true, text: `= ${((grams * 1000 + milligrams) / 1000).toFixed(3)} g` };
}
