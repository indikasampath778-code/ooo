"use client";

import { useRouter } from "next/navigation";

/**
 * Leaves a form without saving: goes back to the previous screen (which also closes a
 * popup opened from a list), or to `fallback` when there is nothing to go back to.
 */
export default function CancelButton({ fallback }: { fallback: string }) {
  const router = useRouter();
  return (
    <button
      type="button"
      className="btn-outline"
      onClick={() => (window.history.length > 1 ? router.back() : router.push(fallback))}
    >
      Cancel
    </button>
  );
}
