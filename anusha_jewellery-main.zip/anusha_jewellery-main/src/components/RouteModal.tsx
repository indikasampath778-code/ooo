"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, type ReactNode } from "react";

/**
 * Shows a page in a popup over the screen it was opened from (an intercepted route).
 * Closing it (×, Esc or the backdrop) goes back, so the URL returns to that screen.
 */
export default function RouteModal({ children }: { children: ReactNode }) {
  const router = useRouter();
  const dialogRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    if (!dialogRef.current?.open) dialogRef.current?.showModal();
  }, []);

  return (
    <dialog
      ref={dialogRef}
      onCancel={(e) => {
        e.preventDefault();
        router.back();
      }}
      onClick={(e) => {
        if (e.target === dialogRef.current) router.back();
      }}
      className="m-auto max-h-[94vh] w-[min(96vw,80rem)] overflow-y-auto rounded-2xl bg-canvas p-4 text-slate-900 shadow-2xl backdrop:bg-slate-950/70 sm:p-6"
    >
      <div className="mb-2 flex justify-end">
        <button type="button" onClick={() => router.back()} aria-label="Close" className="text-2xl leading-none text-slate-400 hover:text-slate-700">
          &times;
        </button>
      </div>
      {children}
    </dialog>
  );
}
