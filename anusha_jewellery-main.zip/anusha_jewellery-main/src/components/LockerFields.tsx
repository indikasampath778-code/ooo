import { Field } from "@/components/ui";
import { listLockers } from "@/lib/lockers";

/**
 * Locker picker plus the position inside it ("Tray 2, slot 5"). Orders and pawns must
 * go in a locker; shop stock may be left unassigned (on open display).
 */
export default async function LockerFields({ locker, slot, required = false }: {
  locker?: string | null;
  slot?: string;
  required?: boolean;
}) {
  const lockers = await listLockers();
  return (
    <>
      <label className="block">
        <span className="label">Locker</span>
        <select name="locker" className="input" defaultValue={locker ?? ""} required={required}>
          <option value="">{required ? "Choose a locker…" : "Not assigned"}</option>
          {lockers.map((l) => (
            <option key={l._id} value={l._id}>
              {l._id}{l.description ? ` - ${l.description}` : ""}
            </option>
          ))}
        </select>
        {lockers.length === 0 && (
          <span className="mt-1 block text-xs text-foreground/50">No lockers yet. Add one on the Lockers page first.</span>
        )}
      </label>
      <Field label="Position inside locker">
        <input name="lockerSlot" className="input" defaultValue={slot ?? ""} maxLength={60} placeholder="e.g. Tray 2, slot 5" />
      </Field>
    </>
  );
}
