import type { ReactNode } from "react";
import PrintButton from "@/components/PrintButton";
import { SHOP } from "@/lib/constants";

/** 80 mm receipt-printer layout shared by receipts and pawn tickets. */
export function PrintSlip({ title, children }: { title: string; children: ReactNode }) {
  return (
    <>
      <style>{`
        @page { size: 80mm auto; margin: 4mm; }
        @media print { html, body { background: #fff !important; } .slip { box-shadow: none !important; margin: 0 !important; } }
      `}</style>
      <div className="no-print flex justify-center p-4">
        <PrintButton label={`Print ${title.toLowerCase()}`} />
      </div>
      <div className="slip mx-auto mb-8 bg-white p-4 text-[12px] leading-snug text-black shadow-md" style={{ width: "72mm" }}>
        <div className="text-center">
          <p className="text-base font-bold tracking-wide">{SHOP.name.toUpperCase()}</p>
          <p className="font-sinhala">{SHOP.nameSi}</p>
          <p>{SHOP.address}</p>
          <p>Tel: {SHOP.phone}</p>
          <p className="mt-2 border-y border-dashed border-black py-1 font-bold uppercase">{title}</p>
        </div>
        <div className="mt-2 space-y-0.5">{children}</div>
        <p className="mt-3 border-t border-dashed border-black pt-2 text-center">Thank you! / ස්තූතියි!</p>
      </div>
    </>
  );
}

export function SlipRow({ label, value, bold }: { label: string; value: ReactNode; bold?: boolean }) {
  return (
    <div className={`flex justify-between gap-2 ${bold ? "text-[13px] font-bold" : ""}`}>
      <span>{label}</span>
      <span className="text-right">{value}</span>
    </div>
  );
}

export function SlipDivider() {
  return <hr className="my-1.5 border-dashed border-black" />;
}
