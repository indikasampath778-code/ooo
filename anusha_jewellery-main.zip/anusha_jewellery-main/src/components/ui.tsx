import type { ReactNode } from "react";
import { statusLabel, type OrderStatus } from "@/lib/constants";
import type { Urgency } from "@/lib/rules";

export function PageHeader({ title, subtitle, actions, titleAside }: {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  /** Shown on the same line as the title, e.g. small status or location chips. */
  titleAside?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col items-start justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:flex-row sm:items-center">
      <div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
          <h1 className="text-xl font-bold text-slate-900">{title}</h1>
          {titleAside}
        </div>
        {subtitle && <p className="mt-0.5 text-xs text-slate-500">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Stat({ label, value, hint, icon, tone = "default" }: {
  label: string;
  value: ReactNode;
  hint?: string;
  icon?: string;
  tone?: "default" | "red" | "orange" | "yellow" | "ink";
}) {
  const tones = {
    default: "bg-white border-slate-200",
    ink: "bg-gradient-to-br from-slate-900 to-slate-800 text-white border-slate-700",
    red: "bg-rose-50 border-rose-200",
    orange: "bg-orange-50 border-orange-200",
    yellow: "bg-amber-50 border-amber-200",
  };
  const dark = tone === "ink";
  return (
    <div className={`rounded-xl border p-5 shadow-sm ${tones[tone]}`}>
      <div className="flex items-center justify-between gap-2">
        <span className={`text-xs font-semibold uppercase ${dark ? "text-amber-300" : "text-slate-500"}`}>{label}</span>
        {icon && <span className={`rounded-lg p-2 text-lg leading-none ${dark ? "bg-white/10" : "bg-slate-50"}`}>{icon}</span>}
      </div>
      <p className={`mt-2 text-2xl font-black ${dark ? "text-white" : "text-slate-900"}`}>{value}</p>
      {hint && <p className={`mt-2 text-xs ${dark ? "text-slate-300" : "text-slate-500"}`}>{hint}</p>}
    </div>
  );
}

export function Detail({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <dt className="text-xs font-medium tracking-wide text-foreground/50 uppercase">{label}</dt>
      <dd className="mt-0.5 font-medium">{children}</dd>
    </div>
  );
}

const statusStyles: Record<OrderStatus, string> = {
  pending: "bg-stone-100 text-stone-700 ring-stone-300",
  in_progress: "bg-blue-50 text-blue-800 ring-blue-200",
  completed: "bg-emerald-50 text-emerald-800 ring-emerald-200",
  delivered: "bg-gold/15 text-ink ring-gold/50",
  cancelled: "bg-red-50 text-red-700 ring-red-200",
};

export function StatusBadge({ status }: { status: OrderStatus }) {
  return (
    <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold whitespace-nowrap ring-1 ${statusStyles[status]}`}>
      {statusLabel(status)}
    </span>
  );
}

export function Pill({ children, tone }: { children: ReactNode; tone: "green" | "gray" | "ink" }) {
  const tones = {
    green: "bg-emerald-50 text-emerald-800 ring-emerald-200",
    gray: "bg-stone-100 text-stone-600 ring-stone-300",
    ink: "bg-ink/10 text-ink ring-ink/30",
  };
  return <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold whitespace-nowrap ring-1 ${tones[tone]}`}>{children}</span>;
}

export const urgencyRow: Record<Exclude<Urgency, null>, string> = {
  yellow: "bg-yellow-100 hover:bg-yellow-200/70",
  orange: "bg-orange-200 hover:bg-orange-300/70",
  red: "bg-red-200 hover:bg-red-300/70",
};

const urgencyBadge: Record<Exclude<Urgency, null>, string> = {
  yellow: "bg-yellow-300 text-yellow-950",
  orange: "bg-orange-500 text-white",
  red: "bg-red-600 text-white",
};

export function UrgencyBadge({ urgency, label }: { urgency: Urgency; label: string }) {
  if (!urgency) return null;
  return <span className={`inline-flex rounded-full px-2 py-0.5 text-xs font-bold whitespace-nowrap ${urgencyBadge[urgency]}`}>{label}</span>;
}

export function UrgencyLegend() {
  return (
    <div className="flex flex-wrap items-center gap-3 text-xs text-foreground/70">
      <span className="font-medium">Delivery highlight:</span>
      <span className="flex items-center gap-1"><span className="size-3 rounded bg-yellow-300" /> within 1 week</span>
      <span className="flex items-center gap-1"><span className="size-3 rounded bg-orange-500" /> within 3 days</span>
      <span className="flex items-center gap-1"><span className="size-3 rounded bg-red-600" /> today / overdue</span>
      <span className="text-foreground/50">(only while the item is not completed)</span>
    </div>
  );
}

export function Field({ label, children, className = "" }: { label: string; children: ReactNode; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="label">{label}</span>
      {children}
    </label>
  );
}

export function CategorySelect({ categories, defaultValue }: { categories: { code: string; name: string }[]; defaultValue?: string }) {
  return (
    <Field label="Item category">
      <select name="category" className="input" defaultValue={defaultValue}>
        {categories.map((c) => (
          <option key={c.code} value={c.code}>
            {c.name} ({c.code})
          </option>
        ))}
      </select>
    </Field>
  );
}

/**
 * Collapsible card section; `summary` stays visible in the header while closed.
 * Accordions sharing a `group` name close each other: only one is open at a time.
 */
export function Accordion({ title, summary, defaultOpen = false, group, children }: {
  title: string;
  summary?: ReactNode;
  defaultOpen?: boolean;
  group?: string;
  children: ReactNode;
}) {
  return (
    <details open={defaultOpen} name={group} className="group rounded-2xl border border-slate-200 bg-white shadow-sm">
      <summary className="flex cursor-pointer list-none items-center justify-between gap-3 rounded-2xl px-5 py-4 select-none hover:bg-canvas/50 [&::-webkit-details-marker]:hidden">
        <span className="font-bold text-lg text-ink">{title}</span>
        <span className="flex items-center gap-3">
          {summary}
          <svg viewBox="0 0 20 20" fill="currentColor" aria-hidden className="size-5 text-ink transition-transform group-open:rotate-180">
            <path fillRule="evenodd" d="M5.22 8.22a.75.75 0 0 1 1.06 0L10 11.94l3.72-3.72a.75.75 0 1 1 1.06 1.06l-4.25 4.25a.75.75 0 0 1-1.06 0L5.22 9.28a.75.75 0 0 1 0-1.06Z" clipRule="evenodd" />
          </svg>
        </span>
      </summary>
      <div className="border-t border-slate-200 px-5 pt-4 pb-5">{children}</div>
    </details>
  );
}

export function EmptyState({ children }: { children: ReactNode }) {
  return <p className="rounded-xl border border-dashed border-slate-200 bg-white/60 p-8 text-center text-sm text-foreground/60">{children}</p>;
}
