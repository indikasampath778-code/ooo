import { createPawn } from "@/app/actions/pawns";
import ActionForm from "@/components/ActionForm";
import LockerFields from "@/components/LockerFields";
import { CategorySelect, Field } from "@/components/ui";
import WeightInput from "@/components/WeightInput";
import { PAWN_STANDARDS } from "@/lib/constants";
import { getCategories } from "@/lib/categories";

/** Customer, item and loan details for a new pawn. */
export default async function NewPawnForm() {
  const categories = await getCategories();
  return (
    <ActionForm action={createPawn} submitLabel="Save pawn & generate barcode" className="space-y-6">
      <fieldset className="grid gap-4 sm:grid-cols-2">
        <legend className="mb-3 font-bold text-ink">Customer</legend>
        <Field label="Customer name">
          <input name="name" className="input" required />
        </Field>
        <Field label="NIC number">
          <input name="nic" className="input uppercase" required placeholder="123456789V or 200012345678" />
        </Field>
        <Field label="Phone number">
          <input name="phone" type="tel" className="input" required placeholder="07X XXX XXXX" />
        </Field>
        <Field label="Address">
          <input name="address" className="input" required />
        </Field>
      </fieldset>
  
      <fieldset className="grid gap-4 sm:grid-cols-2">
        <legend className="mb-3 font-bold text-ink">Item</legend>
        <CategorySelect categories={categories} />
        <Field label="Standard">
          <select name="standard" className="input" defaultValue="22K">
            {PAWN_STANDARDS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </Field>
        <WeightInput name="gross" label="Gross weight (optional)" required={false} />
        <WeightInput name="net" label="Net weight" />
        <LockerFields required />
      </fieldset>
  
      <fieldset className="grid gap-4 sm:grid-cols-3">
        <legend className="mb-3 font-bold text-ink">Loan</legend>
        <Field label="Assessed value (Rs.)">
          <input name="assessedValue" type="number" min="0.01" step="0.01" className="input" required />
        </Field>
        <Field label="Principal amount (Rs.)">
          <input name="principal" type="number" min="0.01" step="0.01" className="input" required />
        </Field>
        <Field label="Monthly interest rate (%)">
          <input name="monthlyRate" type="number" min="0" max="20" step="0.01" className="input" required placeholder="e.g. 2.5" />
        </Field>
        <Field label="Duration — months">
          <input name="durationMonths" type="number" min="0" max="120" step="1" className="input" defaultValue={12} />
        </Field>
        <Field label="Duration — days">
          <input name="durationDays" type="number" min="0" max="365" step="1" className="input" defaultValue={0} />
        </Field>
        <p className="self-end pb-2 text-xs text-foreground/50">The due date is the pawn date plus this duration.</p>
      </fieldset>
  
      <Field label="Notes (optional)">
        <textarea name="notes" rows={2} className="input" placeholder="Item description, stones, damage, etc." />
      </Field>
    </ActionForm>
  );
}
