import Link from "next/link";
import { notFound } from "next/navigation";
import { updateStockItem } from "@/app/actions/stock";
import DeleteStockButton from "@/components/DeleteStockButton";
import LabelPrintButton from "@/components/LabelPrintButton";
import AddToCartButton from "@/components/AddToCartButton";
import StockItemEditor from "@/components/StockItemEditor";
import { StockFields } from "@/components/stock";
import { Detail, PageHeader, Pill } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { getCategoryNames } from "@/lib/categories";
import { payMethodLabel } from "@/lib/constants";
import { formatDate, formatDateTime, formatMoney, formatWeight, round2 } from "@/lib/format";
import { lockerLabel } from "@/lib/lockerLabel";
import { getSaleByReceipt, getStockItem } from "@/lib/stock";
import { readCartIds } from "@/lib/cart";
import { getReservation } from "@/lib/reservations";

/** Everything about one stock item: details (editable while in stock), barcode, sale or reservation. */
export default async function StockItemView({ id, created = false }: { id: string; created?: boolean }) {
  const [item, categoryName, user, cartIds] = await Promise.all([getStockItem(id), getCategoryNames(), getCurrentUser(), readCartIds()]);
  if (!item) notFound();
  // The checkout this piece was sold in (old gold is recorded per bill, not per item).
  const sale = item.sale ? await getSaleByReceipt(item.sale.receiptNo) : null;
  const reservation = item.reservationId ? await getReservation(item.reservationId.toString()) : null;
  const inStock = item.status === "in_stock";
  const isAdmin = user?.role === "admin";
  const price = item.sale?.price ?? item.price;

  // Read-only view of the item: the preview while in stock, and all there is once sold or reserved.
  const details = (
    <dl className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <Detail label="Item">{item.name}</Detail>
      <Detail label="Category">{categoryName(item.category)} ({item.category})</Detail>
      <Detail label="Carats">{item.karat}K</Detail>
      <Detail label="Weight">{formatWeight(item.weightMg)}</Detail>
      <Detail label={item.sale ? "Sold for" : item.pricing ? "Today's price (daily gold rate)" : "Fixed price"}>
        <span className="text-base font-bold">{formatMoney(price)}</span>
      </Detail>
      {isAdmin && item.costPrice != null && (
        <Detail label="Cost / margin">
          {formatMoney(item.costPrice)} ·{" "}
          <span className={price - item.costPrice < 0 ? "text-red-700" : "text-emerald-700"}>{formatMoney(round2(price - item.costPrice))}</span>
        </Detail>
      )}
      <Detail label="Made by">{item.makerName || "—"}</Detail>
      {item.notes && <Detail label="Notes">{item.notes}</Detail>}
    </dl>
  );

  return (
    <>
      <PageHeader
        title={`${item.code} · ${item.name}`}
        subtitle={`Added ${formatDateTime(item.createdAt)}`}
        titleAside={
          <div className="flex flex-wrap gap-2 text-xs">
            <span className="rounded-lg bg-amber-50 px-2.5 py-1 ring-1 ring-gold/40">
              <span className="text-foreground/60">Locker </span>
              <strong>{lockerLabel(item.lockerCode, item.lockerSlot) ?? (item.sale ? "— (released on sale)" : "Not assigned")}</strong>
            </span>
            <span className="rounded-lg bg-canvas px-2.5 py-1 ring-1 ring-slate-200">
              <span className="text-foreground/60">Location </span>
              <strong>{item.location || "—"}</strong>
            </span>
          </div>
        }
        actions={
          <>
            <LabelPrintButton kind="stock" id={id} />
            {inStock && <AddToCartButton id={id} inCart={cartIds.includes(id)} size="md" />}
            {item.sale && (
              <a href={`/print/receipt/${item.sale.receiptNo}`} className="btn-outline">
                Print receipt {item.sale.receiptNo}
              </a>
            )}
          </>
        }
      />

      {created && (
        <p className="mb-5 rounded-xl border border-emerald-300 bg-emerald-50 p-4 text-sm font-medium text-emerald-800">
          Item saved with barcode <strong>{item.code}</strong>. Print the barcode label and attach it to the item.
        </p>
      )}

      <div className={inStock ? "" : "grid gap-6 lg:grid-cols-3"}>
        <div className={inStock ? "space-y-6" : "space-y-6 lg:col-span-2"}>
          <section className="card">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <h2 className="card-title">Item details</h2>
              {inStock ? <Pill tone="green">In stock</Pill> : item.status === "reserved" ? <Pill tone="ink">Reserved</Pill> : <Pill tone="gray">Sold</Pill>}
            </div>
            {inStock ? (
              <StockItemEditor
                action={updateStockItem.bind(null, id)}
                preview={details}
                fields={<StockFields item={item} wide showCost={isAdmin} />}
                deleteButton={isAdmin && <DeleteStockButton id={id} label={`${item.code} (${item.name})`} />}
              />
            ) : (
              details
            )}
          </section>
        </div>

        {/* Side column only for reserved or sold items; an item in stock uses the full width. */}
        {!inStock && (
        <div className="space-y-4">
          {item.status === "reserved" && reservation ? (
            <section className="card space-y-3">
              <h2 className="card-title mb-0">Reserved</h2>
              <p className="text-sm text-foreground/70">
                Held for <strong>{reservation.customer.name}</strong> ({reservation.customer.phone}) on reservation{" "}
                {reservation.code}
                {reservation.reserveUntil && <> until {formatDate(reservation.reserveUntil)}</>}. It can&apos;t be sold to anyone else.
              </p>
              <Link href={`/billing?type=reservations&id=${reservation._id}`} className="btn-primary w-full">
                Open reservation in Billing
              </Link>
            </section>
          ) : item.sale ? (
            <section className="card">
              <h2 className="card-title">Sale</h2>
              <dl className="space-y-3 text-sm">
                <Detail label="Customer">
                  {item.sale.customer.name}
                  {item.sale.customer.phone && <span className="text-foreground/60"> · {item.sale.customer.phone}</span>}
                </Detail>
                <Detail label="Item price">{formatMoney(item.sale.price)}</Detail>
                {sale && sale.oldGoldTotal > 0 && (
                  <div className="rounded-lg bg-emerald-50 p-3 ring-1 ring-emerald-200">
                    <p className="text-xs font-semibold tracking-wide text-emerald-800 uppercase">Old gold exchange on this bill</p>
                    <ul className="mt-1 space-y-0.5 text-emerald-900">
                      {sale.oldGold.map((g, n) => (
                        <li key={n}>
                          {g.description} ({g.weightMg > 0 ? `${formatWeight(g.weightMg)} ` : ""}{g.karat}K): − {formatMoney(g.value)}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {sale && (
                  <Detail label={sale.items.length > 1 ? `Bill total (${sale.items.length} items)` : "Bill total"}>
                    {formatMoney(sale.subtotal)}
                    {sale.oldGoldTotal > 0 && <> − old gold {formatMoney(sale.oldGoldTotal)}</>}
                    {" = "}
                    <strong>{formatMoney(sale.total)} paid</strong>
                  </Detail>
                )}
                <Detail label="Paid by">{payMethodLabel(item.sale.method)}</Detail>
                <Detail label="Sold on">{formatDateTime(item.sale.soldAt)}</Detail>
                <Detail label="Sold by">{item.sale.soldBy}</Detail>
                <Detail label="Receipt">{item.sale.receiptNo}</Detail>
              </dl>
            </section>
          ) : null}
        </div>
        )}
      </div>
    </>
  );
}
