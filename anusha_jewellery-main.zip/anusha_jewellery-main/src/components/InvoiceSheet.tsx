import type { ReactNode } from "react";
import PrintButton from "@/components/PrintButton";
import { SHOP } from "@/lib/constants";

export type InvoiceColumn = { label: string; align?: "left" | "center" | "right" };
export type InvoiceLine = { label: string; value: ReactNode; tone?: "minus" };

export type InvoiceData = {
  /** What the receipt is for, e.g. "Sales receipt", shown under the copy label. */
  kind: string;
  receiptNo: string;
  date: string;
  /** Customer strip, e.g. Customer · Phone · NIC. */
  customer: { label: string; value: ReactNode }[];
  /** Extra references on the right of the customer strip, e.g. Bill No. */
  refs?: { label: string; value: ReactNode }[];
  columns: InvoiceColumn[];
  rows: ReactNode[][];
  /** Lines above the grand total (subtotal, old gold, paid to date…). */
  lines: InvoiceLine[];
  grand: { label: string; value: ReactNode };
  /** Lines under the grand total (method, balance…). */
  after?: InvoiceLine[];
  /** Short note at the bottom left, e.g. "Item remains in our safe keeping." */
  note?: string;
  /** Every payment on the bill up to and including this receipt (this one is highlighted). */
  history?: { receiptNo: string; date: string; label: string; amount: string; current?: boolean }[];
  historyTotal?: string;
};

const align = { left: "text-left", center: "text-center", right: "text-right" } as const;

/**
 * A4 bill printed as two copies on one sheet: the original for the customer and a
 * duplicate kept by the shop, separated by a cut line.
 */
export function InvoiceSheet({ data }: { data: InvoiceData }) {
  return (
    <>
      <style>{`
        @page { size: A4 portrait; margin: 10mm; }
        @media print {
          html, body { background: #fff !important; }
          .invoice-sheet { box-shadow: none !important; margin: 0 !important; padding: 0 !important; width: auto !important; }
        }
      `}</style>
      <div className="no-print flex justify-center p-4">
        <PrintButton label="Print bill (customer + shop copy)" />
      </div>
      <div className="invoice-sheet mx-auto mb-8 bg-white p-[10mm] text-black shadow-md" style={{ width: "210mm" }}>
        <InvoiceCopy data={data} title="ORIGINAL INVOICE (CUSTOMER COPY)" />
        <div className="relative my-[6mm] border-t border-dashed border-slate-500 text-center">
          <span className="relative -top-2.5 bg-white px-2 text-[10px] text-slate-500">
            ✂ - - - - - - CUT HERE FOR SHOP DUPLICATE COPY - - - - - - ✂
          </span>
        </div>
        <InvoiceCopy data={data} title="DUPLICATE INVOICE (SHOP COPY)" duplicate />
      </div>
    </>
  );
}

function InvoiceCopy({ data, title, duplicate = false }: { data: InvoiceData; title: string; duplicate?: boolean }) {
  return (
    <section className="break-inside-avoid border border-slate-800 p-[7mm] text-[13px] leading-snug">
      <header className="flex items-start justify-between gap-6 border-b-[3px] border-black pb-3">
        <div>
          <h1 className="text-[26px] leading-tight font-black tracking-tight">{SHOP.name.toUpperCase()}</h1>
          <p className="mt-1 text-[12px] text-slate-600">
            <span className="font-sinhala">{SHOP.nameSi}</span> &bull; {SHOP.address} &bull; Tel: {SHOP.phone}
          </p>
        </div>
        <div className="shrink-0 text-right">
          <p className="max-w-[60mm] text-[13px] font-bold text-slate-400">{title}</p>
          <p className="mt-1 font-mono text-[15px] font-bold">{data.receiptNo}</p>
          <p className="text-[11px] text-slate-500">{data.date}</p>
          <p className="text-[11px] font-semibold text-slate-600 uppercase">{data.kind}</p>
        </div>
      </header>

      <div className="flex flex-wrap justify-between gap-x-6 gap-y-1 px-1 py-3">
        <p>
          {data.customer.map((c, i) => (
            <span key={c.label}>
              {i > 0 && " • "}
              <b>{c.label}:</b> {c.value}
            </span>
          ))}
        </p>
        {data.refs && data.refs.length > 0 && (
          <p>
            {data.refs.map((r, i) => (
              <span key={r.label}>
                {i > 0 && " • "}
                <b>{r.label}:</b> {r.value}
              </span>
            ))}
          </p>
        )}
      </div>

      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b border-slate-800">
            {data.columns.map((c) => (
              <th key={c.label} className={`px-1.5 py-2 font-bold ${align[c.align ?? "left"]}`}>{c.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.rows.map((row, r) => (
            <tr key={r} className="border-b border-dashed border-slate-300">
              {row.map((cell, c) => (
                <td key={c} className={`px-1.5 py-2 ${align[data.columns[c]?.align ?? "left"]}`}>{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>

      {data.history && data.history.length > 0 && (
        <div className="mt-3">
          <p className="px-1.5 text-[12px] font-bold">Payments made</p>
          <table className="w-full border-collapse text-[12px]">
            <thead>
              <tr className="border-b border-slate-400 text-left">
                <th className="px-1.5 py-1 font-semibold">Date</th>
                <th className="px-1.5 py-1 font-semibold">Receipt</th>
                <th className="px-1.5 py-1 font-semibold">Details</th>
                <th className="px-1.5 py-1 text-right font-semibold">Amount</th>
              </tr>
            </thead>
            <tbody>
              {data.history.map((h) => (
                <tr key={h.receiptNo} className={`border-b border-dashed border-slate-300 ${h.current ? "font-bold" : ""}`}>
                  <td className="px-1.5 py-1">{h.date}</td>
                  <td className="px-1.5 py-1 font-mono">{h.receiptNo}{h.current && " (this receipt)"}</td>
                  <td className="px-1.5 py-1">{h.label}</td>
                  <td className="px-1.5 py-1 text-right">{h.amount}</td>
                </tr>
              ))}
            </tbody>
            {data.historyTotal && (
              <tfoot>
                <tr>
                  <td colSpan={3} className="px-1.5 py-1 text-right font-bold">Total paid</td>
                  <td className="px-1.5 py-1 text-right font-bold">{data.historyTotal}</td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      )}

      <div className="mt-2 flex justify-between gap-6">
        <p className="self-end text-[12px] text-slate-600">{data.note}</p>
        <div className="w-[45%] shrink-0 text-right">
          {data.lines.map((l) => (
            <p key={l.label}>{l.label}: <b>{l.tone === "minus" ? "- " : ""}{l.value}</b></p>
          ))}
          <p className="mt-1 border-t border-black pt-1 text-[19px] font-black">{data.grand.label}: {data.grand.value}</p>
          {data.after?.map((l) => (
            <p key={l.label} className="text-[12px]">{l.label}: <b>{l.value}</b></p>
          ))}
        </div>
      </div>

      <div className="mt-8 flex justify-between gap-6 text-[12px]">
        <span className="w-[35%] border-t border-dotted border-black pt-1 text-center">{duplicate ? "Customer Acknowledgment" : "Customer Signature"}</span>
        <span className="w-[35%] border-t border-dotted border-black pt-1 text-center">Authorized Cashier</span>
      </div>
    </section>
  );
}
