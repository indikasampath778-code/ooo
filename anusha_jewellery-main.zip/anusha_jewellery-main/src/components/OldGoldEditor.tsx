"use client";

import { KARATS } from "@/lib/constants";

/** One old gold line as typed at the counter. The value is what counts; weight is a note. */
export type OldGoldRow = { key: number; description: string; g: string; mg: string; karat: number; value: string };

export const round2 = (n: number) => Math.round(n * 100) / 100;
export const money = (n: number) => `Rs. ${n.toLocaleString("en-LK", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
export const oldGoldValue = (r: OldGoldRow) => round2(Number(r.value) || 0);
export const oldGoldTotal = (rows: OldGoldRow[]) => round2(rows.reduce((s, r) => s + oldGoldValue(r), 0));

/** JSON sent to the server as the `oldGold` form field. */
export function oldGoldPayload(rows: OldGoldRow[]) {
  return JSON.stringify(
    rows.map((r) => ({
      description: r.description,
      weightMg: (Number(r.g) || 0) * 1000 + (Number(r.mg) || 0),
      karat: r.karat,
      value: Number(r.value),
    })),
  );
}

let nextKey = 1;

/** "Old gold exchange" section used by the shop checkout and order payments. */
export default function OldGoldEditor({
  rows,
  onChange,
  hint,
  compact = false,
}: {
  rows: OldGoldRow[];
  onChange: (rows: OldGoldRow[]) => void;
  hint?: string;
  /** Two columns, for narrow side panels. */
  compact?: boolean;
}) {
  const wide = compact ? "" : "sm:col-span-4";
  const update = (key: number, patch: Partial<OldGoldRow>) =>
    onChange(rows.map((r) => (r.key === key ? { ...r, ...patch } : r)));

  return (
    <fieldset className="rounded-xl border border-slate-200 p-4">
      <legend className="px-1 text-sm font-semibold text-ink">Old gold exchange (optional)</legend>
      {rows.length === 0 && hint && <p className="mb-3 text-sm text-foreground/60">{hint}</p>}
      <div className="space-y-3">
        {rows.map((r) => (
          <div key={r.key} className={`grid grid-cols-2 items-end gap-2 rounded-lg bg-canvas/60 p-3 ${compact ? "" : "sm:grid-cols-4"}`}>
            <label className={`col-span-2 block ${wide}`}>
              <span className="label text-xs">Description</span>
              <input className="input py-1.5" value={r.description} placeholder="e.g. Old chain" onChange={(e) => update(r.key, { description: e.target.value })} />
            </label>
            <label className="block">
              <span className="label text-xs">Weight g (note)</span>
              <input className="input py-1.5" type="number" min={0} step={1} value={r.g} onChange={(e) => update(r.key, { g: e.target.value })} />
            </label>
            <label className="block">
              <span className="label text-xs">mg</span>
              <input className="input py-1.5" type="number" min={0} max={999} step={1} value={r.mg} onChange={(e) => update(r.key, { mg: e.target.value })} />
            </label>
            <label className="block">
              <span className="label text-xs">Carats</span>
              <select className="input py-1.5" value={r.karat} onChange={(e) => update(r.key, { karat: Number(e.target.value) })}>
                {KARATS.map((k) => <option key={k} value={k}>{k}K</option>)}
              </select>
            </label>
            <label className="block">
              <span className="label text-xs">Old gold value (Rs.)</span>
              <input className="input py-1.5" type="number" min="0.01" step="0.01" required value={r.value} onChange={(e) => update(r.key, { value: e.target.value })} />
            </label>
            <div className={`col-span-2 flex items-center justify-between gap-2 border-t border-slate-100 pt-2 ${wide}`}>
              <button type="button" aria-label="Remove old gold line" className="text-xs font-semibold text-red-700 underline" onClick={() => onChange(rows.filter((x) => x.key !== r.key))}>
                Remove
              </button>
              <span className="text-sm font-semibold whitespace-nowrap text-emerald-700">Value: - {money(oldGoldValue(r))}</span>
            </div>
          </div>
        ))}
      </div>
      <button
        type="button"
        className="btn-outline mt-3 px-3 py-1.5 text-xs"
        onClick={() => onChange([...rows, { key: nextKey++, description: "", g: "", mg: "", karat: 22, value: "" }])}
      >
        + Add old gold
      </button>
    </fieldset>
  );
}
