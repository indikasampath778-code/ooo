import AddToCartButton from "@/components/AddToCartButton";
import ClickableRow from "@/components/ClickableRow";
import LabelPrintButton from "@/components/LabelPrintButton";
import LockerFields from "@/components/LockerFields";
import MakerSelect from "@/components/MakerSelect";
import StockPriceFields from "@/components/StockPriceFields";
import { CategorySelect, Field, Pill } from "@/components/ui";
import WeightInput from "@/components/WeightInput";
import { KARATS } from "@/lib/constants";
import { getCategories, getCategoryNames } from "@/lib/categories";
import { lockerLabel } from "@/lib/lockerLabel";
import { getLatestGoldRates } from "@/lib/rates";
import { formatDateTime, formatMoney, formatWeight } from "@/lib/format";
import type { StockDoc } from "@/lib/types";

/** Inputs shared by the add-item and edit-item forms. */
export async function StockFields({ item, wide = false, showCost = false }: { item?: StockDoc; wide?: boolean; showCost?: boolean }) {
  const [categories, rates] = await Promise.all([getCategories(), getLatestGoldRates()]);
  return (
    <div className={`grid sm:grid-cols-2 ${wide ? "gap-3 lg:grid-cols-4" : "gap-4"}`}>
      <Field label="Item name" className="sm:col-span-2">
        <input name="name" className="input" required defaultValue={item?.name} placeholder="e.g. Ladies ring with red stone" />
      </Field>
      <CategorySelect categories={categories} defaultValue={item?.category} />
      <LockerFields locker={item?.lockerCode} slot={item?.lockerSlot} />
      <Field label="Number of carats">
        <select name="karat" className="input" defaultValue={item?.karat ?? 22}>
          {KARATS.map((k) => (
            <option key={k} value={k}>
              {k}K
            </option>
          ))}
        </select>
      </Field>
      <WeightInput name="weight" label="Weight" defaultMg={item?.weightMg} />
      <Field label="Cost price (Rs., optional)">
        <input name="costPrice" type="number" min="0" step="0.01" className="input" defaultValue={item?.costPrice ?? undefined} />
      </Field>
      {/* New items are priced at weight × today's gold rate; pricing details are only edited later. */}
      {/* Only plain values can go to a client component (not the item's ObjectId or dates). */}
      {item && (
        <StockPriceFields
          item={{ pricing: item.pricing ?? null, weightMg: item.weightMg, karat: item.karat, price: item.price }}
          rates={rates && { rate24: rates.rate24, rate22: rates.rate22, rate18: rates.rate18 }}
          showCost={showCost}
          wide={wide}
        />
      )}
      <MakerSelect label="Made by (optional)" defaultValue={item?.makerName} />
      <Field label="Display location (optional)">
        <input name="location" className="input" defaultValue={item?.location} placeholder="e.g. Showcase 2" />
      </Field>
      <Field label="Notes (optional)" className="sm:col-span-2">
        <textarea name="notes" rows={1} className="input" defaultValue={item?.notes} />
      </Field>
    </div>
  );
}

export async function StockTable({ items, bare = false, cartIds, editable = false }: {
  items: StockDoc[];
  bare?: boolean;
  /** When given, in-stock rows get an "Add to cart" button. */
  cartIds?: string[];
  /** Adds a "Barcode" (print label) button to each row. */
  editable?: boolean;
}) {
  const categoryName = await getCategoryNames();
  return (
    <div className={`overflow-x-auto ${bare ? "" : "rounded-2xl border border-slate-200 bg-white shadow-sm"}`}>
      <table className="table">
        <thead>
          <tr>
            <th>Item no.</th>
            <th>Name</th>
            <th>Category</th>
            <th>Gold</th>
            <th>Location</th>
            <th className="text-right">Price</th>
            <th>Status</th>
            {(cartIds || editable) && <th />}
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <ClickableRow
              key={item._id.toString()}
              href={`/stock/${item._id}`}
              className="hover:bg-canvas/70"
            >
              <td className="font-mono text-sm whitespace-nowrap">{item.code}</td>
              <td className="font-semibold">{item.name}</td>
              <td className="whitespace-nowrap">{categoryName(item.category)}</td>
              <td className="whitespace-nowrap">
                <p>{item.karat}K</p>
                <p className="text-sm text-foreground/60">{formatWeight(item.weightMg)}</p>
              </td>
              <td className="text-sm">
                <p>{lockerLabel(item.lockerCode, item.lockerSlot) ?? (item.location ? "" : "—")}</p>
                {item.location && <p className="text-foreground/60">{item.location}</p>}
              </td>
              <td className="text-right whitespace-nowrap">
                {formatMoney(item.sale?.price ?? item.price)}
                {item.sale && item.sale.price !== item.price && (
                  <p className="text-xs text-foreground/50 line-through">{formatMoney(item.price)}</p>
                )}
              </td>
              <td className="whitespace-nowrap">
                {item.sale ? (
                  <>
                    <Pill tone="gray">Sold</Pill>
                    <p className="mt-1 text-xs text-foreground/60">{formatDateTime(item.sale.soldAt)}</p>
                  </>
                ) : item.status === "reserved" ? (
                  <a href={`/billing?type=reservations&id=${item.reservationId}`} className="inline-block">
                    <Pill tone="ink">Reserved</Pill>
                  </a>
                ) : (
                  <Pill tone="green">In stock</Pill>
                )}
              </td>
              {(cartIds || editable) && (
                <td>
                  <div className="flex items-center justify-end gap-2">
                    {cartIds && item.status === "in_stock" && (
                      <AddToCartButton id={item._id.toString()} inCart={cartIds.includes(item._id.toString())} />
                    )}
                    {editable && (
                      <LabelPrintButton kind="stock" id={item._id.toString()} label="Barcode" className="btn-outline px-3 py-1 text-xs" />
                    )}
                  </div>
                </td>
              )}
            </ClickableRow>
          ))}
        </tbody>
      </table>
    </div>
  );
}
