"use client";

import { startTransition, useActionState, useState } from "react";
import OldGoldEditor, { money, oldGoldPayload, oldGoldTotal, round2, type OldGoldRow } from "@/components/OldGoldEditor";
import { PAY_METHODS } from "@/lib/constants";
import type { FormState } from "@/lib/types";

/**
 * Advance, installment or final payment for an order. The customer can pay in cash
 * (or card/bank), hand in old gold, or both; the two together are credited to the bill.
 */
export default function OrderPaymentFields({
  action,
  balance,
  canHandOver,
  submitLabel,
  suggested,
}: {
  /** Quick-fill for the next installment of the order's plan. */
  suggested?: { label: string; amount: number; note: string };
  /** Server action that records the payment (order bill or reservation installment). */
  action: (state: FormState, formData: FormData) => Promise<FormState>;
  balance: number | null;
  canHandOver: boolean;
  submitLabel: string;
}) {
  const [state, formAction, saving] = useActionState(action, {});
  const [note, setNote] = useState("");
  // Starts empty: the customer pays only what is typed (use "Pay remaining" to fill the rest).
  const [amount, setAmount] = useState("");
  const [oldGold, setOldGold] = useState<OldGoldRow[]>([]);

  // Reset for the next payment once one is saved (the balance has changed too).
  const [seen, setSeen] = useState({ state, balance });
  if (state !== seen.state || balance !== seen.balance) {
    setSeen({ state, balance });
    if (state.success && state !== seen.state) {
      setOldGold([]);
      setAmount("");
      setNote("");
    }
  }

  const goldValue = oldGoldTotal(oldGold);
  const credited = round2((Number(amount) || 0) + goldValue);
  const remaining = balance == null ? null : round2(balance - credited);
  // What is still owed after the old gold, i.e. the most cash that can be taken now.
  const cashToClear = balance == null ? null : Math.max(0, round2(balance - goldValue));

  return (
    <form
      className="space-y-4"
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        fd.set("oldGold", oldGoldPayload(oldGold));
        startTransition(() => formAction(fd));
      }}
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block">
          <span className="label">Cash / card paying now (Rs.)</span>
          <input
            name="amount"
            type="number"
            min="0"
            step="0.01"
            className="input"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required={oldGold.length === 0}
            placeholder="0.00"
          />
          {suggested && suggested.amount > 0 && Number(amount) !== suggested.amount && (
            <button
              type="button"
              className="mt-1 mr-3 text-xs font-semibold text-ink underline"
              onClick={() => {
                setAmount(String(suggested.amount));
                setNote(suggested.note);
              }}
            >
              {suggested.label} · {money(suggested.amount)}
            </button>
          )}
          {cashToClear != null && cashToClear > 0 && Number(amount) !== cashToClear && (
            <button type="button" className="mt-1 text-xs font-semibold text-ink underline" onClick={() => setAmount(String(cashToClear))}>
              Pay remaining {money(cashToClear)}
            </button>
          )}
        </label>
        <label className="block">
          <span className="label">Method</span>
          <select name="method" className="input" defaultValue="cash">
            {PAY_METHODS.map((m) => <option key={m.value} value={m.value}>{m.label}</option>)}
          </select>
        </label>
      </div>

      <OldGoldEditor
        rows={oldGold}
        onChange={setOldGold}
        compact
      />

      <dl className="space-y-1 rounded-xl bg-canvas p-3 text-sm">
        {balance != null && (
          <div className="flex justify-between"><dt className="text-foreground/60">Balance due</dt><dd className="font-semibold">{money(balance)}</dd></div>
        )}
        {oldGold.length > 0 && (
          <div className="flex justify-between"><dt className="text-foreground/60">Less old gold</dt><dd className="font-semibold text-emerald-700">- {money(goldValue)}</dd></div>
        )}
        <div className="flex justify-between"><dt className="text-foreground/60">Less cash / card now</dt><dd className="font-semibold text-emerald-700">- {money(Number(amount) || 0)}</dd></div>
        {remaining != null ? (
          <div className="flex justify-between border-t border-slate-200 pt-1 text-base">
            <dt className="font-semibold">Balance after this</dt>
            <dd className={`font-bold ${remaining < 0 ? "text-red-700" : "text-ink"}`}>{money(remaining)}</dd>
          </div>
        ) : (
          <div className="flex justify-between border-t border-slate-200 pt-1 text-base">
            <dt className="font-semibold">Paying now</dt>
            <dd className="font-bold text-ink">{money(credited)}</dd>
          </div>
        )}
        {remaining != null && remaining < 0 && (
          <p className="pt-1 text-xs font-medium text-red-700">This is more than the balance due. Lower the cash amount or the old gold value.</p>
        )}
      </dl>

      <label className="block">
        <span className="label">Note (optional)</span>
        <input name="note" className="input" placeholder="e.g. 2nd payment" value={note} onChange={(e) => setNote(e.target.value)} />
      </label>
      {/* A payment that clears the balance of a completed order hands the item over and takes it out of its locker. */}
      {canHandOver && <input type="hidden" name="handover" value="on" />}

      {state.error && (
        <p role="alert" className="rounded-lg border border-red-300 bg-red-50 px-3 py-2 text-sm font-medium text-red-800">{state.error}</p>
      )}
      {state.success && (
        <div role="status" className="flex flex-wrap items-center gap-3 rounded-lg border border-emerald-300 bg-emerald-50 px-3 py-2 text-sm font-medium text-emerald-800">
          <span>{state.success}</span>
          {state.receiptNo && (
            <a href={`/print/receipt/${state.receiptNo}`} className="btn-primary px-3 py-1">
              Print receipt {state.receiptNo}
            </a>
          )}
        </div>
      )}

      <button type="submit" disabled={saving || (remaining != null && remaining < 0)} className="btn-primary w-full">
        {saving ? "Saving…" : `${submitLabel}${credited > 0 ? ` · ${money(credited)}` : ""}`}
      </button>
    </form>
  );
}
