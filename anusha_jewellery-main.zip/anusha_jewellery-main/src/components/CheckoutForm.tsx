"use client";

import { useRouter } from "next/navigation";
import { startTransition, useActionState, useState, useTransition } from "react";
import { checkout, clearCart, removeFromCart } from "@/app/actions/cart";
import { reserveCart } from "@/app/actions/reservations";
import OldGoldEditor, { money, oldGoldPayload, oldGoldTotal as sumOldGold, round2, type OldGoldRow } from "@/components/OldGoldEditor";
import { PAY_METHODS } from "@/lib/constants";
import { priceAtRate, type StockPricing } from "@/lib/pricing";

export type CartLine = {
  id: string;
  code: string;
  name: string;
  karat: number;
  weightMg: number;
  price: number; // today's price
  rate: number | null; // today's gold rate per gram for this karat (null when no rates are set)
  pricing: StockPricing | null; // set for items priced by the gold rate
};

/**
 * Price for a rate typed at the counter: weight × rate, plus wastage, making charge and
 * stones for items priced by the gold rate.
 */
function priceForRate(line: CartLine, rate: number) {
  if (line.pricing) return priceAtRate(line.weightMg, rate, line.pricing).total;
  return Math.round((line.weightMg / 1000) * rate);
}

/** "8.000 g × Rs. 3,000 + making, wastage" — how a typed rate became the price. */
function rateWorking(line: CartLine, rate: number) {
  const extras = line.pricing
    ? [line.pricing.wastagePercent && `${line.pricing.wastagePercent}% wastage`, line.pricing.makingCharge && "making", line.pricing.stoneValue && "stones"].filter(Boolean)
    : [];
  return `${(line.weightMg / 1000).toFixed(3)} g × ${money(rate)}${extras.length ? ` + ${extras.join(", ")}` : ""}`;
}

/**
 * Cart table, old gold exchange and payment, all on one form with live totals.
 * "Sell now" completes the sale; "Reserve" holds the items for a customer who pays in installments.
 */
export default function CheckoutForm({ items }: { items: CartLine[] }) {
  const router = useRouter();
  const [mode, setMode] = useState<"sell" | "reserve">("sell");
  const [saleState, saleAction, selling] = useActionState(checkout, {});
  const [reserveState, reserveAction, reserving] = useActionState(reserveCart, {});
  const [lastMode, setLastMode] = useState<"sell" | "reserve">("sell");
  const state = lastMode === "sell" ? saleState : reserveState;
  const saving = selling || reserving;
  const [firstPayment, setFirstPayment] = useState("");
  const [busy, startBusy] = useTransition();
  const [prices, setPrices] = useState<Record<string, string>>({});
  const [rates, setRates] = useState<Record<string, string>>({});
  const [oldGold, setOldGold] = useState<OldGoldRow[]>([]);

  // After a successful sale the cart is empty; reset the extras for the next customer.
  const [seenState, setSeenState] = useState(state);
  if (state !== seenState) {
    setSeenState(state);
    if (state.success) {
      setOldGold([]);
      setPrices({});
      setRates({});
      setFirstPayment("");
      setMode("sell");
    }
  }

  const priceOf = (line: CartLine) => prices[line.id] ?? String(line.price);
  const rateOf = (line: CartLine) => rates[line.id] ?? (line.rate == null ? "" : String(line.rate));
  function changeRate(line: CartLine, value: string) {
    setRates((r) => ({ ...r, [line.id]: value }));
    const rate = Number(value);
    if (value && Number.isFinite(rate) && rate > 0) setPrices((p) => ({ ...p, [line.id]: String(priceForRate(line, rate)) }));
  }
  /** Back to today's rate and the item's own price. */
  function resetLine(line: CartLine) {
    const drop = (m: Record<string, string>) => Object.fromEntries(Object.entries(m).filter(([k]) => k !== line.id));
    setRates(drop);
    setPrices(drop);
  }
  const rateEdited = (line: CartLine) => line.id in rates && rates[line.id] !== String(line.rate ?? "");
  const subtotal = round2(items.reduce((s, l) => s + (Number(priceOf(l)) || 0), 0));
  const oldGoldTotal = sumOldGold(oldGold);
  const total = round2(subtotal - oldGoldTotal);
  const firstTotal = round2((Number(firstPayment) || 0) + oldGoldTotal);
  const balanceLater = round2(subtotal - firstTotal);
  const invalid = mode === "sell" ? total < 0 : balanceLater < 0;

  if (!items.length) {
    return (
      <section className="card space-y-4">
        <h2 className="card-title mb-0">Cart</h2>
        {state.success ? (
          <div className="space-y-3 rounded-xl border border-emerald-300 bg-emerald-50 p-4 text-emerald-900">
            <p className="font-semibold">{state.success}</p>
            <div className="flex flex-wrap gap-2">
              {state.receiptNo && (
                <a href={`/print/receipt/${state.receiptNo}`} className="btn-primary">
                  Print receipt {state.receiptNo}
                </a>
              )}
              {state.reservationId && (
                <a href={`/billing?type=reservations&id=${state.reservationId}`} className="btn-outline">
                  Open reservation
                </a>
              )}
            </div>
          </div>
        ) : (
          <p className="text-sm text-foreground/60">The cart is empty. Scan items or use “Add to cart” in Shop Stock.</p>
        )}
      </section>
    );
  }

  return (
    <form
      className="card space-y-5"
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        fd.set("oldGold", oldGoldPayload(oldGold));
        setLastMode(mode);
        startTransition(() => (mode === "sell" ? saleAction(fd) : reserveAction(fd)));
      }}
    >
      <div className="flex items-center justify-between">
        <h2 className="card-title mb-0">Cart ({items.length} item{items.length === 1 ? "" : "s"})</h2>
        <button
          type="button"
          disabled={busy}
          className="text-sm font-semibold text-red-700 underline"
          onClick={() => window.confirm("Remove all items from the cart?") && startBusy(async () => { await clearCart(); router.refresh(); })}
        >
          Clear cart
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="table">
          <thead>
            <tr><th>Item</th><th>Weight</th><th className="text-right">Rate (Rs./g)</th><th className="text-right">Price (Rs.)</th><th /></tr>
          </thead>
          <tbody>
            {items.map((line) => (
              <tr key={line.id}>
                <td>
                  <p className="font-medium">{line.name}</p>
                  <p className="font-mono text-xs text-foreground/60">{line.code} · {line.karat}K</p>
                </td>
                <td className="whitespace-nowrap">{(line.weightMg / 1000).toFixed(3)} g</td>
                <td className="text-right">
                  <input
                    name={`rate_${line.id}`}
                    type="number"
                    min="0.01"
                    step="0.01"
                    value={rateOf(line)}
                    onChange={(e) => changeRate(line, e.target.value)}
                    placeholder="No rate"
                    className="input w-28 py-1 text-right"
                    aria-label={`Gold rate per gram for ${line.code}`}
                  />
                  {line.rate != null && rateEdited(line) && (
                    <button type="button" className="mt-1 block w-full text-right text-[11px] text-foreground/50 underline" onClick={() => resetLine(line)}>
                      Today {money(line.rate)}
                    </button>
                  )}
                </td>
                <td className="text-right">
                  <input
                    name={`price_${line.id}`}
                    type="number"
                    min="0.01"
                    step="0.01"
                    required
                    value={priceOf(line)}
                    onChange={(e) => setPrices((p) => ({ ...p, [line.id]: e.target.value }))}
                    className="input w-36 py-1 text-right"
                    aria-label={`Price for ${line.code}`}
                  />
                  {rateEdited(line) && Number(rateOf(line)) > 0 ? (
                    <p className="mt-1 text-[11px] text-foreground/50">{rateWorking(line, Number(rateOf(line)))}</p>
                  ) : (
                    Number(priceOf(line)) < line.price && <p className="mt-1 text-[11px] text-foreground/50">List {money(line.price)}</p>
                  )}
                </td>
                <td className="text-right">
                  <button
                    type="button"
                    disabled={busy}
                    aria-label={`Remove ${line.code}`}
                    className="rounded-full px-2 text-lg text-foreground/40 hover:bg-red-50 hover:text-red-700"
                    onClick={() => startBusy(async () => { await removeFromCart(line.id); router.refresh(); })}
                  >
                    ×
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <OldGoldEditor
        rows={oldGold}
        onChange={setOldGold}
      />

      <div className="flex w-fit gap-1 rounded-lg bg-canvas p-1">
        {(["sell", "reserve"] as const).map((m) => (
          <button
            key={m}
            type="button"
            onClick={() => setMode(m)}
            className={`rounded-md px-4 py-1.5 text-sm font-semibold ${mode === m ? "bg-ink text-canvas shadow-sm" : "text-ink hover:bg-white"}`}
          >
            {m === "sell" ? "Sell now" : "Reserve for customer"}
          </button>
        ))}
      </div>

      {mode === "sell" ? (
        <>
          <dl className="space-y-1.5 rounded-xl bg-canvas p-4 text-sm">
            <div className="flex justify-between"><dt className="text-foreground/60">Items total</dt><dd className="font-semibold">{money(subtotal)}</dd></div>
            {oldGold.length > 0 && (
              <div className="flex justify-between"><dt className="text-foreground/60">Less old gold</dt><dd className="font-semibold text-emerald-700">- {money(oldGoldTotal)}</dd></div>
            )}
            <div className="flex justify-between border-t border-slate-200 pt-2 text-lg">
              <dt className="font-semibold">To pay</dt>
              <dd className={`font-bold ${total < 0 ? "text-red-700" : "text-ink"}`}>{money(total)}</dd>
            </div>
            {total < 0 && (
              <p className="pt-1 text-xs font-medium text-red-700">
                The old gold is worth more than the items. Add more items or reduce the old gold.
              </p>
            )}
          </dl>
          <div className="grid gap-4 sm:grid-cols-3">
            <label className="block">
              <span className="label">Payment method</span>
              <select name="method" className="input" defaultValue="cash">
                {PAY_METHODS.map((m) => <option key={m.value} value={m.value}>{m.label}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="label">Customer name (optional)</span>
              <input name="customerName" className="input" placeholder="Walk-in customer" />
            </label>
            <label className="block">
              <span className="label">Phone (optional)</span>
              <input name="customerPhone" type="tel" className="input" />
            </label>
          </div>
        </>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-3">
            <label className="block">
              <span className="label">Customer name</span>
              <input name="customerName" className="input" required />
            </label>
            <label className="block">
              <span className="label">Phone</span>
              <input name="customerPhone" type="tel" className="input" required placeholder="07X XXX XXXX" />
            </label>
            <label className="block">
              <span className="label">Reserve until (optional)</span>
              <input name="reserveUntil" type="date" className="input" />
            </label>
            <label className="block">
              <span className="label">First payment (Rs., optional)</span>
              <input name="amount" type="number" min="0" step="0.01" className="input" value={firstPayment} onChange={(e) => setFirstPayment(e.target.value)} placeholder="0.00" />
            </label>
            <label className="block">
              <span className="label">Method</span>
              <select name="method" className="input" defaultValue="cash">
                {PAY_METHODS.map((m) => <option key={m.value} value={m.value}>{m.label}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="label">Notes (optional)</span>
              <input name="reservationNotes" className="input" placeholder="e.g. for a wedding on the 5th" />
            </label>
          </div>
          <dl className="space-y-1.5 rounded-xl bg-canvas p-4 text-sm">
            <div className="flex justify-between"><dt className="text-foreground/60">Items total</dt><dd className="font-semibold">{money(subtotal)}</dd></div>
            <div className="flex justify-between">
              <dt className="text-foreground/60">First payment{oldGold.length > 0 ? " (incl. old gold)" : ""}</dt>
              <dd className="font-semibold text-emerald-700">{money(firstTotal)}</dd>
            </div>
            <div className="flex justify-between border-t border-slate-200 pt-2 text-lg">
              <dt className="font-semibold">Balance to pay later</dt>
              <dd className={`font-bold ${balanceLater < 0 ? "text-red-700" : "text-ink"}`}>{money(balanceLater)}</dd>
            </div>
            {balanceLater < 0 && <p className="pt-1 text-xs font-medium text-red-700">The first payment is more than the items total.</p>}
          </dl>
        </>
      )}

      {state.error && (
        <p role="alert" className="rounded-lg border border-red-300 bg-red-50 px-3 py-2 text-sm font-medium text-red-800">{state.error}</p>
      )}

      <button type="submit" disabled={saving || invalid} className="btn-gold w-full py-3 text-base">
        {saving ? "Saving…" : mode === "sell" ? `Complete sale · ${money(total)}` : `Reserve items · balance ${money(balanceLater)}`}
      </button>
    </form>
  );
}
