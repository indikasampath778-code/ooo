"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const baseLinks = [
  { href: "/dashboard", label: "📊 Dashboard" },
  { href: "/orders", label: "📋 Orders" },
  { href: "/billing", label: "🛒 Billing" },
  { href: "/pawning", label: "🔒 Pawning" },
  { href: "/stock", label: "📦 Shop Stock" },
  { href: "/lockers", label: "🗄️ Lockers" },
  { href: "/reports", label: "📑 Reports" },
];

export default function NavLinks({ isAdmin }: { isAdmin: boolean }) {
  const pathname = usePathname();
  const links = isAdmin ? [...baseLinks, { href: "/settings", label: "⚙️ Settings" }] : baseLinks;
  // The most specific matching link wins, so /orders/new doesn't also light up /orders.
  const active = links
    .filter((l) => pathname === l.href || pathname.startsWith(`${l.href}/`))
    .sort((a, b) => b.href.length - a.href.length)[0]?.href;

  return (
    <div className="mx-auto flex max-w-7xl gap-1 px-4 py-2 sm:gap-2 sm:px-6 lg:px-8">
      {links.map((link) => (
        <Link
          key={link.href}
          href={link.href}
          className={`rounded-lg px-3.5 py-2 text-xs font-semibold whitespace-nowrap transition ${
            active === link.href ? "bg-gold text-slate-950 shadow" : "text-slate-300 hover:bg-slate-800"
          }`}
        >
          {link.label}
        </Link>
      ))}
    </div>
  );
}
