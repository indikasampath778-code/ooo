"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";

/**
 * Dropdown filter that keeps its choice in the URL (`?name=value`). With `allLabel` the
 * first option clears it; `defaultValue` is the option shown when the URL has none.
 */
export default function FilterSelect({ name, allLabel, options, defaultValue = "" }: {
  name: string;
  allLabel?: string;
  options: { value: string; label: string }[];
  defaultValue?: string;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  return (
    <select
      aria-label={allLabel ?? name}
      className="input w-auto"
      value={searchParams.get(name) ?? defaultValue}
      onChange={(e) => {
        const params = new URLSearchParams(searchParams.toString());
        if (e.target.value && e.target.value !== defaultValue) params.set(name, e.target.value);
        else params.delete(name);
        const query = params.toString();
        router.replace(query ? `${pathname}?${query}` : pathname, { scroll: false });
      }}
    >
      {allLabel && <option value="">{allLabel}</option>}
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}
