"use client";

import { useRef, useState, useTransition } from "react";
import { deleteStockItem } from "@/app/actions/stock";

/**
 * Delete button for a stock item. It asks in a confirmation popup first, then deletes
 * and returns to the Shop Stock list.
 */
export default function DeleteStockButton({ id, label }: { id: string; label: string }) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState("");

  return (
    <>
      <button
        type="button"
        className="btn-danger"
        onClick={() => {
          setError("");
          dialogRef.current?.showModal();
        }}
      >
        Delete
      </button>

      <dialog
        ref={dialogRef}
        aria-label="Delete item"
        onClick={(e) => {
          if (e.target === dialogRef.current && !pending) dialogRef.current?.close();
        }}
        className="m-auto w-[min(92vw,26rem)] rounded-2xl bg-white p-6 text-slate-900 shadow-2xl backdrop:bg-slate-950/70"
      >
        <h2 className="text-base font-bold">Delete this item?</h2>
        <p className="mt-2 text-sm text-foreground/70">
          <strong>{label}</strong> will be removed from shop stock. This can&apos;t be undone. Use this only for items
          added by mistake.
        </p>
        {error && <p role="alert" className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-800 ring-1 ring-red-200">{error}</p>}
        <div className="mt-5 flex justify-end gap-2">
          <button type="button" className="btn-outline" disabled={pending} onClick={() => dialogRef.current?.close()}>
            No, keep it
          </button>
          <button
            type="button"
            className="btn-danger"
            disabled={pending}
            onClick={() =>
              startTransition(async () => {
                const result = await deleteStockItem(id);
                if (result?.error) setError(result.error);
              })
            }
          >
            {pending ? "Deleting…" : "Yes, delete"}
          </button>
        </div>
      </dialog>
    </>
  );
}
