"use client";

import { useRef, useState } from "react";

/**
 * "Print barcode label" button that shows the label in a popup dialog on the same
 * screen. The label page loads in a frame, so Print sends only the label (with its
 * own 34 × 25 mm page size) to the printer.
 */
export default function LabelPrintButton({ kind, id, className = "btn-gold", label = "Print barcode label" }: {
  kind: "order" | "pawn" | "stock";
  id: string;
  className?: string;
  label?: string;
}) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const frameRef = useRef<HTMLIFrameElement>(null);
  const [open, setOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);

  const close = () => {
    dialogRef.current?.close();
    setOpen(false);
    setLoaded(false);
  };

  return (
    <>
      <button
        type="button"
        className={className}
        onClick={() => {
          setOpen(true);
          dialogRef.current?.showModal();
        }}
      >
        {label}
      </button>

      <dialog
        ref={dialogRef}
        onClose={() => {
          setOpen(false);
          setLoaded(false);
        }}
        onClick={(e) => {
          // Clicking the dark backdrop closes the popup.
          if (e.target === dialogRef.current) close();
        }}
        aria-label="Barcode label"
        className="m-auto w-[min(92vw,32rem)] overflow-hidden rounded-2xl bg-white p-0 shadow-2xl backdrop:bg-slate-950/60"
      >
        <div className="px-6 pt-6 pb-4">
          {open && (
            <iframe
              ref={frameRef}
              src={`/print/label/${kind}/${id}?embed=1`}
              title="Barcode label preview"
              onLoad={() => setLoaded(true)}
              className="h-[300px] w-full border-0 bg-white"
            />
          )}
        </div>

        <div className="flex justify-end gap-3 bg-slate-900 px-6 py-4">
          <button
            type="button"
            onClick={close}
            className="rounded-lg border border-slate-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={!loaded}
            onClick={() => frameRef.current?.contentWindow?.print()}
            className="rounded-lg bg-amber-400 px-4 py-2 text-sm font-semibold text-slate-950 transition hover:bg-amber-300 disabled:opacity-60"
          >
            {loaded ? "Print Now" : "Loading…"}
          </button>
        </div>
      </dialog>
    </>
  );
}
