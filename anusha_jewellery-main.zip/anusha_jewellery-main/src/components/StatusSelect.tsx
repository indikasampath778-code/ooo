"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState, useTransition } from "react";
import { updateOrderStatus } from "@/app/actions/orders";
import { Field } from "@/components/ui";
import WeightInput from "@/components/WeightInput";
import { KARATS } from "@/lib/constants";

const styles: Record<string, string> = {
  pending: "bg-stone-100 text-stone-700 ring-stone-300",
  in_progress: "bg-blue-50 text-blue-800 ring-blue-200",
};

/**
 * Status dropdown for an order. Pending / In Progress / Cancelled save right away.
 * Completed needs the final weight, carats and price: in the orders table it opens
 * the order page; on the order page (`completion` given) it opens a popup to enter them.
 */
export default function StatusSelect({ id, status, completion, startCompleting = false }: {
  id: string;
  status: "pending" | "in_progress";
  /** Ordered weight and carats, used as defaults in the completion popup. */
  completion?: { weightMg: number | null; karat: number };
  /** Open the completion popup straight away (arriving from the orders table). */
  startCompleting?: boolean;
}) {
  const router = useRouter();
  const [value, setValue] = useState<string>(status);
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState("");
  const [formError, setFormError] = useState("");
  const dialogRef = useRef<HTMLDialogElement>(null);

  const canComplete = Boolean(completion);
  useEffect(() => {
    if (canComplete && startCompleting) dialogRef.current?.showModal();
  }, [canComplete, startCompleting]);

  function save(fd: FormData, onError: (message: string) => void) {
    startTransition(async () => {
      const result = await updateOrderStatus(id, {}, fd);
      if (result.error) onError(result.error);
      else if (fd.get("status") === "completed") {
        dialogRef.current?.close();
        router.replace(`/orders/${id}`);
      }
      router.refresh();
    });
  }

  function change(next: string) {
    setError("");
    if (next === "completed") {
      if (completion) {
        setFormError("");
        dialogRef.current?.showModal();
      } else {
        router.push(`/orders/${id}?complete=1`);
      }
      return;
    }
    if (next === "cancelled" && !window.confirm("Cancel this order? It will be taken out of its locker (if any).")) return;
    const previous = value;
    setValue(next);
    const fd = new FormData();
    fd.set("status", next);
    save(fd, (message) => {
      setValue(previous);
      setError(message);
    });
  }

  return (
    <span className="inline-flex flex-col">
      <select
        aria-label="Order status"
        value={value}
        disabled={pending}
        onChange={(e) => change(e.target.value)}
        className={`cursor-pointer rounded-full py-0.5 pr-7 pl-2.5 text-xs font-semibold ring-1 outline-none focus:ring-2 focus:ring-ink/40 disabled:opacity-60 ${styles[value] ?? "bg-white ring-gold/50"}`}
      >
        <option value="pending">Pending</option>
        <option value="in_progress">In Progress</option>
        <option value="completed">Completed…</option>
        <option value="cancelled">Cancelled</option>
      </select>
      {error && <span className="mt-1 max-w-40 text-[11px] text-red-700">{error}</span>}

      {completion && (
        <dialog
          ref={dialogRef}
          aria-label="Mark order as completed"
          onClick={(e) => {
            if (e.target === dialogRef.current) dialogRef.current?.close();
          }}
          className="m-auto w-[min(92vw,28rem)] overflow-hidden rounded-2xl bg-white p-0 shadow-2xl backdrop:bg-slate-950/60"
        >
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setFormError("");
              const fd = new FormData(e.currentTarget);
              fd.set("status", "completed");
              save(fd, setFormError);
            }}
          >
            <div className="space-y-4 px-6 pt-6 pb-5">
              <div>
                <h2 className="text-lg font-bold text-slate-900">Mark as completed</h2>
                <p className="text-xs text-slate-500">Enter the finished item&apos;s weight and carats. The price can be added later.</p>
              </div>
              <WeightInput name="finalWeight" label="Final weight" defaultMg={completion.weightMg} />
              <Field label="Number of carats">
                <select name="finalKarat" className="input" defaultValue={completion.karat}>
                  {KARATS.map((k) => <option key={k} value={k}>{k}K</option>)}
                </select>
              </Field>
              <Field label="Price (Rs., optional)">
                <input name="price" type="number" min="0.01" step="0.01" className="input" placeholder="Set later" />              </Field>
              {formError && (
                <p role="alert" className="rounded-lg border border-red-300 bg-red-50 px-3 py-2 text-sm font-medium text-red-800">{formError}</p>
              )}
            </div>
            <div className="flex justify-end gap-3 bg-slate-900 px-6 py-4">
              <button
                type="button"
                onClick={() => dialogRef.current?.close()}
                className="rounded-lg border border-slate-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={pending}
                className="rounded-lg bg-amber-400 px-4 py-2 text-sm font-semibold text-slate-950 transition hover:bg-amber-300 disabled:opacity-60"
              >
                {pending ? "Saving…" : "Mark completed"}
              </button>
            </div>
          </form>
        </dialog>
      )}
    </span>
  );
}
