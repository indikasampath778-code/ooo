"use client";

import { useRouter } from "next/navigation";

/**
 * Print pages open in the same tab, so they get a Back button next to Print to
 * return to the screen the staff member came from.
 */
export default function PrintButton({ label = "Print" }: { label?: string }) {
  const router = useRouter();
  return (
    <div className="flex flex-wrap justify-center gap-2">
      <button
        type="button"
        onClick={() => (window.history.length > 1 ? router.back() : router.push("/dashboard"))}
        className="btn-outline"
      >
        ← Back
      </button>
      <button type="button" onClick={() => window.print()} className="btn-primary">
        {label}
      </button>
    </div>
  );
}
