"use client";

import { useRouter } from "next/navigation";
import type { ReactNode } from "react";

/** Table row that opens `href` when clicked anywhere (links inside still work normally). */
export default function ClickableRow({ href, className, children }: { href: string; className?: string; children: ReactNode }) {
  const router = useRouter();
  return (
    <tr
      className={`cursor-pointer ${className ?? ""}`}
      onClick={(event) => {
        // Clicks inside a popup opened from the row (edit form, label) stay in the popup.
        if ((event.target as HTMLElement).closest("a, button, input, select, textarea, label, dialog")) return;
        router.push(href);
      }}
    >
      {children}
    </tr>
  );
}
