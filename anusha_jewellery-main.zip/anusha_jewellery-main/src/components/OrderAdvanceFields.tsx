"use client";

import { useState } from "react";
import OldGoldEditor, { money, oldGoldPayload, oldGoldTotal, round2, type OldGoldRow } from "@/components/OldGoldEditor";
import { PAY_METHODS } from "@/lib/constants";

/**
 * Advance taken when the order is placed: cash/card and/or old gold, credited as the
 * first payment.
 */
export default function OrderAdvanceFields() {
  const [cash, setCash] = useState("");
  const [oldGold, setOldGold] = useState<OldGoldRow[]>([]);
  const goldValue = oldGoldTotal(oldGold);
  const total = round2((Number(cash) || 0) + goldValue);

  return (
    <fieldset className="space-y-4 rounded-xl border border-slate-200 px-4 pt-2 pb-4">
      <legend className="px-1 text-sm font-semibold text-ink">Advance payment (optional)</legend>
      <input type="hidden" name="oldGold" value={oldGoldPayload(oldGold)} />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <label className="block">
          <span className="label">Advance amount (Rs.)</span>
          <input name="advance" type="number" min="0" step="0.01" className="input" placeholder="0.00" value={cash} onChange={(e) => setCash(e.target.value)} />
        </label>
        <label className="block">
          <span className="label">Method</span>
          <select name="method" className="input" defaultValue="cash">
            {PAY_METHODS.map((m) => <option key={m.value} value={m.value}>{m.label}</option>)}
          </select>
        </label>
      </div>

      <OldGoldEditor rows={oldGold} onChange={setOldGold} hint="Customer handing in old gold for this order? Add it here; its value counts towards the advance." />

      {total > 0 && (
        <dl className="space-y-1 rounded-xl bg-canvas p-3 text-sm sm:max-w-sm">
          <div className="flex justify-between"><dt className="text-foreground/60">Cash / card</dt><dd className="font-semibold">{money(Number(cash) || 0)}</dd></div>
          {oldGold.length > 0 && (
            <div className="flex justify-between"><dt className="text-foreground/60">Old gold</dt><dd className="font-semibold">{money(goldValue)}</dd></div>
          )}
          <div className="flex justify-between border-t border-slate-200 pt-1 text-base">
            <dt className="font-semibold">Total advance</dt>
            <dd className="font-bold text-emerald-700">{money(total)}</dd>
          </div>
        </dl>
      )}

    </fieldset>
  );
}
