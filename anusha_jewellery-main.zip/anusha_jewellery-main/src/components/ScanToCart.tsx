"use client";

import { useRouter } from "next/navigation";
import { useRef, useState, useTransition } from "react";
import { addToCartByCode } from "@/app/actions/cart";

/**
 * Scan box for the shop sales cart. A scanned stock code goes straight into the cart
 * and the box clears for the next scan; other text shows matching items below.
 */
export default function ScanToCart({ initial }: { initial: string }) {
  const router = useRouter();
  const input = useRef<HTMLInputElement>(null);
  const [value, setValue] = useState(initial);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, startTransition] = useTransition();

  return (
    <form
      className="card space-y-3"
      onSubmit={(e) => {
        e.preventDefault();
        const q = value.trim();
        if (!q) return;
        startTransition(async () => {
          const result = await addToCartByCode(q);
          if (result.notFound) {
            setMessage(null);
            router.push(`/billing?type=stock&q=${encodeURIComponent(q)}`);
            return;
          }
          setMessage(result.error ? { ok: false, text: result.error } : { ok: true, text: result.success ?? "Added" });
          if (!result.error) setValue("");
          router.replace("/billing?type=stock");
          router.refresh();
          input.current?.focus();
        });
      }}
    >
      <div className="flex flex-col gap-3 sm:flex-row">
        <input
          ref={input}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          autoFocus
          className="input"
          placeholder="Scan item barcodes one after another, or search by name"
          aria-label="Scan or search stock"
        />
        <button disabled={pending} className="btn-primary px-6 whitespace-nowrap">
          {pending ? "Adding…" : "Add / Search"}
        </button>
      </div>
      {message && (
        <p className={`text-sm font-medium ${message.ok ? "text-emerald-700" : "text-red-700"}`}>{message.text}</p>
      )}
    </form>
  );
}
