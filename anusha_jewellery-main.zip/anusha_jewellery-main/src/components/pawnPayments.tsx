import { payPawnInstallment, payPawnInterest, settlePawn } from "@/app/actions/pawns";
import ActionForm from "@/components/ActionForm";
import { PayMethodSelect } from "@/components/orders";
import { Accordion, Field } from "@/components/ui";
import { formatDate, formatMoney } from "@/lib/format";
import { lockerLabel } from "@/lib/lockerLabel";
import { pawnFigures } from "@/lib/pawns";
import type { PawnDoc } from "@/lib/types";

export function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className={`flex justify-between gap-4 ${strong ? "border-t border-slate-200 pt-2 text-base font-bold text-ink" : ""}`}>
      <dt className={strong ? "" : "text-foreground/60"}>{label}</dt>
      <dd className="text-right font-semibold">{value}</dd>
    </div>
  );
}

/** Interest figures for a pawn as of today. */
export function PawnInterestSummary({ pawn }: { pawn: PawnDoc }) {
  const f = pawnFigures(pawn);
  const active = pawn.status === "active";
  return (
    <>
      <dl className="space-y-2 text-sm">
        <Row label="Days elapsed (since pawned)" value={active ? `${f.daysElapsed} days` : "—"} />
        <Row label="Unpaid interest from" value={formatDate(f.interestFrom)} />
        <Row label="Unpaid days" value={active ? `${f.interestDays} days` : "—"} />
        <Row label="Accrued interest" value={formatMoney(f.accruedInterest)} strong />
        <Row label="Interest paid so far" value={formatMoney(f.interestPaid)} />
      </dl>
      <p className="mt-3 text-xs text-foreground/50">
        {pawn.monthlyRate}% per month on {formatMoney(pawn.principal)}, charged per day (30-day month).
      </p>
    </>
  );
}

/** Billing → Pawn payments: Pay Interest / Renewal and Full Settlement & Release. */
export function PawnPaymentPanel({ pawn }: { pawn: PawnDoc }) {
  const id = pawn._id.toString();
  const f = pawnFigures(pawn);

  if (pawn.status !== "active") {
    const last = pawn.payments.at(-1);
    return (
      <section className="card space-y-3">
        <h2 className="card-title mb-0">Settled &amp; released</h2>
        <p className="text-sm text-foreground/70">This pawn is fully settled and the item was returned.</p>
        {last && (
          <a href={`/print/receipt/${last.receiptNo}`} className="btn-primary w-full">
            Print settlement receipt ({last.receiptNo})
          </a>
        )}
      </section>
    );
  }

  return (
    <div className="space-y-4">
      <Accordion
        title="1. Pay Interest / Renewal"
        summary={<span className="text-sm font-semibold text-foreground/60">{formatMoney(f.accruedInterest)}</span>}
        defaultOpen
      >
        <ActionForm action={payPawnInterest.bind(null, id)} submitLabel={`Receive ${formatMoney(f.accruedInterest)} interest`} submitClassName="btn-gold w-full">
          <p className="text-sm text-foreground/70">Customer pays only the interest. The item stays in locker {lockerLabel(pawn.lockerCode, pawn.lockerSlot)}.</p>
          <Field label="Method"><PayMethodSelect /></Field>
        </ActionForm>
      </Accordion>

      <Accordion
        title="2. Installment (part payment)"
        summary={<span className="text-sm font-semibold text-foreground/60">Loan {formatMoney(pawn.principal)}</span>}
      >
        <dl className="mb-4 space-y-2 text-sm">
          <Row label="Loan balance (principal)" value={formatMoney(pawn.principal)} />
          <Row label="Interest due now" value={formatMoney(f.accruedInterest)} />
        </dl>
        <ActionForm action={payPawnInstallment.bind(null, id)} submitLabel="Receive installment" submitClassName="btn-gold w-full">
          <p className="text-sm text-foreground/70">
            The installment first clears the interest due; the rest reduces the loan. The item stays in locker {lockerLabel(pawn.lockerCode, pawn.lockerSlot)}.
          </p>
          <Field label="Installment amount (Rs.)">
            <input
              name="amount"
              type="number"
              min={Math.max(0.01, f.accruedInterest)}
              max={Math.max(0.01, f.settlementAmount - 0.01)}
              step="0.01"
              className="input"
              required
              placeholder={`At least ${formatMoney(f.accruedInterest)}`}
            />
          </Field>
          <Field label="Method"><PayMethodSelect /></Field>
        </ActionForm>
      </Accordion>

      <Accordion
        title="3. Full Settlement & Release"
        summary={<span className="text-sm font-semibold text-foreground/60">{formatMoney(f.settlementAmount)}</span>}
      >
        <dl className="mb-4 space-y-2 text-sm">
          <Row label="Principal" value={formatMoney(pawn.principal)} />
          <Row label="Accrued interest" value={formatMoney(f.accruedInterest)} />
          <Row label="Total to settle" value={formatMoney(f.settlementAmount)} strong />
        </dl>
        <ActionForm
          action={settlePawn.bind(null, id)}
          submitLabel={`Settle ${formatMoney(f.settlementAmount)} & release`}
          submitClassName="btn-primary w-full"
          confirmMessage={`Receive ${formatMoney(f.settlementAmount)} and release the item from ${lockerLabel(pawn.lockerCode, pawn.lockerSlot)}?`}
        >
          <Field label="Method"><PayMethodSelect /></Field>
          <label className="flex items-start gap-2 text-sm">
            <input type="checkbox" name="confirm" required className="mt-0.5 size-4 accent-ink" />
            <span>Item handed back to the customer</span>
          </label>
        </ActionForm>
      </Accordion>
    </div>
  );
}
