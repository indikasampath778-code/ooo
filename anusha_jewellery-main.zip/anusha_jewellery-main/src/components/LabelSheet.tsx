import Barcode from "@/components/Barcode";
import { SHOP } from "@/lib/constants";

/** Page styles for 34 mm × 25 mm labels; each LabelSheet prints on its own label. */
export const LABEL_PAGE_CSS = `
  @page { size: 34mm 25mm; margin: 0; }
  @media print { html, body { margin: 0 !important; padding: 0 !important; background: #fff !important; min-height: 0 !important; } }
  @media screen { .label-sheet { zoom: 3; box-shadow: 0 0 0 0.25mm #d4af37; } }
  .label-sheet { break-after: page; }
  .label-sheet:last-child { break-after: auto; }
  .label-sheet svg { height: 9mm; }
`;

/** One 34 mm wide × 25 mm high label: shop name, barcode, code, locker and weight. */
export default function LabelSheet({ barcode, locker, weightMg }: { barcode: string; locker: string | null; weightMg: number }) {
  return (
    <div
      className="label-sheet bg-white text-black"
      style={{
        width: "34mm",
        height: "25mm",
        padding: "1mm 1.5mm",
        boxSizing: "border-box",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "space-between",
        textAlign: "center",
        fontFamily: "Arial, Helvetica, sans-serif",
        lineHeight: 1.1,
      }}
    >
      <div style={{ fontFamily: "var(--font-cinzel), serif", fontWeight: 700, fontStyle: "italic", fontSize: "8pt", letterSpacing: "0.2pt" }}>
        {SHOP.name}
      </div>
      <Barcode value={barcode} className="block w-full" />
      <div style={{ fontSize: "7pt", letterSpacing: "0.6pt" }}>{barcode}</div>
      <div style={{ fontSize: "6.5pt", fontWeight: 700 }}>
        {[locker, `${(weightMg / 1000).toFixed(3)}g`].filter(Boolean).join("  ·  ")}
      </div>
    </div>
  );
}
