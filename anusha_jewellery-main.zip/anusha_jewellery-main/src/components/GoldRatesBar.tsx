"use client";

import { startTransition, useActionState, useEffect, useRef, useState } from "react";
import { setGoldRates } from "@/app/actions/rates";
import { SOVEREIGN_GRAMS } from "@/lib/constants";

type Rates = { rate24: number; rate22: number; rate18: number };

const rs = (n: number) => `Rs. ${n.toLocaleString("en-LK", { maximumFractionDigits: 2 })}`;

/**
 * Compact "Gold Rate" button for the top bar. It opens the Daily Morning Gold Rates
 * popup, which shows the current rates; admins can update them there.
 */
export default function GoldRatesBar({ rates, setOn, isToday, canEdit }: {
  rates: Rates | null;
  /** Date the shown rates were set, already formatted. */
  setOn: string | null;
  isToday: boolean;
  canEdit: boolean;
}) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const [state, formAction, saving] = useActionState(setGoldRates, {});
  const [r24, setR24] = useState("");
  const [r22, setR22] = useState("");
  const [r18, setR18] = useState("");

  useEffect(() => {
    if (state.success) dialogRef.current?.close();
  }, [state]);

  function openModal() {
    setR24(rates ? String(rates.rate24) : "");
    setR22(rates ? String(rates.rate22) : "");
    setR18(rates ? String(rates.rate18) : "");
    dialogRef.current?.showModal();
  }

  const close = () => dialogRef.current?.close();
  const sov = (value: string) => rs((Number(value) || 0) * SOVEREIGN_GRAMS);

  return (
    <>
      <button
        type="button"
        onClick={openModal}
        className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/90 px-3 py-2 text-xs font-semibold whitespace-nowrap text-amber-400 transition hover:border-gold/60 hover:bg-slate-800"
      >
        <span className={`inline-block size-2 rounded-full ${rates && isToday ? "animate-pulse bg-emerald-400" : "bg-amber-500"}`} />
        ⚡ Gold Rate
        {(!rates || !isToday) && (
          <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] text-amber-300">{rates ? "Not updated today" : "Not set"}</span>
        )}
      </button>

      <dialog
        ref={dialogRef}
        aria-label="Daily Morning Gold Rates"
        onClick={(e) => {
          if (e.target === dialogRef.current) close();
        }}
        className="m-auto w-[min(92vw,26rem)] rounded-2xl bg-white p-6 text-slate-900 shadow-2xl backdrop:bg-slate-950/70"
      >
        <div className="flex items-start justify-between border-b border-slate-200 pb-3">
          <div>
            <h2 className="text-sm font-bold">⚡ Daily Morning Gold Rates</h2>
            <p className="mt-0.5 text-xs text-slate-500">
              {rates ? (isToday ? `Today's rates (${setOn})` : `Last set on ${setOn} — not updated today`) : "No rates set yet"}
            </p>
          </div>
          <button type="button" onClick={close} aria-label="Close" className="text-lg text-slate-400 hover:text-slate-700">
            &times;
          </button>
        </div>

        {canEdit ? (
          <form
            className="mt-4 space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              startTransition(() => formAction(fd));
            }}
          >
            <label className="block">
              <span className="label">24K Gold Rate per gram (Rs):</span>
              <input name="rate24" type="number" min="0.01" step="0.01" required className="input font-bold" value={r24} onChange={(e) => setR24(e.target.value)} />
              <span className="text-[10px] text-slate-500">24K Sovereign ({SOVEREIGN_GRAMS}g): <b>{sov(r24)}</b></span>
            </label>
            <label className="block">
              <span className="label">22K Gold Rate per gram (Rs):</span>
              <input name="rate22" type="number" min="0.01" step="0.01" required className="input font-bold text-amber-700" value={r22} onChange={(e) => setR22(e.target.value)} />
              <span className="text-[10px] text-slate-500">22K Sovereign ({SOVEREIGN_GRAMS}g): <b>{sov(r22)}</b></span>
            </label>
            <label className="block">
              <span className="label">18K Gold Rate per gram (Rs):</span>
              <input name="rate18" type="number" min="0.01" step="0.01" required className="input font-bold" value={r18} onChange={(e) => setR18(e.target.value)} />
            </label>
            {state.error && (
              <p role="alert" className="rounded-lg border border-red-300 bg-red-50 px-3 py-2 text-sm font-medium text-red-800">{state.error}</p>
            )}
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={close} className="rounded-lg bg-slate-100 px-4 py-2 text-sm text-slate-700 hover:bg-slate-200">
                Cancel
              </button>
              <button type="submit" disabled={saving} className="rounded-lg bg-gold px-5 py-2 text-sm font-bold text-slate-950 hover:bg-amber-500 disabled:opacity-60">
                {saving ? "Saving…" : "Save Rates"}
              </button>
            </div>
          </form>
        ) : (
          <div className="mt-4 space-y-3">
            {rates ? (
              <dl className="divide-y divide-slate-100 rounded-xl border border-slate-200">
                {([["24K", rates.rate24, true], ["22K", rates.rate22, true], ["18K", rates.rate18, false]] as const).map(([k, rate, showSov]) => (
                  <div key={k} className="flex items-center justify-between px-4 py-3">
                    <dt className="text-sm font-semibold text-slate-600">{k} per gram</dt>
                    <dd className="text-right">
                      <span className={`text-base font-bold ${k === "22K" ? "text-amber-700" : ""}`}>{rs(rate)}</span>
                      {showSov && <span className="block text-[10px] text-slate-500">{rs(rate * SOVEREIGN_GRAMS)} per sovereign</span>}
                    </dd>
                  </div>
                ))}
              </dl>
            ) : (
              <p className="text-sm text-slate-500">Ask the shop owner to set today&apos;s rates.</p>
            )}
            <div className="flex justify-end">
              <button type="button" onClick={close} className="rounded-lg bg-slate-100 px-4 py-2 text-sm text-slate-700 hover:bg-slate-200">
                Close
              </button>
            </div>
          </div>
        )}
      </dialog>
    </>
  );
}
