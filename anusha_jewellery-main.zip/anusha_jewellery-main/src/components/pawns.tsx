import Link from "next/link";
import ClickableRow from "@/components/ClickableRow";
import { Pill } from "@/components/ui";
import { getCategoryNames } from "@/lib/categories";
import { formatDate, formatMoney, formatWeight, todayISO } from "@/lib/format";
import { lockerLabel } from "@/lib/lockerLabel";
import { pawnFigures } from "@/lib/pawns";
import type { PawnDoc } from "@/lib/types";

export async function PawnsTable({ pawns, bare = false, inBilling = false }: {
  pawns: PawnDoc[];
  bare?: boolean;
  /** Rows open the pawn in Billing → Pawn payments instead of the pawn page. */
  inBilling?: boolean;
}) {
  const today = todayISO();
  const categoryName = await getCategoryNames();
  return (
    <div className={`overflow-x-auto ${bare ? "" : "rounded-2xl border border-slate-200 bg-white shadow-sm"}`}>
      <table className="table">
        <thead>
          <tr>
            <th>Ticket</th>
            <th>Customer</th>
            <th>Item</th>
            <th className="text-right">Principal</th>
            <th>Pawned</th>
            <th className="text-right">Days elapsed</th>
            <th className="text-right">Accrued interest</th>
            <th>Locker</th>
          </tr>
        </thead>
        <tbody>
          {pawns.map((pawn) => {
            const f = pawnFigures(pawn, today);
            return (
              <ClickableRow key={pawn._id.toString()} href={inBilling ? `/billing?type=pawn&id=${pawn._id}` : `/pawning/${pawn._id}`} className="hover:bg-canvas/70">
                <td>
                  <Link href={inBilling ? `/billing?type=pawn&id=${pawn._id}` : `/pawning/${pawn._id}`} className="font-semibold text-ink underline decoration-gold underline-offset-2">
                    {pawn.ticketNo}
                  </Link>
                  {pawn.status === "released" && <div className="mt-1"><Pill tone="gray">Released</Pill></div>}
                </td>
                <td>
                  <p className="font-medium">{pawn.customer.name}</p>
                  <p className="text-xs text-foreground/60">{pawn.customer.nic}</p>
                </td>
                <td className="whitespace-nowrap">
                  {categoryName(pawn.category)} · {pawn.standard}
                  <p className="text-xs text-foreground/60">Net {formatWeight(pawn.netWeightMg)}</p>
                </td>
                <td className="text-right whitespace-nowrap">
                  {formatMoney(pawn.principal)}
                  <p className="text-xs text-foreground/60">{pawn.monthlyRate}% / month</p>
                </td>
                <td className="whitespace-nowrap">{formatDate(pawn.pawnDate)}</td>
                <td className="text-right">{pawn.status === "active" ? f.daysElapsed : "—"}</td>
                <td className="text-right font-semibold whitespace-nowrap text-ink">
                  {pawn.status === "active" ? formatMoney(f.accruedInterest) : "—"}
                </td>
                <td className="font-bold whitespace-nowrap text-ink">
                  {pawn.status === "active" ? lockerLabel(pawn.lockerCode, pawn.lockerSlot) : "—"}
                </td>
              </ClickableRow>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

/** Big "where is it stored" card for finder results. */
export async function StorageCard({ pawn }: { pawn: PawnDoc }) {
  const categoryName = await getCategoryNames();
  return (
    <Link
      href={`/pawning/${pawn._id}`}
      className="flex items-center gap-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition hover:shadow-md"
    >
      <div className={`rounded-xl px-4 py-3 text-center ${pawn.status === "active" ? "bg-ink text-canvas" : "bg-stone-200 text-stone-600"}`}>
        <p className="text-[10px] tracking-widest uppercase opacity-80">Locker</p>
        <p className="font-bold text-2xl">{pawn.status === "active" ? lockerLabel(pawn.lockerCode, pawn.lockerSlot) : "—"}</p>
      </div>
      <div className="min-w-0">
        <p className="font-semibold text-ink">
          {pawn.ticketNo} {pawn.status === "released" && <Pill tone="gray">Released</Pill>}
        </p>
        <p className="truncate font-medium">{pawn.customer.name}</p>
        <p className="text-sm text-foreground/60">
          NIC {pawn.customer.nic} · {categoryName(pawn.category)} {pawn.standard} · {formatWeight(pawn.netWeightMg)}
        </p>
      </div>
    </Link>
  );
}
