"use client";

import { useState, type ReactNode } from "react";

/**
 * Order page top bar (Order / Payments tabs, status, delivery badge, actions) with
 * the chosen tab's content below at full width.
 */
export default function OrderTabs({ status, actions, paymentsSummary, order, payments }: {
  status: ReactNode;
  actions?: ReactNode;
  paymentsSummary: ReactNode;
  order: ReactNode;
  payments: ReactNode;
}) {
  const [tab, setTab] = useState<"order" | "payments">("order");
  const tabClass = (active: boolean) =>
    `rounded-lg px-3.5 py-1.5 text-sm font-semibold whitespace-nowrap transition ${
      active ? "bg-ink text-white shadow-sm" : "text-ink hover:bg-white"
    }`;

  return (
    <>
      <div className="mb-6 flex flex-wrap items-center gap-3">
        <div role="tablist" className="flex items-center gap-1 rounded-xl bg-slate-100 p-1">
          <button type="button" role="tab" aria-selected={tab === "order"} className={tabClass(tab === "order")} onClick={() => setTab("order")}>
            Order
          </button>
          <span aria-hidden className="mx-0.5 h-6 w-px bg-slate-300" />
          <button type="button" role="tab" aria-selected={tab === "payments"} className={tabClass(tab === "payments")} onClick={() => setTab("payments")}>
            Payments <span className="ml-1 text-xs font-medium opacity-80">· {paymentsSummary}</span>
          </button>
        </div>
        <span aria-hidden className="h-7 w-px bg-slate-300" />
        {status}
        {actions && <div className="ml-auto flex flex-wrap gap-2">{actions}</div>}
      </div>

      <div role="tabpanel">{tab === "order" ? order : payments}</div>
    </>
  );
}
