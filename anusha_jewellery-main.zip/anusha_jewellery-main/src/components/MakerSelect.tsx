import Link from "next/link";
import { Field } from "@/components/ui";
import { getMakers } from "@/lib/makers";

/**
 * Item maker picker filled from Settings → Item makers. The record stores the
 * maker's name, so a name that is no longer in the list is still offered.
 */
export default async function MakerSelect({ label, defaultValue, required = false }: {
  label: string;
  defaultValue?: string;
  required?: boolean;
}) {
  const makers = await getMakers();
  const names = makers.map((m) => m.name);
  if (defaultValue && !names.includes(defaultValue)) names.unshift(defaultValue);

  return (
    <Field label={label}>
      <select name="makerName" className="input" required={required} defaultValue={defaultValue ?? ""}>
        <option value="">{names.length === 0 ? "No makers yet" : required ? "Choose a maker…" : "— None —"}</option>
        {names.map((name) => (
          <option key={name} value={name}>{name}</option>
        ))}
      </select>
      {makers.length === 0 && (
        <span className="mt-1 block text-xs text-foreground/50">
          Add item makers in <Link href="/settings?tab=makers" className="underline">Settings → Item makers</Link>.
        </span>
      )}
    </Field>
  );
}
