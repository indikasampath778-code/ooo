"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { addToCart } from "@/app/actions/cart";

/** "Add to cart" for one stock item; shows "In cart" once added. */
export default function AddToCartButton({ id, inCart, size = "sm" }: { id: string; inCart: boolean; size?: "sm" | "md" }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState("");
  const cls = size === "md" ? "" : "px-3 py-1 text-xs";

  if (inCart) {
    return (
      <Link href="/billing?type=stock" className={`btn-outline whitespace-nowrap ${cls}`}>
        ✓ In cart
      </Link>
    );
  }
  return (
    <span className="inline-flex flex-col">
      <button
        type="button"
        disabled={pending}
        className={`btn-success whitespace-nowrap ${cls}`}
        onClick={() =>
          startTransition(async () => {
            const result = await addToCart(id);
            setError(result.error ?? "");
            router.refresh();
          })
        }
      >
        {pending ? "Adding…" : "+ Add to cart"}
      </button>
      {error && <span className="mt-1 text-[11px] text-red-700">{error}</span>}
    </span>
  );
}
